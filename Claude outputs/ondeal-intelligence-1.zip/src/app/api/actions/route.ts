import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireStoreAccess, AuthError } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { SENSITIVE_ACTION_TYPES } from "@/lib/intelligence/actionTypes";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const { storeId, recommendationId } = body ?? {};
  if (!storeId || !recommendationId) return NextResponse.json({ error: "storeId et recommendationId requis." }, { status: 400 });

  try {
    const { userId } = await requireStoreAccess(storeId);

    const rec = await prisma.recommendation.findUnique({ where: { id: recommendationId } });
    if (!rec || rec.storeId !== storeId) return NextResponse.json({ error: "Recommandation introuvable." }, { status: 404 });
    if (!rec.actionType) return NextResponse.json({ error: "Cette recommandation n'a pas d'action exécutable." }, { status: 400 });

    // Garde-fou anti-doublon : si une action non terminale existe déjà pour
    // cette recommandation (double clic, rechargement avant que l'UI ne
    // reprenne son état, appel direct de l'API), on la retourne telle
    // quelle plutôt que d'en créer une deuxième pour la même décision.
    const active = await prisma.actionItem.findFirst({
      where: { recommendationId, status: { in: ["PENDING_VALIDATION", "CONFIRMED"] } },
      orderBy: { createdAt: "desc" },
    });
    if (active) {
      return NextResponse.json({ ok: true, actionId: active.id, resumed: true });
    }

    const sensitivity = SENSITIVE_ACTION_TYPES.has(rec.actionType) ? "SENSITIVE" : "SAFE";

    const action = await prisma.actionItem.create({
      data: {
        storeId,
        recommendationId,
        type: rec.actionType,
        sensitivity,
        status: "PENDING_VALIDATION",
        payloadJson: rec.actionPayloadJson ?? "{}",
        createdByUserId: userId,
      },
    });

    await logAudit({
      storeId,
      userId,
      actorType: "user",
      event: "action.prepared",
      message: `Action préparée : "${rec.title}" (${rec.actionType}). En attente de validation.`,
      meta: { actionId: action.id },
    });

    return NextResponse.json({ ok: true, actionId: action.id });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }
}
