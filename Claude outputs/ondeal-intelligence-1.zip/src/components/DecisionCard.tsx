"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { CheckCircle2, AlertTriangle, ArrowRight } from "lucide-react";
import type { RecommendationGroup } from "@/lib/intelligence/group";
import type { ActionStatus } from "@prisma/client";
import { SEVERITY_META } from "@/components/ui/severity";
import { isSensitiveActionType } from "@/lib/intelligence/actionTypes";
import { derivePhaseFromExistingAction, type DecisionPhase } from "@/lib/intelligence/decision";
import { simulatePriceChange, simulateRestock } from "@/lib/intelligence/simulate";
import Badge from "@/components/ui/Badge";
import Button from "@/components/ui/Button";

type PricePayload = {
  productId: string;
  variantId: string;
  currentPrice: number | null;
  supplierCost: number | null;
  shippingCost: number | null;
  paymentFeesRate: number | null;
  otherFixedCost: number | null;
};
type StockPayload = { variantId: string; storeStock: number | null; dailyVelocity: number | null };

export interface SerializedActionItem {
  id: string;
  type: string;
  sensitivity: "SENSITIVE" | "SAFE";
  status: ActionStatus;
  payload: Record<string, unknown>;
  resultJson: string | null;
  createdAt: string;
  confirmedAt: string | null;
  executedAt: string | null;
}

const CATEGORY_LABEL: Record<string, string> = {
  stock: "Stock",
  margin: "Marge",
  reviews: "Avis",
  marketing: "Marketing",
  data_quality: "Qualité des données",
  content: "Contenu produit",
};

function fmtDate(iso: string | null): string {
  return iso ? new Date(iso).toLocaleString("fr-FR") : "—";
}

/**
 * Decision Workspace — ferme la boucle complète du Command Center sans
 * changer de page : SIGNAL → POURQUOI → SIMULATION → DÉCISION → VALIDATION
 * → EXÉCUTION → RÉSULTAT.
 *
 * Ne réimplémente RIEN du moteur existant : réutilise tel quel
 * /api/actions (préparation), /api/actions/[id]/confirm (validation
 * humaine), /api/actions/[id]/execute (exécution réelle, mutation Shopify,
 * audit). Réutilise analyzeMargin/analyzeStock via simulatePriceChange /
 * simulateRestock — aucune nouvelle formule.
 *
 * Reprend l'état exact d'une ActionItem déjà préparée pour cette
 * recommandation (passée en prop `existingAction`) plutôt que de repartir
 * de zéro — évite de créer une deuxième ActionItem pour la même décision si
 * la page est rechargée avant confirmation/exécution.
 */
export default function DecisionCard({
  group,
  storeId,
  existingAction = null,
}: {
  group: RecommendationGroup;
  storeId: string;
  existingAction?: SerializedActionItem | null;
}) {
  const meta = SEVERITY_META[group.severity as keyof typeof SEVERITY_META] ?? SEVERITY_META.SUGGESTION;
  const Icon = meta.icon;
  const router = useRouter();
  const { representative, items } = group;
  const singleton = items.length === 1;

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [phase, setPhase] = useState<DecisionPhase>(() => derivePhaseFromExistingAction(existingAction));
  const [actionId, setActionId] = useState<string | null>(existingAction?.id ?? null);
  const [sensitive, setSensitive] = useState(existingAction ? existingAction.sensitivity === "SENSITIVE" : false);
  const [result, setResult] = useState<{ detail: string; verification?: string } | null>(
    existingAction?.resultJson ? (JSON.parse(existingAction.resultJson) as { detail: string; verification?: string }) : null,
  );
  const [resultAt, setResultAt] = useState<string | null>(existingAction?.executedAt ?? null);

  const payload: Record<string, unknown> | null = representative.actionPayloadJson
    ? (JSON.parse(representative.actionPayloadJson) as Record<string, unknown>)
    : null;

  const isPriceSim = singleton && representative.actionType === "update_price" && !!payload;
  const isRestockSim = singleton && representative.actionType === "review_supplier" && !!payload && "dailyVelocity" in (payload ?? {});
  const canSimulate = isPriceSim || isRestockSim;

  const pricePayload = isPriceSim ? (payload as unknown as PricePayload) : null;
  const stockPayload = isRestockSim ? (payload as unknown as StockPayload) : null;

  const [candidatePrice, setCandidatePrice] = useState(() => {
    if (existingAction?.payload && typeof existingAction.payload.newPrice === "number") return String(existingAction.payload.newPrice);
    return pricePayload?.currentPrice != null ? String(pricePayload.currentPrice) : "";
  });
  const [candidateUnits, setCandidateUnits] = useState("");

  // Simulation calculée en direct (fonction pure, pas d'appel réseau) —
  // jamais stockée séparément pour ne jamais afficher un résultat qui ne
  // correspond plus à l'entrée courante.
  const priceSim =
    isPriceSim && pricePayload && candidatePrice.trim() !== ""
      ? simulatePriceChange({
          productId: pricePayload.productId,
          variantId: pricePayload.variantId,
          title: representative.title,
          currentPrice: pricePayload.currentPrice,
          supplierCost: pricePayload.supplierCost,
          shippingCost: pricePayload.shippingCost,
          paymentFeesRate: pricePayload.paymentFeesRate,
          otherFixedCost: pricePayload.otherFixedCost,
          candidatePrice: Number(candidatePrice),
        })
      : null;
  const restockSim =
    isRestockSim && stockPayload && candidateUnits.trim() !== ""
      ? simulateRestock({
          currentStock: stockPayload.storeStock,
          dailyVelocity: stockPayload.dailyVelocity,
          candidateAddedUnits: Number(candidateUnits),
        })
      : null;

  const dataPoints: Array<{ label: string; value: string }> = [];
  if (pricePayload) {
    dataPoints.push({ label: "Prix actuel", value: pricePayload.currentPrice != null ? `${pricePayload.currentPrice.toFixed(2)} €` : "N/D" });
    dataPoints.push({ label: "Coût fournisseur", value: pricePayload.supplierCost != null ? `${pricePayload.supplierCost.toFixed(2)} €` : "N/D" });
    dataPoints.push({ label: "Frais d'expédition", value: pricePayload.shippingCost != null ? `${pricePayload.shippingCost.toFixed(2)} €` : "N/D" });
  } else if (stockPayload) {
    dataPoints.push({ label: "Stock actuel", value: stockPayload.storeStock != null ? `${stockPayload.storeStock} unité(s)` : "N/D" });
    dataPoints.push({
      label: "Vélocité de vente",
      value:
        stockPayload.dailyVelocity != null
          ? `≈ ${(stockPayload.dailyVelocity * 7).toFixed(1)} ventes / 7 j (moy. 30 j)`
          : "Inconnue — pas d'historique de ventes",
    });
  }
  dataPoints.push({ label: "Confiance OnDeal", value: `${group.confidence}%` });

  async function dismissAll() {
    setBusy(true);
    await Promise.all(items.map((r) => fetch(`/api/recommendations/${r.id}/dismiss`, { method: "POST" })));
    setBusy(false);
    router.refresh();
  }

  async function prepareAction() {
    if (!representative.actionType) return;
    setBusy(true);
    setError(null);
    const res = await fetch("/api/actions", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ storeId, recommendationId: representative.id }),
    });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok || !data.ok) {
      setError(data.error ?? "Échec de préparation de l'action.");
      return;
    }
    setActionId(data.actionId);
    const isSensitive = isSensitiveActionType(representative.actionType);
    setSensitive(isSensitive);
    if (isSensitive) {
      setPhase("confirm");
    } else {
      await executeNow(data.actionId);
    }
  }

  async function confirmAndExecute() {
    if (!actionId) return;
    setBusy(true);
    setError(null);
    const params: Record<string, unknown> = {};
    if (representative.actionType === "update_price") {
      const price = priceSim && priceSim.available ? priceSim.after.sellingPrice : Number(candidatePrice);
      if (!price || Number(price) <= 0) {
        setError("Indiquez un prix candidat valide avant de confirmer.");
        setBusy(false);
        return;
      }
      params.newPrice = Number(price);
    }
    const confirmRes = await fetch(`/api/actions/${actionId}/confirm`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ params }),
    });
    const confirmData = await confirmRes.json().catch(() => ({}));
    if (!confirmRes.ok) {
      setError(confirmData.error ?? "Échec de confirmation.");
      setBusy(false);
      return;
    }
    await executeNow(actionId);
  }

  async function executeNow(id: string) {
    setBusy(true);
    setError(null);
    const res = await fetch(`/api/actions/${id}/execute`, { method: "POST" });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    setResultAt(new Date().toISOString());
    if (!res.ok || !data.ok) {
      setResult({ detail: data.error ?? data.detail ?? "Échec d'exécution." });
      setPhase("done-failed");
      return;
    }
    setResult({ detail: data.detail, verification: data.verification });
    setPhase("done-success");
    // Rafraîchit les données serveur (compteurs, historique) sans faire
    // disparaître ce panneau : le résultat reste affiché tel quel, seule la
    // recommandation quitte la liste « Priorités du jour » à la prochaine
    // navigation puisqu'elle est désormais ACTIONED.
    router.refresh();
  }

  function retryAfterFailure() {
    setPhase("signal");
    setActionId(null);
    setResult(null);
    setError(null);
  }

  return (
    <div className={`priority-card ${meta.cls}`}>
      <div className="priority-card-icon">
        <Icon size={17} strokeWidth={2} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        {/* SIGNAL */}
        <div className="decision-section-label">Signal</div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4, flexWrap: "wrap" }}>
          <Badge tone={meta.tone}>{meta.label}</Badge>
          <Badge tone="neutral">{CATEGORY_LABEL[representative.category] ?? representative.category}</Badge>
          {items.length > 1 && <span className="priority-card-group-count">{items.length} recommandations groupées</span>}
        </div>
        <div style={{ fontWeight: 700, fontSize: 14.5 }}>{group.title}</div>
        {group.product && <div style={{ fontSize: 12.5, color: "var(--color-text-faint)", marginTop: 2 }}>Produit : {group.product.title}</div>}

        {phase !== "done-success" && phase !== "done-failed" && (
          <>
            {/* POURQUOI */}
            <div className="decision-section">
              <div className="decision-section-label">Pourquoi</div>
              {dataPoints.length > 0 && (
                <div className="decision-data-points">
                  {dataPoints.map((d) => (
                    <div className="decision-data-point" key={d.label}>
                      <span className="decision-data-point-label">{d.label}</span>
                      <span className="decision-data-point-value">{d.value}</span>
                    </div>
                  ))}
                </div>
              )}
              <div style={{ fontSize: 13.5, color: "var(--color-text-muted)" }}>
                {representative.reason}
                {items.length > 1 ? ` (exemple sur ${items.length} au total)` : ""}
              </div>
              <div style={{ fontSize: 13.5, color: "var(--color-text-muted)", marginTop: 2 }}>
                <strong>Impact potentiel :</strong> {representative.impact}
              </div>
            </div>

            {/* SIMULATION */}
            {singleton && representative.actionType && (
              <div className="decision-section">
                <div className="decision-section-label">Simulation</div>
                {canSimulate ? (
                  <div className="decision-sim">
                    {isPriceSim && (
                      <div className="field">
                        <label>Prix candidat (€)</label>
                        <input
                          className="input"
                          type="number"
                          step="0.01"
                          value={candidatePrice}
                          disabled={phase !== "signal" && phase !== "confirm"}
                          onChange={(e) => setCandidatePrice(e.target.value)}
                        />
                      </div>
                    )}
                    {isRestockSim && (
                      <div className="field">
                        <label>Unités reçues (simulation)</label>
                        <input
                          className="input"
                          type="number"
                          step="1"
                          placeholder="ex. 20"
                          value={candidateUnits}
                          disabled={phase !== "signal" && phase !== "confirm"}
                          onChange={(e) => setCandidateUnits(e.target.value)}
                        />
                      </div>
                    )}

                    {isPriceSim &&
                      (priceSim ? (
                        priceSim.available ? (
                          <>
                            <div className="decision-sim-row">
                              <div className="decision-sim-col">
                                <div className="decision-sim-col-label">Avant</div>
                                <div className="decision-sim-col-value">
                                  {priceSim.before.margin !== null ? `${priceSim.before.margin.toFixed(2)} €` : "N/D"}
                                </div>
                              </div>
                              <ArrowRight size={16} className="decision-sim-arrow" />
                              <div className="decision-sim-col action">
                                <div className="decision-sim-col-label">Action</div>
                                <div className="decision-sim-col-value">{Number(candidatePrice).toFixed(2)} €</div>
                              </div>
                              <ArrowRight size={16} className="decision-sim-arrow" />
                              <div className="decision-sim-col">
                                <div className="decision-sim-col-label">Après</div>
                                <div className="decision-sim-col-value">{priceSim.after.margin!.toFixed(2)} €</div>
                              </div>
                            </div>
                            {priceSim.deltaMargin !== null && (
                              <div className={`decision-sim-impact ${priceSim.deltaMargin >= 0 ? "positive" : "negative"}`}>
                                Impact : {priceSim.deltaMargin >= 0 ? "+" : ""}
                                {priceSim.deltaMargin.toFixed(2)} € de marge par vente
                                {priceSim.deltaMarginRate !== null
                                  ? ` (${priceSim.deltaMarginRate >= 0 ? "+" : ""}${(priceSim.deltaMarginRate * 100).toFixed(1)} pt)`
                                  : ""}
                              </div>
                            )}
                          </>
                        ) : (
                          <p className="decision-sim-hint">{priceSim.reason}</p>
                        )
                      ) : (
                        <p className="decision-sim-hint">Indiquez un prix candidat pour voir l&apos;impact réel sur la marge.</p>
                      ))}

                    {isRestockSim &&
                      (restockSim ? (
                        restockSim.available ? (
                          <>
                            <div className="decision-sim-row">
                              <div className="decision-sim-col">
                                <div className="decision-sim-col-label">Avant</div>
                                <div className="decision-sim-col-value">{stockPayload?.storeStock ?? 0} unités</div>
                              </div>
                              <ArrowRight size={16} className="decision-sim-arrow" />
                              <div className="decision-sim-col action">
                                <div className="decision-sim-col-label">Action</div>
                                <div className="decision-sim-col-value">+{candidateUnits} unités</div>
                              </div>
                              <ArrowRight size={16} className="decision-sim-arrow" />
                              <div className="decision-sim-col">
                                <div className="decision-sim-col-label">Après</div>
                                <div className="decision-sim-col-value">{restockSim.projectedStock} unités</div>
                              </div>
                            </div>
                            {restockSim.projectedDaysOfStock !== null && (
                              <div className="decision-sim-impact positive">
                                Impact : ≈ {Math.round(restockSim.projectedDaysOfStock)} jour(s) de couverture
                              </div>
                            )}
                          </>
                        ) : (
                          <p className="decision-sim-hint">{restockSim.reason}</p>
                        )
                      ) : (
                        <p className="decision-sim-hint">Indiquez une quantité pour voir la couverture de stock projetée.</p>
                      ))}
                  </div>
                ) : (
                  <p className="unavailable-note">Impact chiffré non disponible pour ce type de recommandation.</p>
                )}
              </div>
            )}

            {phase === "confirm" && (
              <div className="callout callout-warning" style={{ marginTop: 10, padding: 10, fontSize: 12.5 }}>
                Cette action va modifier votre boutique. Vous pouvez encore ajuster la valeur ci-dessus avant de confirmer.
              </div>
            )}
            {phase === "ready-execute" && (
              <div className="callout callout-info" style={{ marginTop: 10, padding: 10, fontSize: 12.5 }}>
                Action préparée{existingAction?.confirmedAt ? " et confirmée" : ""} — prête à être exécutée.
              </div>
            )}
          </>
        )}

        {/* RÉSULTAT */}
        {phase === "done-success" && result && (
          <div className="decision-result decision-result-success">
            <div className="decision-result-title">
              <CheckCircle2 size={16} /> Action exécutée
            </div>
            <div className="decision-result-detail">{result.detail}</div>
            {result.verification && <div className="decision-result-detail">Vérification : {result.verification}</div>}
            <div className="decision-result-meta">
              Statut : EXECUTED — {fmtDate(resultAt)}
            </div>
          </div>
        )}
        {phase === "done-failed" && result && (
          <div className="decision-result decision-result-failed">
            <div className="decision-result-title">
              <AlertTriangle size={16} /> Action non exécutée
            </div>
            <div className="decision-result-detail">{result.detail}</div>
            <div className="decision-result-meta">Statut : FAILED — {fmtDate(resultAt)}</div>
          </div>
        )}

        {error && <div className="callout callout-error" style={{ marginTop: 8, marginBottom: 0 }}>{error}</div>}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 150 }}>
        {phase === "signal" && singleton && representative.actionLabel && representative.actionType && (
          <Button variant="primary" size="sm" disabled={busy} onClick={prepareAction}>
            {busy ? "…" : "Décider"}
          </Button>
        )}
        {phase === "confirm" && (
          <Button variant="primary" size="sm" disabled={busy} onClick={confirmAndExecute}>
            {busy ? "…" : "Confirmer l'action"}
          </Button>
        )}
        {phase === "ready-execute" && (
          <Button variant="primary" size="sm" disabled={busy} onClick={() => actionId && executeNow(actionId)}>
            {busy ? "…" : "Exécuter maintenant"}
          </Button>
        )}
        {phase === "done-failed" && (
          <Button variant="secondary" size="sm" disabled={busy} onClick={retryAfterFailure}>
            Réessayer
          </Button>
        )}
        {(phase === "signal" || phase === "confirm") && (
          <Button variant="secondary" size="sm" disabled={busy} onClick={dismissAll}>
            {items.length > 1 ? `Ignorer les ${items.length}` : "Ignorer"}
          </Button>
        )}
      </div>
    </div>
  );
}
