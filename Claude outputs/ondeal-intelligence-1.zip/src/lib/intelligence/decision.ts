import type { ActionStatus } from "@prisma/client";

/**
 * Boucle de décision — logique pure partagée entre le serveur et le client.
 *
 * Ne remplace ni ne duplique le moteur d'exécution existant
 * (/api/actions, /api/actions/[id]/confirm, /api/actions/[id]/execute) :
 * ces deux fonctions servent uniquement à (1) reprendre proprement une
 * décision déjà entamée au lieu d'en recréer une en double, et (2) refuser
 * d'appliquer une simulation devenue obsolète juste avant la mutation
 * réelle.
 */

export type DecisionPhase = "signal" | "confirm" | "ready-execute" | "done-success" | "done-failed";

export interface ExistingActionLike {
  status: ActionStatus;
  sensitivity: "SENSITIVE" | "SAFE";
}

/**
 * Dérive la phase d'affichage de la Decision Card à partir de l'ActionItem
 * le plus récent déjà existant pour cette recommandation, s'il y en a un.
 * Sans cette reprise, recharger la page (ou revenir plus tard) sur une
 * recommandation déjà préparée permettrait de cliquer à nouveau sur
 * « Décider » et de créer une deuxième ActionItem pour la même décision.
 */
export function derivePhaseFromExistingAction(action: ExistingActionLike | null): DecisionPhase {
  if (!action) return "signal";
  switch (action.status) {
    case "PENDING_VALIDATION":
      // Une action SAFE ne nécessite aucune confirmation humaine (déjà le
      // comportement du moteur d'exécution) : elle est directement prête à
      // exécuter. Une action SENSITIVE reprend à l'étape de confirmation.
      return action.sensitivity === "SENSITIVE" ? "confirm" : "ready-execute";
    case "CONFIRMED":
      return "ready-execute";
    case "EXECUTED":
      return "done-success";
    case "FAILED":
      return "done-failed";
    case "CANCELLED":
    default:
      return "signal";
  }
}

/**
 * Vérifie que le prix local connu au moment de l'exécution correspond bien
 * à celui utilisé pour la simulation/décision — pour ne jamais appliquer
 * aveuglément un changement calculé sur une donnée devenue obsolète (ex. une
 * synchronisation Shopify a mis à jour le prix entre-temps). Une tolérance
 * d'un centime absorbe les seules imprécisions flottantes, pas un vrai écart.
 */
export function isPriceStale(expectedPrice: number | null, currentPrice: number | null, toleranceCents = 1): boolean {
  if (expectedPrice === null || currentPrice === null) return false;
  return Math.abs(expectedPrice - currentPrice) * 100 > toleranceCents;
}
