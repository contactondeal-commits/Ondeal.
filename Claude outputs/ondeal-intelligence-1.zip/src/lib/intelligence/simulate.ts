import { analyzeMargin } from "@/lib/intelligence/margin";
import type { MarginAnalysis } from "@/types";

/**
 * Simulation — étape "et si ?" entre Décision et Action. Ne recalcule
 * JAMAIS avec une formule inédite : réutilise exactement les mêmes fonctions
 * pures que les modules Marge/Stock déjà validés (`analyzeMargin`), pour que
 * "simuler" et "ce qui sera réellement vrai après l'action" restent
 * garantis identiques. Quand une hypothèse manque, la simulation est
 * explicitement indisponible — jamais un nombre approché à sa place.
 */

export interface PriceSimulationInput {
  productId: string;
  variantId: string;
  title: string;
  currentPrice: number | null;
  supplierCost: number | null;
  shippingCost: number | null;
  paymentFeesRate: number | null;
  otherFixedCost: number | null;
  candidatePrice: number;
}

export type PriceSimulationResult =
  | {
      available: true;
      before: MarginAnalysis;
      after: MarginAnalysis;
      deltaMargin: number | null;
      deltaMarginRate: number | null;
    }
  | { available: false; reason: string };

export function simulatePriceChange(input: PriceSimulationInput): PriceSimulationResult {
  if (!Number.isFinite(input.candidatePrice) || input.candidatePrice <= 0) {
    return { available: false, reason: "Indiquez un prix candidat valide (supérieur à 0)." };
  }

  const baseInput = {
    productId: input.productId,
    variantId: input.variantId,
    title: input.title,
    supplierCost: input.supplierCost,
    shippingCost: input.shippingCost,
    paymentFeesRate: input.paymentFeesRate,
    otherFixedCost: input.otherFixedCost,
  };

  const before = analyzeMargin({ ...baseInput, sellingPrice: input.currentPrice });
  const after = analyzeMargin({ ...baseInput, sellingPrice: input.candidatePrice });

  if (after.margin === null) {
    const missing = after.missingAssumptions.filter((m) => m !== "sellingPrice");
    return {
      available: false,
      reason:
        missing.length > 0
          ? `Simulation impossible : hypothèse(s) de coût manquante(s) (${missing.join(", ")}). Renseignez-les dans Prix & Marge pour simuler.`
          : "Simulation impossible avec les données actuelles.",
    };
  }

  return {
    available: true,
    before,
    after,
    deltaMargin: before.margin !== null && after.margin !== null ? after.margin - before.margin : null,
    deltaMarginRate:
      before.marginRate !== null && after.marginRate !== null ? after.marginRate - before.marginRate : null,
  };
}

export interface RestockSimulationInput {
  currentStock: number | null;
  dailyVelocity: number | null;
  candidateAddedUnits: number;
}

export type RestockSimulationResult =
  | { available: true; projectedStock: number; projectedDaysOfStock: number | null }
  | { available: false; reason: string };

export function simulateRestock(input: RestockSimulationInput): RestockSimulationResult {
  if (!Number.isFinite(input.candidateAddedUnits) || input.candidateAddedUnits <= 0) {
    return { available: false, reason: "Indiquez une quantité à recevoir valide (supérieure à 0)." };
  }
  if (input.currentStock === null) {
    return { available: false, reason: "Stock boutique actuel inconnu — impossible de simuler le réapprovisionnement." };
  }
  const projectedStock = input.currentStock + input.candidateAddedUnits;
  if (input.dailyVelocity === null) {
    return {
      available: false,
      reason: "Aucune vitesse de vente connue (pas d'historique de ventes) — le stock projeté est calculable mais pas la durée.",
    };
  }
  if (input.dailyVelocity === 0) {
    return { available: false, reason: "Aucune vente récente enregistrée — durée de stock non estimable après réapprovisionnement." };
  }
  return { available: true, projectedStock, projectedDaysOfStock: projectedStock / input.dailyVelocity };
}
