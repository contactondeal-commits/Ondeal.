import { describe, it, expect } from "vitest";
import { derivePhaseFromExistingAction, isPriceStale } from "@/lib/intelligence/decision";

describe("derivePhaseFromExistingAction", () => {
  it("part de 'signal' quand aucune action n'existe encore", () => {
    expect(derivePhaseFromExistingAction(null)).toBe("signal");
  });

  it("reprend à 'confirm' pour une action SENSITIVE en attente de validation (jamais recréée en double)", () => {
    expect(derivePhaseFromExistingAction({ status: "PENDING_VALIDATION", sensitivity: "SENSITIVE" })).toBe("confirm");
  });

  it("reprend à 'ready-execute' pour une action SAFE en attente (aucune confirmation humaine requise)", () => {
    expect(derivePhaseFromExistingAction({ status: "PENDING_VALIDATION", sensitivity: "SAFE" })).toBe("ready-execute");
  });

  it("reprend à 'ready-execute' pour toute action déjà CONFIRMED", () => {
    expect(derivePhaseFromExistingAction({ status: "CONFIRMED", sensitivity: "SENSITIVE" })).toBe("ready-execute");
    expect(derivePhaseFromExistingAction({ status: "CONFIRMED", sensitivity: "SAFE" })).toBe("ready-execute");
  });

  it("affiche l'état terminal pour EXECUTED et FAILED", () => {
    expect(derivePhaseFromExistingAction({ status: "EXECUTED", sensitivity: "SAFE" })).toBe("done-success");
    expect(derivePhaseFromExistingAction({ status: "FAILED", sensitivity: "SENSITIVE" })).toBe("done-failed");
  });

  it("repart de 'signal' pour une action annulée", () => {
    expect(derivePhaseFromExistingAction({ status: "CANCELLED", sensitivity: "SAFE" })).toBe("signal");
  });
});

describe("isPriceStale", () => {
  it("détecte un écart réel de prix entre la simulation et l'exécution", () => {
    expect(isPriceStale(19.9, 24.5)).toBe(true);
  });

  it("tolère les imprécisions flottantes négligeables (moins d'un centime)", () => {
    expect(isPriceStale(19.9, 19.900001)).toBe(false);
  });

  it("ne bloque pas quand une des deux valeurs est inconnue (rien à comparer)", () => {
    expect(isPriceStale(null, 19.9)).toBe(false);
    expect(isPriceStale(19.9, null)).toBe(false);
  });

  it("n'est pas obsolète quand le prix n'a pas changé", () => {
    expect(isPriceStale(19.9, 19.9)).toBe(false);
  });
});
