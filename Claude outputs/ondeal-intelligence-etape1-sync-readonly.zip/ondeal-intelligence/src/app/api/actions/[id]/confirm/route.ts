import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireStoreAccess, AuthError } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { buildPriceSnapshot } from "@/lib/intelligence/snapshot";

// PHASE 13 — étape de validation humaine explicite, distincte de l'exécution.
// "Cette action va modifier votre boutique." → Annuler / Confirmer.
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const action = await prisma.actionItem.findUnique({ where: { id } });
  if (!action) return NextResponse.json({ error: "Action introuvable." }, { status: 404 });

  const body = await req.json().catch(() => ({}));

  try {
    const { userId } = await requireStoreAccess(action.storeId);
    if (action.status !== "PENDING_VALIDATION") {
      return NextResponse.json({ error: `Action déjà au statut ${action.status}.` }, { status: 409 });
    }

    // Pour les actions de type "update_price" / "update_stock", le nouveau
    // prix/stock est saisi par l'humain au moment de la validation — jamais
    // décidé automatiquement par le moteur de recommandations.
    const existingPayload = JSON.parse(action.payloadJson) as Record<string, unknown>;
    let mergedPayload: Record<string, unknown> = { ...existingPayload, ...(body?.params ?? {}) };

    // SNAPSHOT DE SIMULATION (priorité absolue) — capturé ICI, côté serveur,
    // à partir de données rechargées fraîchement en base (jamais celles
    // envoyées par le client, qui peuvent dater de l'ouverture de la page).
    // C'est ce snapshot que /api/actions/[id]/execute comparera aux données
    // réelles juste avant la mutation Shopify, pour refuser d'exécuter une
    // décision calculée sur une donnée devenue obsolète entre-temps.
    if (action.type === "update_price") {
      const productId = mergedPayload.productId as string | undefined;
      const variantId = mergedPayload.variantId as string | undefined;
      const newPrice = Number(mergedPayload.newPrice);
      if (productId && variantId && Number.isFinite(newPrice) && newPrice > 0) {
        const [variant, costAssumption] = await Promise.all([
          prisma.variant.findUnique({ where: { id: variantId } }),
          prisma.costAssumption.findUnique({ where: { productId } }),
        ]);
        if (variant) {
          mergedPayload = {
            ...mergedPayload,
            simulationSnapshot: buildPriceSnapshot({
              productId,
              variantId,
              candidateValue: newPrice,
              fields: {
                currentPrice: variant.price,
                supplierCost: costAssumption?.supplierCost ?? null,
                shippingCost: costAssumption?.shippingCost ?? null,
                paymentFeesRate: costAssumption?.paymentFeesRate ?? null,
                otherFixedCost: costAssumption?.otherFixedCost ?? null,
              },
            }),
          };
        }
      }
    }

    const updated = await prisma.actionItem.update({
      where: { id },
      data: { status: "CONFIRMED", confirmedAt: new Date(), payloadJson: JSON.stringify(mergedPayload) },
    });
    await logAudit({
      storeId: action.storeId,
      userId,
      actorType: "user",
      event: "action.confirmed",
      message: `Action confirmée par l'utilisateur (type: ${action.type}).`,
      meta: { actionId: id },
    });
    return NextResponse.json({ ok: true, action: updated });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }
}
