import { FlaskConical } from "lucide-react";
import type { ResolvedStore } from "@/lib/store-context";
import { hasFeature } from "@/lib/plan-limits";
import Sidebar, { type NavGroup } from "@/components/Sidebar";
import StoreChip from "@/components/StoreChip";
import CommandBar from "@/components/CommandBar";

// Déclaré avec une clé de fonctionnalité optionnelle (résolue côté serveur
// selon le plan de l'organisation, jamais transmise telle quelle à Sidebar —
// un Client Component ne peut pas recevoir de fonction en prop).
const NAV_GROUPS_SOURCE: Array<{ label: string; items: Array<{ href: string; label: string; feature?: string }> }> = [
  {
    label: "Command Center",
    items: [{ href: "/dashboard", label: "Command Center" }],
  },
  {
    label: "Intelligence",
    items: [
      { href: "/intelligence", label: "Centre d'intelligence" },
      { href: "/products", label: "Product Intelligence" },
      { href: "/stock", label: "Stock Intelligence" },
      { href: "/reviews", label: "Review Intelligence" },
    ],
  },
  {
    label: "Croissance",
    items: [
      { href: "/pricing", label: "Prix & Marge", feature: "pricing" },
      { href: "/marketing", label: "Marketing Intelligence", feature: "marketing" },
    ],
  },
  {
    label: "Copilot",
    items: [{ href: "/assistant", label: "Copilot", feature: "assistant" }],
  },
  {
    label: "Opérations",
    items: [
      { href: "/actions", label: "Actions" },
      { href: "/audit-log", label: "Historique" },
    ],
  },
  {
    label: "Paramètres",
    items: [{ href: "/settings", label: "Paramètres" }],
  },
];

const FLAT_NAV = NAV_GROUPS_SOURCE.flatMap((g) => g.items.map((i) => ({ href: i.href, label: i.label, group: g.label })));

export default function AppShell({
  store,
  active,
  children,
  headerExtra,
}: {
  store: ResolvedStore;
  active: string;
  children: React.ReactNode;
  /** Contenu additionnel affiché à droite du header (ex: bouton de synchronisation) */
  headerExtra?: React.ReactNode;
}) {
  const groups: NavGroup[] = NAV_GROUPS_SOURCE.map((g) => ({
    label: g.label,
    items: g.items.map((i) => ({ href: i.href, label: i.label, enabled: !i.feature || hasFeature(store.plan, i.feature) })),
  }));

  return (
    <div className="shell">
      <Sidebar
        groups={groups}
        active={active}
        storeId={store.id}
        storeName={store.name}
        plan={store.plan}
        organizationName={store.organizationName}
        stores={store.allStores}
      />
      <main className="main">
        <div className="app-header">
          <StoreChip
            name={store.name}
            shopifyConnected={store.integrations.shopifyConnected}
            judgemeConnected={store.integrations.judgemeConnected}
            lastSyncedAt={store.integrations.lastSyncedAt}
            isDemo={store.isDemo}
          />
          <CommandBar
            navItems={FLAT_NAV}
            storeId={store.id}
            canSync={!store.isDemo && (store.integrations.shopifyConnected || store.integrations.judgemeConnected)}
          />
          <div className="header-right">{headerExtra}</div>
        </div>

        {store.isDemo && (
          <div className="callout callout-warning" style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <FlaskConical size={16} style={{ flexShrink: 0 }} />
            <span>
              <strong>Données de démonstration</strong> — cette boutique contient des données fictives, à but
              d&apos;exploration uniquement. Elles ne sont jamais mélangées à une boutique réelle.
            </span>
          </div>
        )}
        {children}
      </main>
    </div>
  );
}
