"use client";

import { useRouter } from "next/navigation";
import { LogOut } from "lucide-react";

export default function LogoutButton() {
  const router = useRouter();
  return (
    <button
      className="sidebar-link"
      style={{ width: "100%", border: "none", background: "transparent", cursor: "pointer", textAlign: "left" }}
      onClick={async () => {
        await fetch("/api/auth/logout", { method: "POST" });
        router.push("/login");
        router.refresh();
      }}
    >
      <span><LogOut size={15} strokeWidth={2} /></span>
      <span className="sidebar-link-label">Déconnexion</span>
    </button>
  );
}
