"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, ChevronDown } from "lucide-react";
import StoreSwitcher from "@/components/StoreSwitcher";
import LogoutButton from "@/components/LogoutButton";
import { NAV_ICONS } from "@/components/icons";

export interface NavItem {
  href: string;
  label: string;
  /** Résolu côté serveur (plan de l'organisation) — jamais une fonction, pour rester sérialisable vers ce Client Component. */
  enabled: boolean;
}
export interface NavGroup {
  label: string;
  items: NavItem[];
}

const COLLAPSE_KEY = "ondeal.sidebar.collapsed";
const GROUPS_KEY = "ondeal.sidebar.closedGroups";

export default function Sidebar({
  groups,
  active,
  storeId,
  storeName,
  plan,
  organizationName,
  stores,
}: {
  groups: NavGroup[];
  active: string;
  storeId: string;
  storeName: string;
  plan: string;
  organizationName: string;
  stores: Array<{ id: string; name: string; isDemo: boolean }>;
}) {
  const [collapsed, setCollapsed] = useState(false);
  const [closedGroups, setClosedGroups] = useState<Set<string>>(new Set());
  const [hydrated, setHydrated] = useState(false);

  // Préférence purement d'affichage, par navigateur — jamais de donnée
  // métier ici. Restaurée après le premier rendu pour éviter tout écart
  // serveur/client (SSR n'a pas accès à localStorage) : on rend volontairement
  // l'état par défaut au premier rendu client, puis on hydrate une seule fois.
  useEffect(() => {
    try {
      const storedCollapsed = window.localStorage.getItem(COLLAPSE_KEY);
      // eslint-disable-next-line react-hooks/set-state-in-effect -- hydratation post-SSR à exécution unique, pas une synchronisation continue.
      if (storedCollapsed === "1") setCollapsed(true);
      const storedGroups = window.localStorage.getItem(GROUPS_KEY);
      if (storedGroups) setClosedGroups(new Set(JSON.parse(storedGroups)));
    } catch {
      // localStorage indisponible (navigation privée, etc.) — on garde les valeurs par défaut.
    }
    setHydrated(true);
  }, []);

  function persistCollapsed(next: boolean) {
    setCollapsed(next);
    try {
      window.localStorage.setItem(COLLAPSE_KEY, next ? "1" : "0");
    } catch {
      // ignore
    }
  }

  function toggleGroup(label: string) {
    setClosedGroups((prev) => {
      const next = new Set(prev);
      if (next.has(label)) next.delete(label);
      else next.add(label);
      try {
        window.localStorage.setItem(GROUPS_KEY, JSON.stringify([...next]));
      } catch {
        // ignore
      }
      return next;
    });
  }

  return (
    <aside className={`sidebar ${collapsed ? "is-collapsed" : ""}`} style={hydrated ? undefined : { transition: "none" }}>
      <div className="sidebar-brand">
        <span aria-hidden style={{ fontWeight: 800, fontSize: 13 }}>
          OD
        </span>
        <span className="sidebar-brand-label" style={{ flex: 1 }}>
          OnDeal Intelligence
        </span>
        <button
          type="button"
          className="sidebar-collapse-btn"
          onClick={() => persistCollapsed(!collapsed)}
          title={collapsed ? "Étendre le menu" : "Réduire le menu"}
          aria-label={collapsed ? "Étendre le menu" : "Réduire le menu"}
        >
          {collapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
        </button>
      </div>

      {!collapsed && <StoreSwitcher currentStoreId={storeId} stores={stores} />}

      {groups.map((group) => {
        const isClosed = closedGroups.has(group.label);
        return (
          <div className="sidebar-group" key={group.label}>
            {!collapsed && (
              <button type="button" className="sidebar-group-toggle" onClick={() => toggleGroup(group.label)}>
                <span className="sidebar-section-label" style={{ padding: 0 }}>
                  {group.label}
                </span>
                <ChevronDown size={12} className={`sidebar-group-chevron ${!isClosed ? "is-open" : ""}`} />
              </button>
            )}
            <div className={`sidebar-group-items ${!collapsed && isClosed ? "is-closed" : ""}`}>
              {group.items.map((item) => {
                const Icon = NAV_ICONS[item.href];
                return (
                  <Link
                    key={item.href}
                    href={item.enabled ? `${item.href}?store=${storeId}` : "#"}
                    className={`sidebar-link ${active === item.href ? "active" : ""}`}
                    style={item.enabled ? undefined : { opacity: 0.4, cursor: "not-allowed", pointerEvents: "none" }}
                    title={collapsed ? item.label : item.enabled ? undefined : "Disponible à partir du plan Pro"}
                  >
                    <span>{Icon && <Icon size={15} strokeWidth={2} />}</span>
                    <span className="sidebar-link-label">{item.label}</span>
                  </Link>
                );
              })}
            </div>
          </div>
        );
      })}

      <div style={{ flex: 1 }} />
      <div className="sidebar-footer">
        <div className="sidebar-footer-text">
          Plan {plan} — {organizationName}
        </div>
      </div>
      <LogoutButton />
    </aside>
  );
}
