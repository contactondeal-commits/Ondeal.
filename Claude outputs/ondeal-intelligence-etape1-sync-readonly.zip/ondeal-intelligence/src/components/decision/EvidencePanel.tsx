export interface DataPoint {
  label: string;
  value: string;
}

/**
 * Section POURQUOI / EVIDENCE — présente les données réelles qui motivent
 * le signal, jamais interprétées ni recalculées ici (pur affichage).
 */
export default function EvidencePanel({
  dataPoints,
  reason,
  impact,
  groupCount,
}: {
  dataPoints: DataPoint[];
  reason: string;
  impact: string;
  groupCount: number;
}) {
  return (
    <div className="decision-section">
      <div className="decision-section-label">Pourquoi</div>
      {dataPoints.length > 0 && (
        <div className="decision-data-points">
          {dataPoints.map((d) => (
            <div className="decision-data-point" key={d.label}>
              <span className="decision-data-point-label">{d.label}</span>
              <span className="decision-data-point-value">{d.value}</span>
            </div>
          ))}
        </div>
      )}
      <div style={{ fontSize: 13.5, color: "var(--color-text-muted)" }}>
        {reason}
        {groupCount > 1 ? ` (exemple sur ${groupCount} au total)` : ""}
      </div>
      <div style={{ fontSize: 13.5, color: "var(--color-text-muted)", marginTop: 2 }}>
        <strong>Impact potentiel :</strong> {impact}
      </div>
    </div>
  );
}
