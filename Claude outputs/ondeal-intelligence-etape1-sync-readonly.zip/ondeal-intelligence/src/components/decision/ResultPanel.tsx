import { CheckCircle2, AlertTriangle, RefreshCw } from "lucide-react";
import Button from "@/components/ui/Button";

export interface DisplayResult {
  detail: string;
  kind?: string;
  verification?: string;
  before?: number | string | null;
  applied?: number | string;
  verified?: number | string;
  changedFields?: Array<{ field: string; label: string; expected: number | null; actual: number | null }>;
}

function fmtDate(iso: string | null): string {
  return iso ? new Date(iso).toLocaleString("fr-FR") : "—";
}

function fmtValue(v: number | string | null | undefined): string {
  if (v === null || v === undefined) return "—";
  return typeof v === "number" ? `${v.toFixed(2)} €` : String(v);
}

/**
 * Section RÉSULTAT — jamais un chiffre fictif. Distingue une ACTION
 * EXÉCUTÉE (mutation Shopify réelle, avant/appliqué/vérifié tous issus de
 * données réelles), une MISSION marquée comme effectuée par l'utilisateur
 * (aucune mutation), un refus pour SIMULATION OBSOLÈTE (ce qui a changé,
 * explicitement), et un échec ordinaire.
 */
export default function ResultPanel({
  phase,
  result,
  resultAt,
  onRetry,
}: {
  phase: "done-success" | "done-failed" | "stale";
  result: DisplayResult;
  resultAt: string | null;
  onRetry: () => void;
}) {
  if (phase === "done-success" && result.kind === "automated_mutation") {
    return (
      <div className="decision-result decision-result-success">
        <div className="decision-result-title">
          <CheckCircle2 size={16} /> Action exécutée
        </div>
        <div className="decision-result-grid">
          <div className="decision-result-field">
            <span>Avant</span>
            <strong>{fmtValue(result.before)}</strong>
          </div>
          <div className="decision-result-field">
            <span>Appliqué</span>
            <strong>{fmtValue(result.applied)}</strong>
          </div>
          <div className="decision-result-field">
            <span>Vérifié</span>
            <strong>{fmtValue(result.verified)}</strong>
          </div>
        </div>
        <div className="decision-result-detail">{result.detail}</div>
        {result.verification && <div className="decision-result-detail">Shopify vérifié — {result.verification}</div>}
        <div className="decision-result-meta">
          Exécuté le {fmtDate(resultAt)} — Recommandation résolue
        </div>
      </div>
    );
  }

  if (phase === "done-success" && result.kind === "manual_mission_completed") {
    return (
      <div className="decision-result decision-result-success">
        <div className="decision-result-title">
          <CheckCircle2 size={16} /> Mission marquée comme effectuée
        </div>
        <div className="decision-result-detail">{result.detail}</div>
        <div className="decision-result-meta">
          Confirmé le {fmtDate(resultAt)} — aucune mutation Shopify n&apos;a été effectuée par OnDeal pour ce type d&apos;action.
        </div>
      </div>
    );
  }

  if (phase === "stale") {
    return (
      <div className="decision-result decision-result-stale">
        <div className="decision-result-title">
          <RefreshCw size={16} /> Simulation obsolète — exécution refusée
        </div>
        <div className="decision-result-detail">{result.detail}</div>
        {result.changedFields && result.changedFields.length > 0 && (
          <div className="decision-result-grid">
            {result.changedFields.map((c) => (
              <div className="decision-result-field" key={c.field}>
                <span>{c.label}</span>
                <strong>
                  {c.expected ?? "—"} → {c.actual ?? "—"}
                </strong>
              </div>
            ))}
          </div>
        )}
        <div className="decision-result-meta">Refusé le {fmtDate(resultAt)} — aucune modification appliquée sur Shopify.</div>
        <Button variant="secondary" size="sm" style={{ marginTop: 8 }} onClick={onRetry}>
          Relancer une nouvelle simulation
        </Button>
      </div>
    );
  }

  // done-failed (échec ordinaire : Shopify indisponible, produit supprimé, etc.)
  return (
    <div className="decision-result decision-result-failed">
      <div className="decision-result-title">
        <AlertTriangle size={16} /> Action non exécutée
      </div>
      <div className="decision-result-detail">{result.detail}</div>
      <div className="decision-result-meta">Statut : FAILED — {fmtDate(resultAt)}</div>
    </div>
  );
}
