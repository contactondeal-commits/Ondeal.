import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireStoreAccess, AuthError } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { SENSITIVE_ACTION_TYPES } from "@/lib/intelligence/actionTypes";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const { storeId, recommendationId } = body ?? {};
  if (!storeId || !recommendationId) return NextResponse.json({ error: "storeId et recommendationId requis." }, { status: 400 });

  try {
    const { userId } = await requireStoreAccess(storeId);

    const rec = await prisma.recommendation.findUnique({ where: { id: recommendationId } });
    if (!rec || rec.storeId !== storeId) return NextResponse.json({ error: "Recommandation introuvable." }, { status: 404 });
    if (!rec.actionType) return NextResponse.json({ error: "Cette recommandation n'a pas d'action exécutable." }, { status: 400 });

    const sensitivity = SENSITIVE_ACTION_TYPES.has(rec.actionType) ? "SENSITIVE" : "SAFE";

    // Idempotence : « 1 recommandation active = 1 ActionItem actif ». Le
    // couple vérification-puis-création est exécuté dans une transaction
    // Prisma pour ne pas dépendre uniquement du frontend — double clic,
    // retry réseau, rechargement avant que l'UI ne reprenne son état, ou
    // deux appels concurrents à cette route pour la même recommandation
    // doivent tous retomber sur le même ActionItem plutôt que d'en créer un
    // deuxième. (Limite honnête : SQLite ne sérialise pas des transactions
    // concurrentes avec la même garantie qu'un index unique partiel côté
    // base — une vraie contrainte DB nécessiterait une migration SQL brute,
    // volontairement non ajoutée ici pour ne pas modifier le schéma sans
    // nécessité réelle avérée.)
    const { action, resumed } = await prisma.$transaction(async (tx) => {
      const active = await tx.actionItem.findFirst({
        where: { recommendationId, status: { in: ["PENDING_VALIDATION", "CONFIRMED"] } },
        orderBy: { createdAt: "desc" },
      });
      if (active) return { action: active, resumed: true };

      const created = await tx.actionItem.create({
        data: {
          storeId,
          recommendationId,
          type: rec.actionType!,
          sensitivity,
          status: "PENDING_VALIDATION",
          payloadJson: rec.actionPayloadJson ?? "{}",
          createdByUserId: userId,
        },
      });
      return { action: created, resumed: false };
    });

    if (resumed) {
      return NextResponse.json({ ok: true, actionId: action.id, resumed: true });
    }

    await logAudit({
      storeId,
      userId,
      actorType: "user",
      event: "action.prepared",
      message: `Action préparée : "${rec.title}" (${rec.actionType}). En attente de validation.`,
      meta: { actionId: action.id },
    });

    return NextResponse.json({ ok: true, actionId: action.id });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }
}
