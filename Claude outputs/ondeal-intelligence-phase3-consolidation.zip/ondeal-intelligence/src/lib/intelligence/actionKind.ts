/**
 * AUTOMATED ACTION vs MANUAL MISSION — distinction demandée explicitement
 * pour ne jamais afficher une fausse exécution.
 *
 * Seuls deux types d'action correspondent aujourd'hui à une mutation Shopify
 * réelle (`updateVariantPrice`, `updateProductStatus` dans
 * `src/lib/integrations/shopify.ts`) : `update_price` et `unpublish_product`.
 * Tous les autres types générés par `recommendations.ts`
 * (`review_supplier`, `request_reviews`, `promote_product`,
 * `edit_product_data`) n'ont aucune mutation associée — ce sont des missions
 * qu'OnDeal prépare et explique, mais que l'utilisateur doit réaliser
 * lui-même (contacter un fournisseur, demander des avis, etc.).
 *
 * Source unique utilisée à la fois par la route d'exécution (pour taguer le
 * résultat) et par l'UI (pour ne jamais présenter une simple confirmation
 * utilisateur comme la preuve d'une mutation Shopify qui n'a pas eu lieu).
 */
export type ActionKind = "automated_mutation" | "manual_mission";

export const AUTOMATED_ACTION_TYPES = new Set(["update_price", "unpublish_product"]);

export function actionKindFor(type: string | null | undefined): ActionKind {
  return type && AUTOMATED_ACTION_TYPES.has(type) ? "automated_mutation" : "manual_mission";
}

export function actionKindLabel(kind: ActionKind): string {
  return kind === "automated_mutation" ? "Action automatisée" : "Mission manuelle";
}

export function actionKindDescription(kind: ActionKind): string {
  return kind === "automated_mutation"
    ? "OnDeal effectue réellement cette modification sur Shopify."
    : "OnDeal prépare et explique cette action — vous devez la réaliser vous-même. Confirmer ici enregistre uniquement que la mission a été prise en charge, jamais une mutation Shopify.";
}

/** Résultat structuré d'exécution — remplace les objets ad hoc {ok, detail} pour porter le kind et les données de vérification sans fabriquer de valeur. */
export type ExecutionOutcome =
  | {
      ok: true;
      kind: "automated_mutation";
      detail: string;
      verification: string;
      before: number | string | null;
      applied: number | string;
      verified: number | string;
    }
  | { ok: true; kind: "manual_mission_completed"; detail: string }
  | { ok: false; kind: "stale_simulation"; detail: string; changedFields: Array<{ field: string; label: string; expected: number | null; actual: number | null }> }
  | { ok: false; kind: "error"; detail: string };
