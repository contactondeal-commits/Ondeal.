import { describe, it, expect } from "vitest";
import { actionKindFor } from "@/lib/intelligence/actionKind";

describe("actionKindFor — AUTOMATED ACTION vs MANUAL MISSION", () => {
  it("classe update_price et unpublish_product comme automated_mutation (mutation Shopify réelle disponible)", () => {
    expect(actionKindFor("update_price")).toBe("automated_mutation");
    expect(actionKindFor("unpublish_product")).toBe("automated_mutation");
  });

  it("classe les types sans mutation réelle comme manual_mission (jamais présenté comme une vraie exécution)", () => {
    expect(actionKindFor("review_supplier")).toBe("manual_mission");
    expect(actionKindFor("request_reviews")).toBe("manual_mission");
    expect(actionKindFor("promote_product")).toBe("manual_mission");
    expect(actionKindFor("edit_product_data")).toBe("manual_mission");
  });

  it("traite un type inconnu ou absent comme manual_mission par défaut (jamais une fausse exécution automatique)", () => {
    expect(actionKindFor(null)).toBe("manual_mission");
    expect(actionKindFor(undefined)).toBe("manual_mission");
    expect(actionKindFor("some_future_type")).toBe("manual_mission");
  });
});
