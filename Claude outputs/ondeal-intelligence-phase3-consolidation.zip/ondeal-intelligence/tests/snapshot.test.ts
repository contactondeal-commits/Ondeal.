import { describe, it, expect } from "vitest";
import { buildPriceSnapshot, comparePriceSnapshot, describeSnapshotChange, isPriceSnapshot } from "@/lib/intelligence/snapshot";

const BASE_FIELDS = {
  currentPrice: 19.9,
  supplierCost: 8,
  shippingCost: 2,
  paymentFeesRate: 0.029,
  otherFixedCost: null,
};

describe("buildPriceSnapshot / isPriceSnapshot", () => {
  it("construit un snapshot exploitable reconnu par le type guard", () => {
    const snap = buildPriceSnapshot({
      productId: "p1",
      variantId: "v1",
      candidateValue: 24.9,
      fields: BASE_FIELDS,
      observedAt: new Date("2026-09-03T21:00:00Z"),
    });
    expect(isPriceSnapshot(snap)).toBe(true);
    expect(snap.observedAt).toBe("2026-09-03T21:00:00.000Z");
    expect(snap.candidateValue).toBe(24.9);
  });

  it("rejette une valeur qui ne ressemble pas à un snapshot (repli sur l'ancien comportement)", () => {
    expect(isPriceSnapshot(null)).toBe(false);
    expect(isPriceSnapshot(undefined)).toBe(false);
    expect(isPriceSnapshot({ currentPrice: 20 })).toBe(false);
    expect(isPriceSnapshot("not an object")).toBe(false);
  });
});

describe("comparePriceSnapshot — scénario 21:00 simulation / 21:05 changement Shopify / 21:07 exécution", () => {
  it("ne détecte aucun écart quand rien n'a changé (exécution autorisée)", () => {
    const snap = buildPriceSnapshot({ productId: "p1", variantId: "v1", candidateValue: 24.9, fields: BASE_FIELDS });
    const cmp = comparePriceSnapshot(snap, BASE_FIELDS);
    expect(cmp.stale).toBe(false);
    expect(cmp.changedFields).toHaveLength(0);
  });

  it("détecte un prix modifié entre la simulation et l'exécution (exécution refusée)", () => {
    const snap = buildPriceSnapshot({ productId: "p1", variantId: "v1", candidateValue: 24.9, fields: BASE_FIELDS });
    const current = { ...BASE_FIELDS, currentPrice: 24.5 }; // synchro Shopify entre-temps
    const cmp = comparePriceSnapshot(snap, current);
    expect(cmp.stale).toBe(true);
    expect(cmp.changedFields).toHaveLength(1);
    expect(cmp.changedFields[0]!.field).toBe("currentPrice");
  });

  it("détecte un coût fournisseur modifié même si le prix n'a pas bougé", () => {
    const snap = buildPriceSnapshot({ productId: "p1", variantId: "v1", candidateValue: 24.9, fields: BASE_FIELDS });
    const current = { ...BASE_FIELDS, supplierCost: 11 };
    const cmp = comparePriceSnapshot(snap, current);
    expect(cmp.stale).toBe(true);
    expect(cmp.changedFields.map((c) => c.field)).toContain("supplierCost");
  });

  it("tolère les imprécisions flottantes (pas un vrai écart)", () => {
    const snap = buildPriceSnapshot({ productId: "p1", variantId: "v1", candidateValue: 24.9, fields: BASE_FIELDS });
    const current = { ...BASE_FIELDS, currentPrice: 19.9 + 1e-9 };
    const cmp = comparePriceSnapshot(snap, current);
    expect(cmp.stale).toBe(false);
  });

  it("traite l'apparition/disparition d'une donnée comme un changement réel, jamais ignoré", () => {
    const snap = buildPriceSnapshot({ productId: "p1", variantId: "v1", candidateValue: 24.9, fields: BASE_FIELDS });
    const current = { ...BASE_FIELDS, otherFixedCost: 1.5 }; // était null, maintenant connu
    const cmp = comparePriceSnapshot(snap, current);
    expect(cmp.stale).toBe(true);
    expect(cmp.changedFields.map((c) => c.field)).toContain("otherFixedCost");
  });

  it("produit un message explicite listant exactement ce qui a changé (jamais un simple 'obsolète')", () => {
    const snap = buildPriceSnapshot({ productId: "p1", variantId: "v1", candidateValue: 24.9, fields: BASE_FIELDS });
    const current = { ...BASE_FIELDS, currentPrice: 24.5 };
    const cmp = comparePriceSnapshot(snap, current);
    const message = describeSnapshotChange(cmp);
    expect(message).toContain("Prix actuel");
    expect(message).toContain("19.90 €");
    expect(message).toContain("24.50 €");
    expect(message).toContain("nouvelle simulation est nécessaire");
  });

  it("describeSnapshotChange retourne une chaîne vide quand rien n'est obsolète", () => {
    expect(describeSnapshotChange({ stale: false, changedFields: [] })).toBe("");
  });
});
