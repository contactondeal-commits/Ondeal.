import Link from "next/link";
import { Prisma } from "@prisma/client";
import { requireStore } from "@/lib/store-context";
import { prisma } from "@/lib/db";
import AppShell from "@/components/AppShell";
import DecisionCard from "@/components/DecisionCard";
import SyncButton from "@/components/SyncButton";
import HealthRing from "@/components/HealthRing";
import DataTag from "@/components/ui/DataTag";
import { groupRecommendations, countBySeverity } from "@/lib/intelligence/group";
import { lightenGroup } from "@/lib/intelligence/groupTransport";
import { aggregateScoreBreakdowns } from "@/lib/intelligence/score";
import { derivePhaseFromExistingAction } from "@/lib/intelligence/decision";
import { actionKindFor } from "@/lib/intelligence/actionKind";
import { isPricePrediction } from "@/lib/intelligence/prediction";
import type { ScoreBreakdown } from "@/types";

const PHASE_LABEL: Record<string, { label: string; cls: string }> = {
  confirm: { label: "À valider", cls: "badge-opportunity" },
  "ready-execute": { label: "Prête à exécuter", cls: "badge-opportunity" },
  "done-success": { label: "Exécutée", cls: "badge-suggestion" },
  "done-failed": { label: "Échec — à reprendre", cls: "badge-urgent" },
  stale: { label: "Simulation obsolète", cls: "badge-urgent" },
  signal: { label: "Signal", cls: "badge-neutral" },
};
const TYPE_LABEL: Record<string, string> = {
  update_price: "Prix",
  unpublish_product: "Dépublication",
  review_supplier: "Réassort fournisseur",
  request_reviews: "Demande d'avis",
  promote_product: "Mise en avant",
  edit_product_data: "Fiche produit",
};

/**
 * COMMAND CENTER — cockpit décisionnel : signal prioritaire, opportunités
 * et risques, prochaine action, statut de chaque décision, résultats.
 * Toutes les données sont réelles ou explicitement étiquetées ; les
 * requêtes sont agrégées en base (jamais le catalogue entier chargé).
 */
export default async function DashboardPage({ searchParams }: { searchParams: Promise<{ store?: string }> }) {
  const store = await requireStore(await searchParams);
  const since30d = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const since7d = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  const [productCount, integrations, lastSync, reviewAgg, recommendations, latestScores, stockAgg, revenue30d, actionsRecent, actionCounts] = await Promise.all([
    prisma.product.count({ where: { storeId: store.id } }),
    prisma.integration.findMany({ where: { storeId: store.id } }),
    prisma.syncRun.findFirst({ where: { storeId: store.id, provider: "SHOPIFY", status: { in: ["success", "partial"] } }, orderBy: { startedAt: "desc" } }),
    prisma.review.aggregate({ where: { storeId: store.id }, _avg: { rating: true }, _count: true }),
    prisma.recommendation.findMany({
      where: { storeId: store.id, status: "OPEN" },
      include: { product: { select: { id: true, title: true } } },
      orderBy: [{ severity: "asc" }, { confidence: "desc" }],
    }),
    // Dernier score par produit — en SQL, pas « les 500 dernières lignes ».
    prisma.$queryRaw<Array<{ score: number; factorsJson: string }>>(Prisma.sql`
      SELECT s.score, s.factorsJson FROM score_snapshots s
      WHERE s.storeId = ${store.id}
        AND s.computedAt = (SELECT MAX(s2.computedAt) FROM score_snapshots s2 WHERE s2.storeId = ${store.id} AND s2.productId = s.productId)
    `),
    prisma.$queryRaw<Array<{ known: number | bigint; ruptureProducts: number | bigint }>>(Prisma.sql`
      SELECT
        SUM(CASE WHEN v.inventoryQuantity IS NOT NULL THEN 1 ELSE 0 END) AS known,
        COUNT(DISTINCT CASE WHEN v.inventoryQuantity = 0 THEN v.productId END) AS ruptureProducts
      FROM variants v JOIN products p ON p.id = v.productId WHERE p.storeId = ${store.id}
    `),
    prisma.salesSnapshot.aggregate({ where: { product: { storeId: store.id }, date: { gte: since30d } }, _sum: { revenue: true, unitsSold: true } }),
    prisma.actionItem.findMany({
      where: { storeId: store.id },
      orderBy: { createdAt: "desc" },
      take: 8,
      include: { recommendation: { select: { id: true, title: true, product: { select: { title: true } } } } },
    }),
    prisma.actionItem.groupBy({ by: ["status"], where: { storeId: store.id }, _count: true }),
  ]);

  const shopifyConnected = integrations.find((i) => i.provider === "SHOPIFY")?.status === "CONNECTED";
  const judgemeConnected = integrations.find((i) => i.provider === "JUDGEME")?.status === "CONNECTED";
  const avgRating = reviewAgg._count > 0 ? reviewAgg._avg.rating : null;
  const anyStockKnown = Number(stockAgg[0]?.known ?? 0) > 0;
  const ruptureCount = Number(stockAgg[0]?.ruptureProducts ?? 0);
  const hasSalesData = revenue30d._sum.unitsSold !== null && revenue30d._sum.unitsSold > 0;

  const avgScore = latestScores.length > 0 ? Math.round(latestScores.reduce((a, s) => a + s.score, 0) / latestScores.length) : null;
  const breakdowns: ScoreBreakdown[] = [];
  for (const s of latestScores) {
    try {
      breakdowns.push(JSON.parse(s.factorsJson) as ScoreBreakdown);
    } catch {
      // factorsJson illisible : exclu, jamais remplacé par une valeur inventée.
    }
  }
  const scoreExplanation = aggregateScoreBreakdowns(breakdowns);
  const avgDataCompleteness = breakdowns.length > 0 ? Math.round(breakdowns.reduce((a, b) => a + b.dataCompleteness, 0) / breakdowns.length) : null;

  const severityCounts = countBySeverity(recommendations);
  const allGroups = groupRecommendations(recommendations);
  const groups = allGroups.slice(0, 5);
  const marginSignals = recommendations.filter((r) => r.category === "margin").length;

  // Reprise d'état : ActionItem la plus récente par recommandation affichée.
  const allItemIds = groups.flatMap((g) => g.items.map((i) => i.id));
  const existingActions = allItemIds.length > 0 ? await prisma.actionItem.findMany({ where: { storeId: store.id, recommendationId: { in: allItemIds } }, orderBy: { createdAt: "desc" } }) : [];
  const latestActionByRecommendation = new Map<string, (typeof existingActions)[number]>();
  for (const a of existingActions) if (a.recommendationId && !latestActionByRecommendation.has(a.recommendationId)) latestActionByRecommendation.set(a.recommendationId, a);
  function serializeAction(a: (typeof existingActions)[number]) {
    return {
      id: a.id,
      type: a.type,
      sensitivity: a.sensitivity as "SENSITIVE" | "SAFE",
      status: a.status,
      payload: JSON.parse(a.payloadJson) as Record<string, unknown>,
      resultJson: a.resultJson,
      createdAt: a.createdAt.toISOString(),
      confirmedAt: a.confirmedAt?.toISOString() ?? null,
      executedAt: a.executedAt?.toISOString() ?? null,
    };
  }
  const actionsByRecommendation: Record<string, ReturnType<typeof serializeAction>> = {};
  for (const [recId, a] of latestActionByRecommendation) actionsByRecommendation[recId] = serializeAction(a);

  const countByStatus = (s: string) => actionCounts.find((c) => c.status === s)?._count ?? 0;
  const pendingDecisions = countByStatus("PENDING_VALIDATION") + countByStatus("CONFIRMED");
  const executed7d = actionsRecent.filter((a) => a.status === "EXECUTED" && a.executedAt && a.executedAt >= since7d).length;
  const failedTotal = countByStatus("FAILED");
  const next = groups[0] ?? null;

  return (
    <AppShell
      store={store}
      active="/dashboard"
      headerExtra={!store.isDemo ? <SyncButton storeId={store.id} shopifyConnected={shopifyConnected} judgemeConnected={judgemeConnected} /> : undefined}
    >
      <div className="cockpit-head">
        <div className="cockpit-head-body">
          <div className="cockpit-kicker">Command Center</div>
          <h1 className="cockpit-title">{store.name}</h1>
          <p className="cockpit-subtitle">
            {severityCounts.total === 0
              ? "Aucun signal ouvert sur les données actuelles."
              : `${severityCounts.urgent.toLocaleString("fr-FR")} risque${severityCounts.urgent > 1 ? "s" : ""} urgent${severityCounts.urgent > 1 ? "s" : ""}, ${severityCounts.opportunity.toLocaleString("fr-FR")} opportunité${severityCounts.opportunity > 1 ? "s" : ""}, ${severityCounts.suggestion.toLocaleString("fr-FR")} suggestion${severityCounts.suggestion > 1 ? "s" : ""} — sur ${productCount.toLocaleString("fr-FR")} produits réels.`}
          </p>
          <div className="cockpit-meta">
            <span>
              <DataTag status="real" compact /> Dernière synchronisation : {lastSync?.finishedAt ? lastSync.finishedAt.toLocaleString("fr-FR") : "aucune"}
              {lastSync?.triggeredBy === "bulk_import" ? " (import bulk)" : ""}
            </span>
            <span>Complétude des données : {avgDataCompleteness !== null ? `${avgDataCompleteness} %` : "n/d"}</span>
            <span>{shopifyConnected ? "Shopify connecté" : "Shopify non connecté (jeton à saisir)"}</span>
          </div>
        </div>
        <HealthRing score={avgScore} />
      </div>

      <div className="stat-strip" role="list">
        <Tile label="Risques urgents" value={severityCounts.urgent} tag="calculated" tone={severityCounts.urgent > 0 ? "danger" : undefined} href={`/intelligence?store=${store.id}&filter=urgent`} />
        <Tile label="Opportunités" value={severityCounts.opportunity} tag="calculated" href={`/intelligence?store=${store.id}&filter=opportunity`} />
        <Tile label="Signaux de marge" value={marginSignals} tag="calculated" hint="Coût réel Shopify" href={`/intelligence?store=${store.id}&category=margin`} />
        <Tile label="Décisions en attente" value={pendingDecisions} tag="real" tone={pendingDecisions > 0 ? "warning" : undefined} href={`/actions?store=${store.id}`} />
        <Tile label="Exécutées (7 j)" value={executed7d} tag="real" href={`/actions?store=${store.id}`} />
        <Tile label="À reprendre" value={failedTotal} tag="real" tone={failedTotal > 0 ? "danger" : undefined} hint="Échecs et simulations obsolètes" href={`/actions?store=${store.id}`} />
      </div>

      <div className="stat-strip stat-strip-secondary" role="list">
        <Tile label="Ventes brutes 30 j" value={hasSalesData ? `${revenue30d._sum.revenue?.toFixed(2)} €` : "—"} tag={hasSalesData ? "real" : "unavailable"} hint={hasSalesData ? "Hors annulations, remboursements non déduits" : "Aucune vente sur 30 jours"} />
        <Tile label="Unités vendues 30 j" value={hasSalesData ? String(revenue30d._sum.unitsSold) : "—"} tag={hasSalesData ? "real" : "unavailable"} />
        <Tile label="Produits en rupture" value={anyStockKnown ? ruptureCount : "—"} tag="real" hint="Stock à 0 sur toutes les variantes" />
        <Tile label="Note moyenne" value={avgRating !== null ? `${avgRating.toFixed(2)}/5` : "—"} tag={avgRating !== null ? "real" : "unavailable"} hint={avgRating !== null ? `${reviewAgg._count} avis` : judgemeConnected ? "Aucun avis" : "Judge.me non connecté"} />
      </div>

      {(!shopifyConnected || !judgemeConnected) && !store.isDemo && (
        <div className="callout callout-info">
          {!shopifyConnected && "Shopify n'est pas connecté : les données affichées proviennent du dernier import, aucune action Shopify ne pourra s'exécuter. "}
          {!judgemeConnected && "Judge.me n'est pas connecté. "}
          <Link href={`/settings/integrations?store=${store.id}`} style={{ fontWeight: 700, textDecoration: "underline" }}>
            Connecter maintenant
          </Link>
        </div>
      )}

      <div className="cockpit-grid">
        <div className="cockpit-main">
          <section className="card" aria-labelledby="next-action">
            <div className="section-head">
              <h2 id="next-action" className="section-title">
                Prochaine action
              </h2>
              <span className="section-hint">Le signal le plus prioritaire, avec sa décision complète.</span>
            </div>
            {next ? (
              <DecisionCard group={lightenGroup(next, 10)} storeId={store.id} existingAction={actionsByRecommendation[next.representative.id] ?? null} actionsByRecommendation={actionsByRecommendation} />
            ) : (
              <p className="unavailable-note">Aucune recommandation — synchronisez vos données pour lancer la première analyse.</p>
            )}
          </section>

          {groups.length > 1 && (
            <section className="card" aria-labelledby="priorities">
              <div className="section-head">
                <h2 id="priorities" className="section-title">
                  Priorités suivantes
                </h2>
                <span className="section-hint">
                  {severityCounts.total.toLocaleString("fr-FR")} recommandations réelles regroupées par produit — rien n&apos;est masqué.
                </span>
              </div>
              {groups.slice(1).map((g) => (
                <DecisionCard key={g.key} group={lightenGroup(g, 10)} storeId={store.id} existingAction={actionsByRecommendation[g.representative.id] ?? null} actionsByRecommendation={actionsByRecommendation} />
              ))}
              <Link href={`/intelligence?store=${store.id}`} className="section-link">
                Voir les {allGroups.length.toLocaleString("fr-FR")} priorités
              </Link>
            </section>
          )}
        </div>

        <aside className="cockpit-side">
          <section className="card" aria-labelledby="decisions">
            <div className="section-head">
              <h2 id="decisions" className="section-title">
                Décisions
              </h2>
              <span className="section-hint">Statut réel de chaque décision engagée.</span>
            </div>
            {actionsRecent.length === 0 ? (
              <p className="unavailable-note">Aucune décision engagée pour le moment.</p>
            ) : (
              <ul className="decision-list">
                {actionsRecent.map((a) => {
                  const phase = derivePhaseFromExistingAction({ status: a.status, sensitivity: a.sensitivity, resultJson: a.resultJson });
                  const meta = PHASE_LABEL[phase] ?? PHASE_LABEL.signal!;
                  let payload: Record<string, unknown> = {};
                  try {
                    payload = JSON.parse(a.payloadJson) as Record<string, unknown>;
                  } catch {
                    payload = {};
                  }
                  const prediction = isPricePrediction(payload.prediction) ? payload.prediction : null;
                  return (
                    <li key={a.id} className="decision-list-item">
                      <div className="decision-list-head">
                        <span className={`badge ${meta.cls}`}>{a.status === "CANCELLED" ? "Annulée" : meta.label}</span>
                        <span className="decision-list-type">
                          {TYPE_LABEL[a.type] ?? a.type} · {actionKindFor(a.type) === "automated_mutation" ? "automatisée" : "mission"}
                        </span>
                      </div>
                      <div className="decision-list-title">{a.recommendation?.product?.title ?? a.recommendation?.title ?? "—"}</div>
                      {prediction && (
                        <div className="decision-list-sub">
                          Prédit : {prediction.priceBefore?.toFixed(2) ?? "—"} → {prediction.newPrice.toFixed(2)} € · marge brute {prediction.grossMarginAfter !== null ? `${prediction.grossMarginAfter.toFixed(2)} €` : "n/d"}
                        </div>
                      )}
                      <div className="decision-list-sub">{(a.executedAt ?? a.confirmedAt ?? a.createdAt).toLocaleString("fr-FR")}</div>
                    </li>
                  );
                })}
              </ul>
            )}
            <Link href={`/actions?store=${store.id}`} className="section-link">
              Toutes les décisions
            </Link>
          </section>

          <section className="card" aria-labelledby="score-why">
            <div className="section-head">
              <h2 id="score-why" className="section-title">
                Pourquoi ce score
              </h2>
              <span className="section-hint">
                Contribution moyenne réelle de chaque facteur sur {latestScores.length.toLocaleString("fr-FR")} produit{latestScores.length > 1 ? "s" : ""}.
              </span>
            </div>
            {scoreExplanation.length === 0 ? (
              <p className="unavailable-note">Aucun score calculé pour le moment.</p>
            ) : (
              scoreExplanation.map((f) => (
                <div className="score-factor-row" key={f.key}>
                  <div className="score-factor-label">{f.label}</div>
                  <div className="score-factor-bar-track">
                    <div className="score-factor-bar-fill" style={{ width: `${Math.max(0, Math.min(100, (f.avgContribution / 30) * 100))}%` }} />
                  </div>
                  <div className="score-factor-contribution">{f.avgContribution} pt</div>
                </div>
              ))
            )}
          </section>
        </aside>
      </div>
    </AppShell>
  );
}

function Tile({ label, value, tag, hint, tone, href }: { label: string; value: number | string; tag: "real" | "calculated" | "estimated" | "unavailable"; hint?: string; tone?: "danger" | "warning"; href?: string }) {
  const body = (
    <>
      <div className="stat-tile-label">
        {label} <DataTag status={tag} compact />
      </div>
      <div className="stat-tile-value">{typeof value === "number" ? value.toLocaleString("fr-FR") : value}</div>
      {hint && <div className="stat-tile-hint">{hint}</div>}
    </>
  );
  const cls = `stat-tile${tone ? ` stat-tile-${tone}` : ""}`;
  return href ? (
    <Link href={href} className={`${cls} stat-tile-link`} role="listitem">
      {body}
    </Link>
  ) : (
    <div className={cls} role="listitem">
      {body}
    </div>
  );
}
