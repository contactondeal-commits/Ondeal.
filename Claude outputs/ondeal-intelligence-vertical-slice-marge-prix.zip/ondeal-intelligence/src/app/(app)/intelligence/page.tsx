import { requireStore } from "@/lib/store-context";
import { prisma } from "@/lib/db";
import AppShell from "@/components/AppShell";
import PriorityCard from "@/components/PriorityCard";
import Pagination from "@/components/ui/Pagination";
import TableControls from "@/components/ui/TableControls";
import { parsePageParams } from "@/lib/pagination";
import { groupRecommendations, countBySeverity, type GroupableRecommendation, type RecommendationGroup } from "@/lib/intelligence/group";
import { lightenGroup } from "@/lib/intelligence/groupTransport";

const CATEGORY_OPTIONS = [
  { value: "all", label: "Toutes les catégories" },
  { value: "margin", label: "Marge" },
  { value: "stock", label: "Stock" },
  { value: "reviews", label: "Avis" },
  { value: "data_quality", label: "Qualité des données" },
  { value: "content", label: "Contenu produit" },
  { value: "marketing", label: "Marketing" },
];

type Params = { store?: string; filter?: string; category?: string; q?: string; page?: string; pageSize?: string };

/**
 * CENTRE D'INTELLIGENCE — toutes les recommandations réelles, regroupées
 * par produit, filtrées et paginées (25 groupes par page) : le total exact
 * reste affiché, rien n'est masqué, mais jamais 3 000 cartes dans une page.
 */
export default async function IntelligencePage({ searchParams }: { searchParams: Promise<Params> }) {
  const params = await searchParams;
  const store = await requireStore(params);
  const activeFilter = params.filter === "urgent" || params.filter === "opportunity" || params.filter === "suggestion" ? params.filter : "all";
  const category = CATEGORY_OPTIONS.some((o) => o.value === params.category) ? (params.category as string) : "all";
  const { page, pageSize } = parsePageParams(params, 25);

  const recommendations: GroupableRecommendation[] = await prisma.recommendation.findMany({
    where: { storeId: store.id, status: "OPEN" },
    include: { product: { select: { id: true, title: true } } },
    orderBy: [{ severity: "asc" }, { confidence: "desc" }],
  });

  const counts = countBySeverity(recommendations);
  const allGroups = groupRecommendations(recommendations);
  const q = params.q?.trim().toLowerCase();
  let filtered = recommendations;
  if (activeFilter !== "all") filtered = filtered.filter((r) => r.severity === activeFilter.toUpperCase());
  if (category !== "all") filtered = filtered.filter((r) => r.category === category);
  if (q) filtered = filtered.filter((r) => r.title.toLowerCase().includes(q) || (r.product?.title ?? "").toLowerCase().includes(q));
  const groups: RecommendationGroup[] = activeFilter === "all" && category === "all" && !q ? allGroups : groupRecommendations(filtered);
  const total = groups.length;
  const pageGroups = groups.slice((page - 1) * pageSize, page * pageSize).map((g) => lightenGroup(g, 1));

  const chips: Array<{ key: string; label: string; count: number; cls: string }> = [
    { key: "all", label: "Toutes", count: counts.total, cls: "all" },
    { key: "urgent", label: "Urgent", count: counts.urgent, cls: "urgent" },
    { key: "opportunity", label: "Opportunités", count: counts.opportunity, cls: "opportunity" },
    { key: "suggestion", label: "Recommandations", count: counts.suggestion, cls: "suggestion" },
  ];
  const urlParams: Record<string, string | undefined> = { store: store.id, filter: activeFilter === "all" ? undefined : activeFilter, category, q: params.q, pageSize: params.pageSize };

  return (
    <AppShell store={store} active="/intelligence">
      <div className="topbar">
        <div>
          <h1 className="page-title">Centre d&apos;intelligence</h1>
          <p className="page-subtitle">
            {counts.total.toLocaleString("fr-FR")} recommandation{counts.total > 1 ? "s" : ""} réelle{counts.total > 1 ? "s" : ""}, regroupées en{" "}
            {allGroups.length.toLocaleString("fr-FR")} priorité{allGroups.length > 1 ? "s" : ""} lisibles.
          </p>
        </div>
      </div>

      <div className="chip-row">
        {chips.map((c) => (
          <a
            key={c.key}
            href={`?store=${store.id}${c.key === "all" ? "" : `&filter=${c.key}`}${category !== "all" ? `&category=${category}` : ""}`}
            className={`count-chip chip-${c.cls} ${activeFilter === c.key ? "active" : ""}`}
          >
            {c.label} <span className="chip-count">{c.count.toLocaleString("fr-FR")}</span>
          </a>
        ))}
      </div>

      <div className="card card-table">
        <TableControls
          params={urlParams}
          searchPlaceholder="Rechercher une recommandation ou un produit"
          filters={[{ key: "category", label: "Catégorie", value: category, options: CATEGORY_OPTIONS }]}
        />
        {pageGroups.length === 0 ? (
          <p className="unavailable-note" style={{ padding: 16 }}>
            Aucune recommandation dans cette catégorie.
          </p>
        ) : (
          <div className="priority-list">
            {pageGroups.map((g) => (
              <PriorityCard key={g.key} group={g} storeId={store.id} />
            ))}
          </div>
        )}
        <Pagination total={total} page={page} pageSize={pageSize} params={urlParams} label="priorités" />
      </div>
    </AppShell>
  );
}
