import Link from "next/link";
import { Prisma } from "@prisma/client";
import { requireStore } from "@/lib/store-context";
import { prisma } from "@/lib/db";
import AppShell from "@/components/AppShell";
import Pagination from "@/components/ui/Pagination";
import TableControls from "@/components/ui/TableControls";
import DataTag from "@/components/ui/DataTag";
import { parsePageParams } from "@/lib/pagination";
import { classifyProduct } from "@/lib/intelligence/score";

const TIER_META: Record<string, { label: string; cls: string }> = {
  a_booster: { label: "À booster", cls: "badge-opportunity" },
  performant: { label: "Performant", cls: "badge-suggestion" },
  a_optimiser: { label: "À optimiser", cls: "badge-neutral" },
  a_surveiller: { label: "À surveiller", cls: "badge-opportunity" },
  a_revoir: { label: "À revoir", cls: "badge-urgent" },
};

type Params = { store?: string; q?: string; status?: string; stock?: string; sort?: string; page?: string; pageSize?: string };
type Sort = "score_desc" | "score_asc" | "updated" | "title" | "stock_asc";

const STATUS_OPTIONS = [
  { value: "all", label: "Tous les statuts" },
  { value: "active", label: "Actifs" },
  { value: "draft", label: "Brouillons" },
  { value: "archived", label: "Archivés" },
];
const STOCK_OPTIONS = [
  { value: "all", label: "Tout stock" },
  { value: "zero", label: "Stock à 0 (toutes variantes)" },
  { value: "positive", label: "Stock disponible" },
];
const SORT_OPTIONS: Array<{ value: Sort; label: string }> = [
  { value: "score_desc", label: "Score décroissant" },
  { value: "score_asc", label: "Score croissant" },
  { value: "stock_asc", label: "Stock croissant" },
  { value: "updated", label: "Dernière mise à jour" },
  { value: "title", label: "Nom du produit" },
];

/**
 * PRODUCT INTELLIGENCE — paginé par la base (score, statut, stock, recherche
 * en SQL), jamais les 1 730 produits et 16 407 variantes dans une page.
 */
export default async function ProductsPage({ searchParams }: { searchParams: Promise<Params> }) {
  const params = await searchParams;
  const store = await requireStore(params);
  const { page, pageSize } = parsePageParams(params);
  const status = STATUS_OPTIONS.some((o) => o.value === params.status) ? (params.status as string) : "all";
  const stock = STOCK_OPTIONS.some((o) => o.value === params.stock) ? (params.stock as string) : "all";
  const sort: Sort = SORT_OPTIONS.some((o) => o.value === params.sort) ? (params.sort as Sort) : "score_desc";

  const where: Prisma.Sql[] = [Prisma.sql`p.storeId = ${store.id}`];
  if (params.q?.trim()) {
    const like = `%${params.q.trim()}%`;
    where.push(Prisma.sql`(p.title LIKE ${like} OR p.handle LIKE ${like} OR p.vendor LIKE ${like})`);
  }
  if (status !== "all") where.push(Prisma.sql`p.status = ${status}`);
  if (stock === "zero") where.push(Prisma.sql`NOT EXISTS (SELECT 1 FROM variants v WHERE v.productId = p.id AND v.inventoryQuantity > 0)`);
  if (stock === "positive") where.push(Prisma.sql`EXISTS (SELECT 1 FROM variants v WHERE v.productId = p.id AND v.inventoryQuantity > 0)`);
  const whereSql = Prisma.join(where, " AND ");

  // Dernier score par produit (sous-requête), pour trier sans charger l'historique.
  // storeId inclus pour utiliser l'index (storeId, productId, computedAt) — 1 000 ms → 4 ms sur 1 730 produits.
  const latestScore = Prisma.sql`(SELECT s.score FROM score_snapshots s WHERE s.storeId = ${store.id} AND s.productId = p.id ORDER BY s.computedAt DESC LIMIT 1)`;
  const totalStock = Prisma.sql`(SELECT SUM(v.inventoryQuantity) FROM variants v WHERE v.productId = p.id)`;
  const order =
    sort === "score_asc"
      ? Prisma.sql`ORDER BY (${latestScore} IS NULL) ASC, ${latestScore} ASC, p.title ASC`
      : sort === "stock_asc"
        ? Prisma.sql`ORDER BY ${totalStock} ASC, p.title ASC`
        : sort === "updated"
          ? Prisma.sql`ORDER BY p.updatedAt DESC`
          : sort === "title"
            ? Prisma.sql`ORDER BY p.title ASC`
            : Prisma.sql`ORDER BY (${latestScore} IS NULL) ASC, ${latestScore} DESC, p.title ASC`;

  const [countRow] = await prisma.$queryRaw<Array<{ c: number | bigint }>>(Prisma.sql`SELECT COUNT(*) AS c FROM products p WHERE ${whereSql}`);
  const total = Number(countRow?.c ?? 0);
  const ids = await prisma.$queryRaw<Array<{ id: string }>>(
    Prisma.sql`SELECT p.id FROM products p WHERE ${whereSql} ${order} LIMIT ${pageSize} OFFSET ${(page - 1) * pageSize}`,
  );

  const products = ids.length
    ? await prisma.product.findMany({
        where: { id: { in: ids.map((r) => r.id) } },
        include: {
          variants: { select: { inventoryQuantity: true, unitCost: true } },
          reviews: { select: { rating: true } },
          scoreSnapshots: { orderBy: { computedAt: "desc" }, take: 1, select: { score: true } },
        },
      })
    : [];
  const byId = new Map(products.map((p) => [p.id, p]));
  const ordered = ids.map((r) => byId.get(r.id)).filter((p): p is NonNullable<typeof p> => !!p);
  const urlParams: Record<string, string | undefined> = { store: store.id, q: params.q, status, stock, sort, pageSize: params.pageSize };

  return (
    <AppShell store={store} active="/products">
      <div className="topbar">
        <div>
          <h1 className="page-title">Product Intelligence</h1>
          <p className="page-subtitle">{total.toLocaleString("fr-FR")} produit{total > 1 ? "s" : ""} — classés par OnDeal Score et signaux critiques.</p>
        </div>
      </div>

      <div className="card card-table">
        <TableControls
          params={urlParams}
          searchPlaceholder="Rechercher un produit, un handle, un vendor"
          filters={[
            { key: "status", label: "Statut", value: status, options: STATUS_OPTIONS },
            { key: "stock", label: "Stock", value: stock, options: STOCK_OPTIONS },
          ]}
          sort={{ key: "sort", label: "Tri", value: sort, options: SORT_OPTIONS }}
        />
        <div className="table-scroll">
          <table className="table table-compact">
            <thead>
              <tr>
                <th>Produit</th>
                <th className="num">Score</th>
                <th>Classement</th>
                <th className="num">
                  Stock <DataTag status="real" compact />
                </th>
                <th className="num">Variantes</th>
                <th className="num">Coût réel</th>
                <th>Avis</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {ordered.length === 0 && (
                <tr>
                  <td colSpan={8} className="unavailable-note" style={{ padding: 24, textAlign: "center" }}>
                    Aucun produit ne correspond à ces critères.
                  </td>
                </tr>
              )}
              {ordered.map((p) => {
                const score = p.scoreSnapshots[0]?.score ?? null;
                const totalStockValue = p.variants.reduce((s, v) => s + (v.inventoryQuantity ?? 0), 0);
                const anyStockKnown = p.variants.some((v) => v.inventoryQuantity !== null);
                const withCost = p.variants.filter((v) => v.unitCost !== null).length;
                const avgRating = p.reviews.length > 0 ? p.reviews.reduce((s, r) => s + r.rating, 0) / p.reviews.length : null;
                const tier = score !== null ? classifyProduct({ score, hasStockCritical: anyStockKnown && totalStockValue === 0, hasNegativeMargin: false, salesTrendPositive: null }) : null;
                return (
                  <tr key={p.id}>
                    <td>
                      <div className="cell-title">{p.title}</div>
                      <div className="cell-sub">
                        {p.status}
                        {p.productType ? ` · ${p.productType}` : ""}
                      </div>
                    </td>
                    <td className="num">{score !== null ? `${score}/100` : <span className="unavailable-note">n/d</span>}</td>
                    <td>{tier ? <span className={`badge ${TIER_META[tier]!.cls}`}>{TIER_META[tier]!.label}</span> : "—"}</td>
                    <td className="num">{anyStockKnown ? totalStockValue.toLocaleString("fr-FR") : <span className="unavailable-note">n/d</span>}</td>
                    <td className="num">{p.variants.length}</td>
                    <td className="num">
                      {withCost}/{p.variants.length}
                    </td>
                    <td>{avgRating !== null ? `${avgRating.toFixed(1)}/5 (${p.reviews.length})` : <span className="unavailable-note">aucun</span>}</td>
                    <td>
                      <Link href={`/products/${p.id}?store=${store.id}`} className="btn btn-secondary btn-sm">
                        Détail
                      </Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <Pagination total={total} page={page} pageSize={pageSize} params={urlParams} label="produits" />
      </div>
    </AppShell>
  );
}
