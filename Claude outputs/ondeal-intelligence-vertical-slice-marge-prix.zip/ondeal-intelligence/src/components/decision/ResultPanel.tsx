import { CheckCircle2, AlertTriangle, RefreshCw } from "lucide-react";
import Button from "@/components/ui/Button";
import DataTag from "@/components/ui/DataTag";
import type { PriceOutcomeMeasurement, PricePrediction } from "@/lib/intelligence/prediction";

function eur(v: number | null | undefined): string {
  return v === null || v === undefined ? "—" : `${v.toFixed(2)} €`;
}

/**
 * PRÉVU → APPLIQUÉ → VÉRIFIÉ → ÉCART → PROCHAINE MESURE. Chiffres issus
 * exclusivement de la prédiction persistée à la confirmation et du prix
 * relu de Shopify après mutation ; la mesure commerciale reste « données
 * insuffisantes » tant que le volume ne permet pas de comparer.
 */
function MeasurementBlock({ m }: { m: PriceOutcomeMeasurement }) {
  return (
    <div className="measurement">
      <div className="measurement-title">Prédiction et résultat</div>
      <table className="scenario-table">
        <thead>
          <tr>
            <th scope="col"></th>
            <th scope="col">Prévu (à la validation)</th>
            <th scope="col">Observé (après Shopify)</th>
            <th scope="col">Écart</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">
              Prix <DataTag status="real" compact />
            </th>
            <td>{eur(m.predicted.newPrice)}</td>
            <td>{eur(m.observed.appliedPrice)}</td>
            <td className={Math.abs(m.gap.price) > 0.01 ? "is-negative" : ""}>{m.gap.price >= 0 ? "+" : ""}{m.gap.price.toFixed(2)} €</td>
          </tr>
          <tr>
            <th scope="row">
              Coût fournisseur <DataTag status={m.observed.supplierCostSource === "shopify_unit_cost" ? "real" : m.observed.supplierCost === null ? "unavailable" : "estimated"} compact />
            </th>
            <td>—</td>
            <td>{eur(m.observed.supplierCost)}</td>
            <td>—</td>
          </tr>
          <tr className="scenario-row-strong">
            <th scope="row">
              Marge brute <DataTag status="calculated" compact />
            </th>
            <td>{eur(m.predicted.grossMarginAfter)}</td>
            <td>{eur(m.observed.grossMargin)}</td>
            <td className={m.gap.grossMargin !== null && Math.abs(m.gap.grossMargin) > 0.01 ? "is-negative" : ""}>
              {m.gap.grossMargin === null ? "—" : `${m.gap.grossMargin >= 0 ? "+" : ""}${m.gap.grossMargin.toFixed(2)} €`}
            </td>
          </tr>
        </tbody>
      </table>
      <div className={`measurement-verdict ${m.gap.structuralMatch ? "is-match" : "is-gap"}`}>{m.gap.explanation}</div>
      <div className="measurement-deferred">
        <DataTag status="unavailable" compact /> Effet sur les ventes : {m.deferred.reason}
      </div>
    </div>
  );
}

export interface DisplayResult {
  detail: string;
  kind?: string;
  verification?: string;
  before?: number | string | null;
  applied?: number | string;
  verified?: number | string;
  changedFields?: Array<{ field: string; label: string; expected: number | null; actual: number | null }>;
  /** PREDICTION → RESULT → GAP (update_price) — voir prediction.ts. */
  measurement?: PriceOutcomeMeasurement;
}

function fmtDate(iso: string | null): string {
  return iso ? new Date(iso).toLocaleString("fr-FR") : "—";
}

function fmtValue(v: number | string | null | undefined): string {
  if (v === null || v === undefined) return "—";
  return typeof v === "number" ? `${v.toFixed(2)} €` : String(v);
}

/**
 * Section RÉSULTAT — jamais un chiffre fictif. Distingue une ACTION
 * EXÉCUTÉE (mutation Shopify réelle, avant/appliqué/vérifié tous issus de
 * données réelles), une MISSION marquée comme effectuée par l'utilisateur
 * (aucune mutation), un refus pour SIMULATION OBSOLÈTE (ce qui a changé,
 * explicitement), et un échec ordinaire.
 */
export default function ResultPanel({
  phase,
  result,
  resultAt,
  onRetry,
  prediction = null,
}: {
  phase: "done-success" | "done-failed" | "stale";
  result: DisplayResult;
  resultAt: string | null;
  onRetry: () => void;
  /** Prédiction persistée à la validation (payload.prediction) — affichée telle quelle, même quand l'action a échoué. */
  prediction?: PricePrediction | null;
}) {
  const predicted = prediction ? (
    <div className="decision-result-predicted">
      <span className="decision-result-predicted-label">Prévu à la validation ({new Date(prediction.predictedAt).toLocaleString("fr-FR")})</span>
      <span>
        Prix {eur(prediction.priceBefore)} → {eur(prediction.newPrice)} · marge brute {eur(prediction.grossMarginBefore)} → {eur(prediction.grossMarginAfter)}
        {prediction.marginAfter !== null ? ` · marge complète (hypothèses) ${eur(prediction.marginBefore)} → ${eur(prediction.marginAfter)}` : ""}
      </span>
    </div>
  ) : null;
  if (phase === "done-success" && result.kind === "automated_mutation") {
    return (
      <div className="decision-result decision-result-success">
        <div className="decision-result-title">
          <CheckCircle2 size={16} /> Action exécutée
        </div>
        <div className="decision-result-grid">
          <div className="decision-result-field">
            <span>Avant</span>
            <strong>{fmtValue(result.before)}</strong>
          </div>
          <div className="decision-result-field">
            <span>Appliqué</span>
            <strong>{fmtValue(result.applied)}</strong>
          </div>
          <div className="decision-result-field">
            <span>Vérifié</span>
            <strong>{fmtValue(result.verified)}</strong>
          </div>
        </div>
        <div className="decision-result-detail">{result.detail}</div>
        {result.verification && <div className="decision-result-detail">Shopify vérifié — {result.verification}</div>}
        {!result.measurement && predicted}
        {result.measurement && <MeasurementBlock m={result.measurement} />}
        <div className="decision-result-meta">
          Exécuté le {fmtDate(resultAt)} — Recommandation résolue
        </div>
      </div>
    );
  }

  if (phase === "done-success" && result.kind === "manual_mission_completed") {
    return (
      <div className="decision-result decision-result-success">
        <div className="decision-result-title">
          <CheckCircle2 size={16} /> Mission marquée comme effectuée
        </div>
        <div className="decision-result-detail">{result.detail}</div>
        <div className="decision-result-meta">
          Confirmé le {fmtDate(resultAt)} — aucune mutation Shopify n&apos;a été effectuée par OnDeal pour ce type d&apos;action.
        </div>
      </div>
    );
  }

  if (phase === "stale") {
    return (
      <div className="decision-result decision-result-stale">
        <div className="decision-result-title">
          <RefreshCw size={16} /> Simulation obsolète — exécution refusée
        </div>
        <div className="decision-result-detail">{result.detail}</div>
        {result.changedFields && result.changedFields.length > 0 && (
          <div className="decision-result-grid">
            {result.changedFields.map((c) => (
              <div className="decision-result-field" key={c.field}>
                <span>{c.label}</span>
                <strong>
                  {c.expected ?? "—"} → {c.actual ?? "—"}
                </strong>
              </div>
            ))}
          </div>
        )}
        <div className="decision-result-meta">Refusé le {fmtDate(resultAt)} — aucune modification appliquée sur Shopify.</div>
        <Button variant="secondary" size="sm" style={{ marginTop: 8 }} onClick={onRetry}>
          Relancer une nouvelle simulation
        </Button>
      </div>
    );
  }

  // done-failed (échec ordinaire : Shopify indisponible, produit supprimé, etc.)
  return (
    <div className="decision-result decision-result-failed">
      <div className="decision-result-title">
        <AlertTriangle size={16} /> Action non exécutée
      </div>
      <div className="decision-result-detail">{result.detail}</div>
      {predicted}
      <div className="decision-result-meta">Statut : FAILED — {fmtDate(resultAt)} — aucune modification appliquée sur Shopify.</div>
      <Button variant="secondary" size="sm" style={{ marginTop: 8 }} onClick={onRetry}>
        Réessayer (nouvelle décision)
      </Button>
    </div>
  );
}
