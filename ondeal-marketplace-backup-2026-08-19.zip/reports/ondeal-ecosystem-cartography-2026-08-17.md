# Cartographie complète de l'écosystème OnDeal — 17/08/2026

> Mission : « Ne modifie rien au départ. Cartographie entièrement l'écosystème OnDeal et construis le plan d'automatisation totalement complet sans erreur. »
> Ce document couvre uniquement la phase de découverte (lecture seule — aucune modification effectuée) et le plan proposé. Aucune automatisation n'a été implémentée à ce stade : tout est soumis à validation avant exécution, domaine par domaine, avec tests après chaque domaine, sans jamais casser l'existant.

## 0. Point corrigé (alerte initiale invalidée par toi)

J'avais signalé en direct que la commande Shopify **#1001** (Émilie Peraudeau, 34,80 €, 04/08/2026) semblait bloquée côté CJdropshipping, en statut **« commande invalide »** (produit non associé à sa fiche CJ). **Tu as confirmé que c'est une fausse alerte** : cette commande a été expédiée via ton ancien fournisseur **BigBuy**, pas via CJ — elle n'était donc jamais censée transiter par CJ, et le statut « invalide » côté CJ est sans conséquence sur cette commande précise, déjà réglée.

**Précision de ta part (17/08/2026)** : BigBuy reste **actif** comme fournisseur de secours (rupture CJ, produit indisponible chez CJ), mais **ne fait plus partie de la stratégie de profit** — CJ est le canal principal de marge désormais. Point clos, non approfondi davantage à ta demande.

## 1. Ce qui existe — inventaire réel

### 1.1 Code du projet (`ondeal-marketplace`, Next.js + Vercel)

| Domaine | Fichiers | Statut réel |
|---|---|---|
| Catalogue Shopify (lecture publique) | `src/lib/shopify/storefront.ts` | Fonctionnel, en prod |
| Catalogue Shopify (admin/scripts) | `src/lib/shopify/admin.ts` | Fonctionnel, scripts CLI uniquement (jamais appelé par le site public) |
| Avis clients Judge.me | `src/lib/shopify/judgeme.ts` | Fonctionnel, corrigé aujourd'hui (résumé + contenu détaillé) |
| Import catalogue CJ → Shopify | `src/lib/cj/*`, `scripts/cj-import-batch.ts` | Fonctionnel pour le **catalogue produit uniquement** (catégories, recherche, détail, variantes, stock, entrepôts) — **aucun appel de création/suivi de commande fournisseur** |
| Catégorisation/audit catalogue | `src/lib/catalog/*`, `scripts/audit-shopify-catalog.ts`, `scripts/categorize-active-catalog.ts`, `scripts/catalog-report.ts` | Fonctionnel, déclenché manuellement (`npm run catalog:*`) |
| Panier/checkout | `src/lib/shopify/cart.ts` | Fonctionnel (Storefront API standard) |
| **Commandes client (compte)** | `src/app/account/orders/page.tsx` | ⚠️ **Affiche des données 100% fictives** (`mockOrders`), aucune connexion aux vraies commandes Shopify |
| Webhooks / API routes internes | — | **Aucun** : pas de dossier `src/app/api`, 0 webhook Shopify configuré (vérifié via GraphQL `webhookSubscriptions`) |
| Base de données | — | **Aucune** (pas de Prisma/Postgres/Redis) — tout repose sur Shopify + fichiers de démo locaux |
| Emails transactionnels/notifications | — | **Aucune librairie** (pas de nodemailer/resend/sendgrid) dans le code du site |

### 1.2 Applications Shopify installées (15)

| App | Rôle apparent | Note |
|---|---|---|
| Judge.me Reviews | Avis clients | Branché (rating + contenu, corrigé aujourd'hui) |
| CJdropshipping: Much Faster | Fournisseur dropshipping | Connexion **Autorisée/Activée** — voir §1.3, c'est le cœur du sujet fournisseur |
| Flow | Automatisation Shopify native | 3 workflows actifs — voir §1.4 |
| Klaviyo: Email Marketing & SMS | Emails marketing/transactionnels | Installée ; une demande de mise à jour d'accès aux données (cartes-cadeaux, crédit magasin) était en attente — **non approuvée par moi**, à valider par toi |
| Matrixify | Import/export en masse | Installée, usage réel non vérifié |
| SMART Discounts | Réductions | Installée, usage réel non vérifié |
| Comply | Conformité légale (probable) | Installée, pertinent pour le sujet CGV/mentions légales déjà identifié |
| Messaging | Messagerie (probable chat client) | Installée, usage réel non vérifié |
| Ondeal Newsletter | Newsletter | Installée, usage réel non vérifié |
| T Lab, Translate & Adapt, EZ Product Translate, EA • Auto Translate, Image Translate Easy, G\|translate | Traduction | **6 apps de traduction installées simultanément** — forte redondance probable, à auditer (coûts d'abonnement cumulés possibles pour une fonctionnalité qui ne devrait nécessiter qu'une seule app) |

Non vérifié (nécessite ton accès) : configuration détaillée de Comply, Messaging, Matrixify, SMART Discounts, et laquelle des 6 apps de traduction est réellement active en production (une seule semble l'être d'après les vérifications i18n précédentes de cette session).

### 1.3 Fournisseur CJdropshipping — le point le plus critique

Connexion Shopify ↔ CJ : **Autorisée**, boutique **Activée**, jeton valide jusqu'au 15/11/2026.

| Réglage | État constaté |
|---|---|
| Synchronisation produits/stock | Activé (`Inventory Sync`) |
| Autorisation email | Activée |
| **Auto-Sync commande & produit** | **Activé** — les commandes Shopify remontent bien vers CJ |
| **Auto Pre-occupy Stock** | **Désactivé** |
| **Auto Pay Order** | **Désactivé** (nécessite le réglage précédent) — **c'est le maillon manquant : aucune commande n'est payée/transmise automatiquement au fournisseur, même si elle est bien détectée** |
| Commandes réellement importées à ce jour | **1 seule** (commande #1001, en statut « invalide » côté CJ — mais cette commande a en réalité été traitée hors CJ, via l'ancien fournisseur BigBuy, et est déjà réglée/expédiée, voir §0) |
| Chiffre d'affaires enregistré côté CJ | 0,00 € (aucune vente traitée à ce jour) |

**Conclusion** : le pont technique Shopify↔CJ existe et fonctionne pour le catalogue, mais **la chaîne de traitement automatique d'une commande s'arrête après la synchronisation** — il n'y a aujourd'hui aucun paiement ni envoi automatique de la commande au fournisseur. C'est un réglage CJ à activer (pas du code à écrire), mais il doit être testé prudemment (impact financier direct : CJ paierait le fournisseur avec le portefeuille CJ du compte).

### 1.4 Automatisations Shopify Flow existantes (3, toutes actives)

1. **« Récupérer le paiement abandonné »** — déclencheur : panier abandonné. Fonctionne (dernière exécution aujourd'hui 10:20).
2. **« Tagging auto - bijoux »** — déclencheur : programmé, tague les produits bijoux (lié à la mission de catégorisation antérieure). Fonctionne (dernière exécution mercredi 11:45).
3. **« New Workflow »** (nom non renseigné) — déclencheur : commande créée → condition sur 5 SKU précis → envoi d'un email interne à `contact@ondeal.fr` (« Bon d'achat 15€ à envoyer »). **Jamais exécuté** (aucune commande ne correspond encore aux SKU cette) — semi-automatisé : détecte l'éligibilité mais l'envoi du bon d'achat reste manuel.

### 1.5 Avis clients (Judge.me)

Le résumé (note/nombre) et le contenu détaillé (auteur, texte) sont maintenant branchés côté site (corrigé aujourd'hui). Judge.me dispose nativement d'une fonction « Programmer des demandes » (vue dans ses réglages) qui gère probablement déjà l'envoi automatique des demandes d'avis post-achat côté Judge.me lui-même — **à confirmer avec toi plutôt qu'à reconstruire**, puisque c'est une fonctionnalité native de l'app déjà installée et payée.

### 1.6 Marketing

- GA4 et Meta Pixel configurés (variables d'environnement présentes en production).
- Un token `SHOPIFY_MARKETING_ADMIN_TOKEN` existe en production — **usage exact non identifié**, à clarifier avec toi avant d'y toucher.
- Klaviyo installée mais avec une demande d'accès aux données en attente (non approuvée par cette session) — à vérifier si c'est bloquant pour des flows Klaviyo existants (bienvenue, panier abandonné, post-achat, demande d'avis...).

## 2. Ce qui fonctionne réellement aujourd'hui

- Catalogue public (ondeal.fr) : produits, prix, stock, images, traduction (au moins une app active), avis — tout branché sur Shopify en direct.
- Paiement/checkout : natif Shopify, fonctionnel par construction.
- Récupération de panier abandonné : Shopify Flow actif.
- Import et catégorisation du catalogue CJ → Shopify : fonctionnel via scripts manuels.
- Connexion technique CJ ↔ Shopify (produits) : fonctionnelle et active.

## 3. Ce qui est manuel aujourd'hui

- **Paiement/transmission de la commande au fournisseur CJ** (Auto Pay Order désactivé).
- **Résolution des « commandes invalides »** CJ (association produit) — mécanisme manuel qui existera pour toute future commande passant par un mauvais mapping produit CJ (la seule occurrence connue à ce jour, #1001, n'est pas concernée : elle a été traitée hors CJ, via BigBuy).
- **Envoi du bon d'achat 15€** même quand le Flow détecte l'éligibilité.
- **Suivi de commande / tracking client** — rien ne pousse automatiquement le tracking CJ vers le client au-delà de ce que Shopify fait nativement une fois la commande marquée expédiée (et cette étape elle-même dépend du paiement fournisseur manuel).
- **Traduction** — 6 apps installées, laquelle est réellement pilotée en continu n'est pas clair.
- **Mise à jour prix/stock CJ → Shopify** — scripts existants mais déclenchement manuel (`npm run catalog:*`), pas de planification automatique identifiée.

## 4. Ce qui manque totalement

- Aucun système de commissions / ventes affiliées (mentionné dans ton exemple de tableau de bord — rien de tel n'existe dans le code ni dans les apps installées).
- Aucun SAV structuré (pas de ticketing, pas d'automatisation de réponse client).
- Aucune page « Mes commandes » connectée à la réalité (données fictives).
- Aucun tableau de bord de traçabilité par commande (le parcours ✓/✓/✓ que tu décris n'existe nulle part aujourd'hui — ni dans Shopify natif, ni dans le code, ni dans CJ à lui seul).
- Aucun webhook ni route API côté Next.js — toute automatisation événementielle future devra créer cette couche (`src/app/api/webhooks/*`), qui n'existe pas encore.

## 5. Plan d'automatisation proposé (à valider avant toute exécution)

Principes non négociables rappelés : réutiliser Shopify Flow, CJdropshipping, Judge.me, Klaviyo existants avant de coder quoi que ce soit de nouveau ; ne jamais casser l'existant ; tester après chaque domaine ; toute automatisation validée doit tourner sans intervention humaine ; toute action à risque financier ou irréversible reste soumise à ta confirmation explicite.

| # | Domaine | Proposition | Risque / confirmation nécessaire |
|---|---|---|---|
| 1 | Résolution des futures « commandes invalides » CJ | Aucune action requise pour #1001 (traitée hors CJ, via BigBuy, déjà réglée). Prévoir malgré tout une vérification régulière du bucket « Commandes invalides » CJ pour toute future commande mal mappée, tant que #2 ci-dessous n'est pas actif | Aucun risque technique — simple point de vigilance opérationnelle |
| 2 | Fournisseur — paiement auto | Activer `Auto Pre-occupy Stock` puis `Auto Pay Order` dans CJ, d'abord en observation sur 1-2 commandes réelles avant généralisation | **Impact financier direct (CJ paie le fournisseur automatiquement)** — confirmation explicite obligatoire, test progressif |
| 3 | Traçabilité commande | Créer une vue interne (nouvelle page admin ou export) qui agrège Shopify (statut paiement) + CJ (statut fournisseur/tracking) + Judge.me (avis reçu) par commande, sans dupliquer aucune donnée déjà gérée par ces systèmes | Lecture seule, faible risque — mais nécessite de créer la 1ère route API du projet |
| 4 | Suivi/tracking client | Une fois #2 actif, vérifier si le tracking CJ remonte automatiquement dans Shopify (nativement, via le connecteur) ; sinon, webhook CJ → mise à jour fulfillment Shopify | Dépend de #2, tests requis |
| 5 | Page « Mes commandes » | Remplacer `mockOrders` par les vraies commandes Shopify du client connecté (Customer Account API) | Ne casse rien d'existant si fait en parallèle puis basculé après tests |
| 6 | Bon d'achat 15€ | Étendre le Flow existant pour envoyer automatiquement le bon (Shopify a un objet natif compatible) au lieu du seul email interne | Faible risque, un seul Flow déjà existant à étendre |
| 7 | Traduction | Auditer les 6 apps installées, désinstaller les inutilisées | Aucun risque technique, économie potentielle d'abonnements — confirmation souhaitée avant désinstallation |
| 8 | Demandes d'avis automatiques | Confirmer si Judge.me « Programmer des demandes » est déjà actif ; si oui, ne rien construire en parallèle | Vérification uniquement |
| 9 | Commissions/affiliation | Clarifier avec toi ce que « ventes affiliées » signifie concrètement pour OnDeal avant de concevoir quoi que ce soit — rien n'existe aujourd'hui, c'est une construction complète | Nécessite ta définition du besoin avant tout code |
| 10 | SAV | Clarifier le rôle réel de l'app "Messaging" déjà installée avant de proposer un nouveau système | Vérification d'abord |

## 6. Prochaine étape proposée

Valider ensemble l'ordre de priorité ci-dessus (le point 2 — paiement fournisseur automatique — est probablement le plus impactant mais aussi le plus sensible financièrement). Une fois un domaine validé, je l'implémente, je teste, je documente, puis je passe au suivant — jamais plusieurs domaines en parallèle, pour respecter la règle « ne pas casser une fonctionnalité existante pour en automatiser une autre ».
