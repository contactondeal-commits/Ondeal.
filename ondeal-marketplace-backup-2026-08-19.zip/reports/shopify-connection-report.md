# Rapport de connexion Shopify — Storefront API réelle

**Date** : 13/08/2026
**Mode** : Lecture seule stricte — aucune mutation Shopify effectuée (aucun produit, prix, stock, variante, tag, collection ou statut modifié).
**Statut global** : **BLOCKED** (connexion authentifiée avec succès, mais bloquée en pratique par un scope Storefront manquant sur le token fourni — voir section 9).

---

## 1. Store connecté

**Oui, partiellement.** Le token fourni (`SHOPIFY_STOREFRONT_ACCESS_TOKEN=750c2f1f2db1ba980f7510e9db1fba1a`, transmis par l'utilisateur — token PUBLIC de l'API Storefront visible dans la capture d'écran du canal Headless "OnDeal") a été testé en lecture seule contre l'API Shopify réelle. L'authentification réussit et est bien liée à la boutique de production :

```
query { shop { name primaryDomain { url } } }
→ { "shop": { "name": "Ondeal", "primaryDomain": { "url": "https://ondeal.fr" } } }
```

Ceci confirme que ce token correspond bien à la boutique qui sert (ou servira) `ondeal.fr`, et pas à une autre boutique de test.

Ce token a été **retiré de la configuration active** après les tests (voir section 9) car il fait actuellement échouer `npm run build` — la valeur reste conservée en commentaire dans `.env.local`, prête à être réactivée dès que le blocage est levé.

## 2. Domaine

- `SHOPIFY_STORE_DOMAIN = 6mvti7-9g.myshopify.com` — présent dans `.env.local`, confirmé correct (correspond exactement à `shop.primaryDomain` de la boutique réelle interrogée ci-dessus).
- Domaine public cible : `ondeal.fr` — confirmé comme domaine primaire de cette même boutique côté Shopify (`primaryDomain.url`). Rappel (voir `reports/marketplace-interface-connexion.md`) : `ondeal.fr` sert aujourd'hui le thème natif Shopify, pas ce projet Next.js — un déploiement/bascule DNS reste une étape séparée, non traitée dans cette mission.

## 3. Storefront API

- **Authentification** : ✅ réussie (`SHOPIFY_STORE_DOMAIN` + token public valides et cohérents).
- **Version d'API utilisée** : `2026-07` (`src/lib/shopify/config.ts`).
- **Lecture produits** (`query { products { ... } }`, hors champ `totalInventory`) : ✅ réussie — titres, handles, vendor, tags, `productType`, prix (`priceRange`/`compareAtPriceRange`), images (URLs réelles `cdn.shopify.com`), variantes (`id`, `availableForSale`) tous correctement retournés.
- **Lecture par tag catégorie** (`tag:cat-*`, convention canonique de l'app) : mécanisme identique, non bloqué par un problème de syntaxe — bloqué par le même souci de scope que la requête catalogue générale (section 9).
- **Lecture collections** : ✅ réussie (`collections(first: 5)`) — 5 collections réelles retournées (ex: "Vêtements pour Femmes", "High-Tech & Accessoires"…).
- **Lecture metafields** (`reviews.rating`) : ✅ réussie (champ interrogeable, valeur `null` car non renseignée sur les produits testés — comportement normal, pas une erreur).
- **Champ `totalInventory`** : ❌ **refusé** par l'API — `Access denied for totalInventory field. Required access: unauthenticated_read_product_inventory access scope.` C'est le seul point de blocage identifié (détail section 9).

## 4. Nombre de produits accessibles

Le comptage exhaustif via l'app n'a pas pu être finalisé : la requête réelle de l'application (`PRODUCT_FRAGMENT` dans `src/lib/shopify/storefront.ts`) inclut `totalInventory`, donc **échoue systématiquement** avec le scope actuel du token, y compris pour un simple comptage. Avec une requête de diagnostic n'incluant pas ce champ, un échantillon de produits a été lu avec succès à chaque appel testé (échantillons de 2 et 5 produits) — la lecture du catalogue fonctionne techniquement, mais un compte exhaustif fiable nécessite d'abord de lever le blocage du scope (section 9) plutôt que d'être estimé indirectement.

Pour référence, le dernier compte exact vérifié du catalogue (via l'API Admin, mission d'audit précédente) est de **~893 produits ACTIVE** — voir `reports/project-final-audit.md`.

## 5. Catégories accessibles

Mécanisme vérifié fonctionnel au niveau requête (filtrage par `tag:cat-<id>`, ex. `tag:cat-bijoux`), mais soumis au même blocage `totalInventory` que le reste du catalogue tant que le scope n'est pas corrigé. Les collections Shopify natives (distinctes du système de tags `cat-*` utilisé par l'app pour la navigation) sont lisibles sans restriction (5 collections confirmées, section 3).

## 6. Panier

✅ **Fonctionne réellement, testé en conditions réelles (non destructif).** `createShopifyCart` (`src/lib/shopify/cart.ts`, mutation `cartCreate`) a été testé avec une ligne réelle (1 variante, quantité 1) :

- Panier créé avec succès : `cart.id = gid://shopify/Cart/hWNFbyAfzvdSTFWKEWa2QIWg?key=...`
- `checkoutUrl` retourné, avec pour nom d'hôte **`ondeal.fr`** — confirme que le checkout Shopify est déjà correctement routé vers le domaine public de la boutique.

Un panier Shopify créé sans commande passée est un artefact normal et sans conséquence (aucune donnée produit/stock/prix modifiée — c'est l'usage prévu de cette fonctionnalité, identique à ce qui se produit pour tout visiteur réel).

## 7. Checkout

✅ Le mécanisme `createShopifyCart` → redirection vers `checkoutUrl` (`src/app/actions/shopify-checkout.ts` → `src/app/checkout/page.tsx`) est confirmé fonctionnel de bout en bout au niveau de l'API — le `checkoutUrl` réel pointant vers `ondeal.fr` a été obtenu avec succès (section 6). Le paiement lui-même reste intégralement géré par Shopify (non testé plus loin, hors périmètre lecture seule/non destructif).

## 8. Stock

⚠️ **Non vérifiable avec le token actuel.** Le champ `totalInventory`, utilisé par `mapStorefrontProduct` pour calculer `stock` (nombre affiché) et en repli pour `inStock`, est refusé par l'API (`unauthenticated_read_product_inventory` manquant). La disponibilité (`availableForSale` par variante) est en revanche lisible sans restriction et reste la source principale de `inStock` dans le code actuel — seul le **nombre exact d'unités en stock** affiché au client ne peut pas être vérifié/servi tant que ce scope n'est pas activé.

## 9. Erreurs

**Erreur unique, mais bloquante pour l'ensemble du pipeline catalogue tel que codé actuellement :**

```
Access denied for totalInventory field.
Required access: `unauthenticated_read_product_inventory` access scope.
```

**Conséquence concrète constatée** : avec `SHOPIFY_STOREFRONT_ACCESS_TOKEN` configuré, `npm run build` **échoue complètement** (`Failed to collect page data for /product/[slug]`), car `generateStaticParams` appelle `fetchAllProducts()` → Shopify réel → requête refusée. Home, catégories, recherche, et pages produit auraient le même échec au runtime (désormais intercepté proprement par `src/app/error.tsx`, ajouté lors de la mission précédente, plutôt que de crasher sans message — mais aucune page catalogue ne pourrait afficher de vraies données).

**Deux façons de lever ce blocage — aucune n'a été appliquée dans cette mission (hors périmètre lecture seule/pas de modification Shopify sans autorisation explicite) :**

- **Option A — recommandée** : activer le scope Storefront `unauthenticated_read_product_inventory` (lecture des quantités d'inventaire) sur le canal Headless "OnDeal" dans l'Admin Shopify (Admin > Canaux de vente > Headless > OnDeal > configuration des scopes API Storefront). Ne dégrade aucune fonctionnalité — c'est la correction complète.
- **Option B — repli côté code, nécessite une autorisation explicite séparée** : retirer `totalInventory` de `PRODUCT_FRAGMENT` (`src/lib/shopify/storefront.ts`) et adapter `mapStorefrontProduct` pour ne plus afficher de nombre d'unités en stock exact (garder `inStock` basé uniquement sur `availableForSale`, qui fonctionne déjà sans restriction). Cette option fait fonctionner le catalogue immédiatement mais réduit l'information affichée au client (plus de "X disponibles" précis) — c'est un changement de comportement produit, pas une simple correction de bug, donc non appliqué sans validation explicite de votre part.

**Aucune autre erreur** rencontrée : authentification, lecture produits/prix/images/variantes/tags/collections/metafields, et `cartCreate` fonctionnent tous sans erreur dès lors que `totalInventory` n'est pas demandé.

## 10. Tests

- `npx tsc --noEmit` → ✅ OK, 0 erreur (état final, token désactivé)
- `npm run lint` → ✅ OK, 0 erreur
- `npm run build` → ✅ OK, 161 pages générées (état final, token désactivé — voir ci-dessus pour le comportement avec le token actif)
- `git status` : seul fichier modifié par cette mission = `.env.local` (non suivi par git — `.env*` dans `.gitignore`, confirmé vide de tout secret dans l'arbre suivi). Aucun fichier source (`src/`, `docs/`) modifié. Aucun outil `mcp__Shopify__*` appelé — uniquement des scripts `tsx` temporaires locaux (`scripts/_tmp_verify_*.ts`, supprimés après usage) exécutant le code applicatif réel via `fetch()` HTTP direct vers l'API Storefront.

---

## Addendum — vérification de la valeur transmise comme « token privé »

Après ce rapport, la valeur `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` a été transmise pour tester le token privé Storefront masqué dans la capture d'écran d'origine. Testée en lecture seule (`shop { name myshopifyDomain }`) :

| Endpoint testé | Résultat |
|---|---|
| Storefront API (`/api/2026-07/graphql.json`, header `X-Shopify-Storefront-Access-Token`) | ❌ `HTTP 401 Unauthorized` |
| Admin API (`/admin/api/2026-07/graphql.json`, header `X-Shopify-Access-Token`) | ✅ OK — `{"shop":{"name":"Ondeal","myshopifyDomain":"6mvti7-9g.myshopify.com"}}` |

**Conclusion factuelle** : cette valeur est un **token API Admin** (accès complet en lecture/écriture au catalogue), pas un token API Storefront. Elle ne peut donc pas remplacer `SHOPIFY_STOREFRONT_ACCESS_TOKEN` et ne résout pas le blocage décrit en section 9. Configurée dans `.env.local` sous `SHOPIFY_ADMIN_ACCESS_TOKEN` (utile pour les scripts `npm run catalog:*` existants), **jamais utilisée pour une écriture** dans cette session, et jamais utilisable par le frontend public par conception du projet (`src/lib/shopify/admin.ts`).

## Prochaine étape recommandée

D'après la documentation Shopify officielle (shopify.dev, vérifiée le 13/08/2026) : *« Both Storefront and Admin API permissions are shared across all storefronts »* et se configurent via **Admin Shopify > Canaux de vente > Headless > [le storefront "OnDeal"] > carte « Storefront API permissions » > Edit > cocher/décocher les permissions > Save**. C'est là que la permission d'inventaire manquante doit être activée.

1. Dans cette carte, activer la permission de lecture de l'inventaire (correspond au scope `unauthenticated_read_product_inventory`).
2. Une fois fait, retransmettre le token Storefront **public** (`750c2f1f2db1ba980f7510e9db1fba1a`, déjà testé et fonctionnel pour tout le reste) pour relancer cette vérification : la connexion devrait alors réussir intégralement (produits, catégories, stock, panier, checkout).
3. Alternative si vous préférez ne pas toucher aux permissions Shopify maintenant : autoriser explicitement l'Option B (repli code, affichage stock dégradé) pour une mission dédiée.

```
SHOPIFY_STOREFRONT_ACCESS_TOKEN = BLOCKED (authentification OK, scope unauthenticated_read_product_inventory manquant)
SHOPIFY NON MODIFIÉ
AUCUNE MUTATION SHOPIFY
```
