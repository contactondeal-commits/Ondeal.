import type { Metadata } from "next";
import Breadcrumbs from "@/components/navigation/Breadcrumbs";
import { SITE_DESCRIPTION } from "@/lib/site-config";
import { COMPANY_EMAIL } from "@/lib/company-info";
import styles from "../info-page.module.css";

export const metadata: Metadata = {
  title: "À propos de nous",
  description: SITE_DESCRIPTION,
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <div className={`${styles.page} container`}>
      <Breadcrumbs items={[{ label: "Accueil", href: "/" }, { label: "À propos de nous" }]} />

      <header className={styles.header}>
        <h1>À propos de nous</h1>
        <p className={styles.intro}>{SITE_DESCRIPTION}</p>
      </header>

      <section className={styles.section}>
        <h2>Notre mission</h2>
        <p>
          OnDeal réunit des milliers de produits sélectionnés dans les catégories high-tech, maison, mode, sport et
          plus encore, pour vous permettre de trouver ce qu&apos;il vous faut au meilleur prix, avec une navigation
          rapide et une expérience d&apos;achat fiable.
        </p>
      </section>

      <section className={styles.section}>
        <h2>Qui sommes-nous ?</h2>
        <p>
          OnDeal est édité par Alex Brou, entrepreneur individuel. Le site s&apos;appuie sur une plateforme
          e-commerce sécurisée (Shopify) pour la gestion des commandes, des paiements et des comptes clients.
        </p>
      </section>

      <p className={styles.contactLine}>
        Une question sur OnDeal ? Contactez-nous à <a href={`mailto:${COMPANY_EMAIL}`}>{COMPANY_EMAIL}</a>.
      </p>
    </div>
  );
}
