import Link from "next/link";
import { User, Package, Heart, MapPin, CreditCard, Settings, LogOut } from "lucide-react";
import styles from "./layout.module.css";

const NAV_ITEMS = [
  { href: "/account", label: "Tableau de bord", icon: User },
  { href: "/account/orders", label: "Mes commandes", icon: Package },
  { href: "/account/wishlist", label: "Mes favoris", icon: Heart },
  { href: "/account/profile", label: "Mes informations", icon: Settings },
];

export default function AccountLayout(props: LayoutProps<"/account">) {
  return (
    <div className={`${styles.page} container`}>
      <aside className={styles.sidebar}>
        <p className={styles.greeting}>Bonjour, Utilisateur</p>
        <nav aria-label="Navigation du compte">
          <ul className={styles.navList}>
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              return (
                <li key={item.href}>
                  <Link href={item.href} className={styles.navLink}>
                    <Icon size={17} /> {item.label}
                  </Link>
                </li>
              );
            })}
            <li>
              <span className={styles.navLink}>
                <MapPin size={17} /> Mes adresses
              </span>
            </li>
            <li>
              <span className={styles.navLink}>
                <CreditCard size={17} /> Mes moyens de paiement
              </span>
            </li>
            <li>
              <button type="button" className={`${styles.navLink} ${styles.logout}`}>
                <LogOut size={17} /> Déconnexion
              </button>
            </li>
          </ul>
        </nav>
      </aside>
      <div className={styles.content}>{props.children}</div>
    </div>
  );
}
