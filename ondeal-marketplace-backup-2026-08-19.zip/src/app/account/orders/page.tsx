import type { Metadata } from "next";
import Link from "next/link";
import { mockOrders } from "@/data/orders";
import { products } from "@/data/products";
import PlaceholderImage from "@/components/ui/PlaceholderImage";
import { formatPrice } from "@/lib/format";
import styles from "./page.module.css";

export const metadata: Metadata = { title: "Mes commandes", robots: { index: false, follow: false } };

const STATUS_STYLES: Record<string, string> = {
  Livrée: styles.statusDelivered,
  Expédiée: styles.statusShipped,
  "En préparation": styles.statusPreparing,
  Annulée: styles.statusCancelled,
};

export default function OrdersPage() {
  return (
    <div>
      <h1>Mes commandes</h1>

      {mockOrders.length === 0 ? (
        <p>Vous n&apos;avez pas encore passé de commande.</p>
      ) : (
        <div className={styles.list}>
          {mockOrders.map((order) => (
            <div key={order.id} className={styles.card}>
              <div className={styles.header}>
                <div>
                  <p className={styles.orderId}>{order.id}</p>
                  <p className={styles.date}>Commandée le {order.date}</p>
                </div>
                <span className={`${styles.status} ${STATUS_STYLES[order.status]}`}>{order.status}</span>
              </div>
              <div className={styles.items}>
                {order.items.map((item) => {
                  const product = products.find((p) => p.id === item.productId);
                  if (!product) return null;
                  return (
                    <Link key={item.productId} href={`/product/${product.slug}`} className={styles.item}>
                      <PlaceholderImage seed={product.images[0]} className={styles.itemImage} label={product.title} />
                      <div>
                        <p className={styles.itemTitle}>{product.title}</p>
                        <p className={styles.itemQty}>Quantité : {item.quantity}</p>
                      </div>
                    </Link>
                  );
                })}
              </div>
              <div className={styles.footer}>
                <span>Total</span>
                <span className={styles.total}>{formatPrice(order.total)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
