import { redirect } from "next/navigation";
import { SHOPIFY_ACCOUNT_URL } from "@/lib/site-config";

// Mission "CONNEXION CLIENT" (15/08/2026) — toute la section /account
// personnalisée (tableau de bord, commandes, profil, adresses, moyens de
// paiement — auparavant protégée par un cookie de session + mot de passe
// classique Storefront API) est remplacée par une redirection vers le
// portail natif Shopify. Détail complet du diagnostic et de la décision :
// voir SHOPIFY_ACCOUNT_URL dans src/lib/site-config.ts. Les favoris (qui
// n'avaient rien à voir avec le compte client Shopify — stockage local
// uniquement) ont été déplacés vers /wishlist, en dehors de cette section.
export default function AccountRedirectPage() {
  redirect(SHOPIFY_ACCOUNT_URL);
}
