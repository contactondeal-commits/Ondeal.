"use server";

import { fetchProductsByIds } from "@/services/productService";
import type { Product } from "@/types";

/**
 * Mission "GAINS RAPIDES CROISSANCE" (19/08/2026) — "Produits récemment
 * consultés". Même pont "use client" → Shopify que fetchWishlistProducts
 * (wishlist.ts) : le composant client n'a jamais accès direct à l'API
 * Shopify, seulement à cette Server Action. Ordre des résultats préservé
 * (Shopify `nodes(ids:)` renvoie dans l'ordre demandé, voir
 * fetchShopifyProductsByIds dans storefront.ts) : les ids sont passés
 * du plus récemment consulté au moins récent.
 *
 * Validation défensive identique à wishlist.ts, section 17 de l'audit
 * sécurité du 15/08/2026 : une Server Action est un point d'entrée public.
 */
const MAX_RECENTLY_VIEWED_IDS = 50;

export async function fetchRecentlyViewedProducts(ids: unknown): Promise<Product[]> {
  if (!Array.isArray(ids)) return [];
  const validIds = ids.filter((id): id is string => typeof id === "string" && id.length > 0).slice(0, MAX_RECENTLY_VIEWED_IDS);
  if (validIds.length === 0) return [];
  return fetchProductsByIds(validIds);
}
