import type { Metadata, Viewport } from "next";
import "./globals.css";
import SiteLayout from "@/components/layout/SiteLayout";
import AnalyticsScripts from "@/components/analytics/AnalyticsScripts";
import CookieConsentBanner from "@/components/analytics/CookieConsentBanner";
import { SITE_DESCRIPTION, SITE_NAME, SITE_URL } from "@/lib/site-config";

// Mission IDENTITÉ VISUELLE OFFICIELLE ONDEAL (2026-08-13) — applicationName,
// appleWebApp.title et twitter card ajoutés : uniquement le vrai nom de
// marque déjà utilisé partout ailleurs dans le projet (SITE_NAME), aucune
// donnée inventée. Les icônes (favicon.ico, icon.png, apple-icon.png) et
// l'image Open Graph (opengraph-image.png) sont détectées automatiquement
// par Next.js via les conventions de fichiers dans src/app/ — voir
// reports/ondeal-branding-audit.md section 8.
export const metadata: Metadata = {
  title: {
    default: `${SITE_NAME} — Votre marketplace au meilleur prix`,
    template: `%s | ${SITE_NAME}`,
  },
  description: SITE_DESCRIPTION,
  metadataBase: new URL(SITE_URL),
  applicationName: SITE_NAME,
  appleWebApp: {
    title: SITE_NAME,
    capable: true,
    statusBarStyle: "default",
  },
  openGraph: {
    title: `${SITE_NAME} — Votre marketplace au meilleur prix`,
    description: "Des milliers de produits, une navigation rapide, une expérience fiable.",
    siteName: SITE_NAME,
    type: "website",
    locale: "fr_FR",
  },
  twitter: {
    card: "summary_large_image",
    title: `${SITE_NAME} — Votre marketplace au meilleur prix`,
    description: "Des milliers de produits, une navigation rapide, une expérience fiable.",
  },
};

export const viewport: Viewport = {
  themeColor: "#0c1f32",
};

export default function RootLayout(props: LayoutProps<"/">) {
  return (
    <html lang="fr">
      <body>
        <SiteLayout>{props.children}</SiteLayout>
        <AnalyticsScripts />
        <CookieConsentBanner />
      </body>
    </html>
  );
}
