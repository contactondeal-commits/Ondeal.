import type { Metadata } from "next";
import Breadcrumbs from "@/components/navigation/Breadcrumbs";
import { HELP_SECTIONS } from "@/app/help/help-data";
import styles from "../legal.module.css";

export const metadata: Metadata = {
  title: "Retours & remboursements",
  description: "Conditions de retour et de remboursement Ondeal.",
  alternates: { canonical: "/legal/retours" },
};

/**
 * Mission CRO Phase 1 (2026-08-13) — P0-3 : le lien footer "Retours"
 * pointait vers la FAQ générique /help. Cette page dédiée réutilise le
 * contenu réel déjà présent dans le projet (src/app/help/help-data.ts,
 * section "retours") — aucune information n'est inventée.
 */
export default function RetoursPage() {
  const section = HELP_SECTIONS.find((s) => s.id === "retours");

  return (
    <div className={`${styles.page} container`}>
      <Breadcrumbs items={[{ label: "Accueil", href: "/" }, { label: "Retours & remboursements" }]} />

      <header className={styles.header}>
        <h1>Retours & remboursements</h1>
        <p className={styles.intro}>Conditions de retour et de remboursement de vos commandes.</p>
      </header>

      {section?.items.map((item) => (
        <section key={item.id} className={styles.section}>
          <h2>{item.question}</h2>
          <p>{item.answer}</p>
        </section>
      ))}

      <p className={styles.contactLine}>
        Une question sur un retour ou un remboursement ?{" "}
        <a href="mailto:contact@ondeal.fr">contact@ondeal.fr</a>.
      </p>
    </div>
  );
}
