import { redirect } from "next/navigation";
import { SHOPIFY_ACCOUNT_URL } from "@/lib/site-config";

// Mission "CONNEXION CLIENT" (15/08/2026) — cette page /login personnalisée
// (mot de passe classique, Storefront API) est remplacée par une redirection
// vers le portail natif Shopify. Diagnostic complet et raison du changement :
// voir SHOPIFY_ACCOUNT_URL dans src/lib/site-config.ts. Cette route est
// conservée (plutôt que supprimée) uniquement pour ne jamais renvoyer une 404
// sur d'éventuels liens déjà partagés/indexés vers /login.
export default function LoginRedirectPage() {
  redirect(SHOPIFY_ACCOUNT_URL);
}
