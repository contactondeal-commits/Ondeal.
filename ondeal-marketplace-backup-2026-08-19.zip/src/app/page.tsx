import type { Metadata } from "next";
import Hero from "@/components/home/Hero";
import CategoryBlocks from "@/components/home/CategoryBlocks";
import ProductSection from "@/components/home/ProductSection";
import ProductCarouselSection from "@/components/home/ProductCarouselSection";
import RecentlyViewedSection from "@/components/products/RecentlyViewedSection";
import { categories, getAllCategoriesFlat } from "@/data/categories";
import type { Product } from "@/types";
import { fetchAllProducts, fetchBestsellers, fetchDeals, fetchNewArrivals, fetchProductsByCategory, fetchProductsByIds, sortProducts } from "@/services/productService";

// Mission autonome (15/08/2026) — audit SEO réel : la balise <title> de la
// page d'accueil (la page la plus stratégique du site pour le SEO) était
// littéralement "Accueil" (vérifié dans le HTML servi : `<title>Accueil</title>`,
// sans le nom de marque ni mot-clé) — le title.template du layout racine
// ("%s | Ondeal") ne s'applique pas ici pour une raison propre à cette
// version de Next.js (voir AGENTS.md : "breaking changes" par rapport aux
// conventions habituelles). Plutôt que de dépendre d'un mécanisme de
// template qui ne se comporte pas comme attendu sur la page la plus
// importante du site, on retire `title` ici : la page hérite alors
// directement du `default` du layout racine
// ("Ondeal — Votre marketplace au meilleur prix", src/app/layout.tsx) —
// déjà rédigé avec la marque et la proposition de valeur, déjà réutilisé
// pour Open Graph/Twitter, donc cohérent partout.
export const metadata: Metadata = {
  description: "Des milliers de produits high-tech, maison, mode, sport et plus, livrés rapidement au meilleur prix.",
  alternates: { canonical: "/" },
};

/**
 * Mission CRO Phase 1 (2026-08-13) — P0-2 : le tag Shopify `promotion` n'est
 * réellement présent que sur 1 produit / 970 (reports/shopify-live-catalog-audit.json).
 * Afficher une section "Offres du moment" avec seulement 1 (ou 0) produit
 * réel nuit à la crédibilité perçue dès la page d'accueil (promesse non
 * tenue). Tant qu'aucune vraie politique de prix barrés n'est en place côté
 * Shopify, la section reste masquée en dessous de ce seuil plutôt que
 * d'afficher un nombre de produits non crédible. Aucune donnée n'est
 * inventée : on choisit seulement de ne pas afficher une section
 * quasi-vide sous un intitulé qui promet une sélection.
 */
const MIN_DEALS_TO_SHOW_SECTION = 4;

/**
 * Mission "REFONTE CIBLÉE DU BLOC DÉCOUVREZ NOS CATÉGORIES" (14/08/2026) —
 * un produit "vitrine" réel par catégorie de premier niveau, pour le
 * carrousel merchandising de la homepage (voir CategoryBlocks.tsx).
 *
 * Règle absolue de la mission : ne jamais inventer de promotion/prix/remise.
 * `oldPrice`/`discount` viennent uniquement de `compareAtPriceRange` réel
 * Shopify (voir src/lib/shopify/storefront.ts, `hasDiscount = compareAt >
 * price`) — jamais calculés ou simulés ici. Sélection, par catégorie, parmi
 * les 6 meilleurs candidats (remise réelle d'abord, puis popularité/note) :
 *   1. le produit avec la plus forte remise RÉELLE, s'il en existe une ;
 *   2. sinon le produit le plus vendu (puis le mieux noté).
 *
 * Exclusions manuelles (vérification visuelle faite pendant cette mission,
 * voir CategoryBlocks.tsx) : certaines photos produit réelles portent du
 * texte publicitaire fournisseur incrusté qui nuit fortement au rendu
 * ("Amélioré...", bandeaux promo, montages multi-vignettes, infographie en
 * allemand avec références SKU). Dans ce cas, le candidat suivant (une autre
 * vraie photo d'un autre vrai produit de la même catégorie) est utilisé à la
 * place — jamais une image retouchée ou inventée. `HERO_IMAGE_EXCLUDED_SLUGS`
 * liste les seuls produits ainsi écartés, avec la raison constatée.
 */
const HERO_IMAGE_EXCLUDED_SLUGS = new Set([
  // Texte publicitaire fournisseur incrusté dans la photo ("Upgraded ...").
  "industry-gaming-keyboard-glowing-usb-cable-gaming-keyboard",
  // Texte publicitaire fournisseur incrusté ("Gaming Keyboard Mouse Set").
  "gtx300-gaming-cf-lol-gaming-keyboard-mouse-glowing-set",
  // Texte publicitaire fournisseur incrusté ("GAME KEY FREELY SET").
  "gaming-keyboard-throne-one-mouse-set",
  // Texte publicitaire fournisseur incrusté ("4D Stereo Sound", logo marque).
  "compatible-with-apple-4d-computer-speaker-bar-stereo-sound-subwoofer-bluetooth-speaker-for-macbook-laptop-notebook-pc-music-player-wired-loudspeaker",
  // Montage/collage multi-vignettes peu lisible en grand format carrousel.
  "kit-dassemblage-3-en-1-serre-joints-dangle-gants-et-metre",
  // Montage multi-panneaux peu lisible en grand format carrousel.
  "parachute-de-jeu-arc-en-ciel-2-4-m-avec-12-balles",
  // Montage multi-panneaux peu lisible en grand format carrousel.
  "coffret-3-livres-de-coloriage-fleurs-chateau-et-vase",
  // Infographie en allemand avec références SKU, inexploitable en carrousel.
  "lot-de-15-filtres-de-rechange-pour-fontaine-a-eau-chat",
]);

async function fetchCategoryHeroProducts(): Promise<Record<string, Product | null>> {
  const entries = await Promise.all(
    categories.map(async (cat) => {
      const ids = getAllCategoriesFlat([cat]).map((c) => c.id);
      const catProducts = await fetchProductsByCategory(ids);
      if (catProducts.length === 0) return [cat.id, null] as const;

      const discounted = catProducts
        .filter((p) => typeof p.discount === "number" && p.discount > 0)
        .sort((a, b) => (b.discount ?? 0) - (a.discount ?? 0));
      const byPopularity = [...catProducts].sort(
        (a, b) => b.salesCount - a.salesCount || b.rating - a.rating
      );
      const ranked = [...discounted, ...byPopularity.filter((p) => !discounted.includes(p))];

      // Premier candidat, dans l'ordre de pertinence commerciale ci-dessus,
      // dont l'image n'a pas été manuellement écartée pour texte publicitaire
      // incrusté / montage illisible (voir HERO_IMAGE_EXCLUDED_SLUGS).
      const usable = ranked.find((p) => !HERO_IMAGE_EXCLUDED_SLUGS.has(p.slug));
      return [cat.id, usable ?? null] as const;
    })
  );
  return Object.fromEntries(entries);
}

/**
 * Mission "PLAN MARKETING" (15/08/2026), section 3 du plan — Bijoux est la
 * catégorie recommandée en priorité : catalogue profond (149 produits, voir
 * le plan) ET fraîchement remis en visibilité (correctif du bug de tags
 * Shopify, voir CHANGELOG). "Bijoux" est une sous-catégorie (rattachée à
 * "Mode"), donc absente du carrousel CategoryBlocks (qui ne couvre que les
 * catégories de premier niveau) — mise en avant dédiée ici plutôt que
 * d'attendre qu'elle apparaisse noyée dans "Mode".
 */
const FEATURED_CATEGORY_ID = "bijoux";
const FEATURED_CATEGORY_TITLE = "Bijoux — à découvrir";
const FEATURED_CATEGORY_HREF = "/category/bijoux";

/**
 * Mission "GAMME RENTRÉE" (19/08/2026) — demande explicite du client. Audit
 * du catalogue Shopify réel (via Admin, l'API Storefront ne remonte pas les
 * produits Archivés) : plusieurs centaines de vrais produits rentrée
 * scolaire (cartables/sacs à dos, trousses, papeterie — marques Safta,
 * BlackFit8, Kappa, Munich, Kelme, Real Madrid C.F., Harper & Neyer, et
 * licences enfants Jurassic World / Snoopy / Vicky Martín Berrocal) étaient
 * en stock réel (10 unités, quelques-uns à 1) mais en statut Archivé —
 * donc invisibles sur le site alors que vendables. Réactivés (statut Actif)
 * pour cette mise en avant, sélection volontairement CURATÉE (pas
 * l'intégralité des ~300+ produits archivés trouvés) pour une vitrine
 * qualitative plutôt qu'un mur de doublons quasi identiques (mêmes cartables
 * en plusieurs tailles) — inspiré des pages "rentrée" des grands acteurs
 * (Fnac, Amazon Ads : sections thématiques courtes plutôt qu'une grille
 * unique géante). Deux sections : sacs à dos (le produit phare rentrée) et
 * trousses/papeterie (fournitures). Ids Shopify réels, jamais de produit
 * inventé — mêmes principes que HERO_IMAGE_EXCLUDED_SLUGS ci-dessus.
 */
const RENTREE_BACKPACK_IDS = [
  "gid://shopify/Product/16259201728847", // Cartable Jurassic World Marron 33x42x14
  "gid://shopify/Product/16259201466703", // Cartable Snoopy 26x34x11
  "gid://shopify/Product/16259201106255", // Cartable Vicky Martín Berrocal Multicouleur 32x42x15
  "gid://shopify/Product/16259198746959", // Cartable BlackFit8 Mariposas Multicouleur 32x42x15
  "gid://shopify/Product/16259198681423", // Cartable Safta Bouquet Rose Lila 33x42x14
  "gid://shopify/Product/16259198419279", // Cartable Safta Zone 32x42x15
  "gid://shopify/Product/16259197960527", // Cartable BlackFit8 Varsity Noir Vert 32x42x15
  "gid://shopify/Product/16259197469007", // Cartable Kappa Grey Noir Gris 32x42x15
  "gid://shopify/Product/16259196846415", // Cartable Munich Track Bleu Noir 31x43x13
  "gid://shopify/Product/16259196158287", // Cartable Real Madrid C.F. Bleu
  "gid://shopify/Product/16259197141327", // Cartable Kelme Blue Bleu 32x42x15
  "gid://shopify/Product/16259196289359", // Cartable Harper & Neyer 32x42x15
];
const RENTREE_SUPPLIES_IDS = [
  "gid://shopify/Product/16259201565007", // Carnet Snoopy A5 80 Volets
  "gid://shopify/Product/16259201532239", // Reliure à anneaux Snoopy A4 26.5x33x4
  "gid://shopify/Product/16259190784335", // Fourre-tout Jurassic World Marron 21x8x6
  "gid://shopify/Product/16259201270095", // Carnet Vicky Martín Berrocal Multicouleur A4 120 Volets
  "gid://shopify/Product/16259201204559", // Reliure à anneaux Vicky Martín Berrocal Multicouleur A4 27x33x6
  "gid://shopify/Product/16259170533711", // Trousse Scolaire avec Accessoires Vicky Martín Berrocal Mint paradise
  "gid://shopify/Product/16259190358351", // Fourre-tout Vicky Martín Berrocal Multicouleur 22x8,5x6
  "gid://shopify/Product/16259190620495", // Fourre-tout Snoopy Denim 22x8,5x6
  "gid://shopify/Product/16259190718799", // Fourre-tout Jurassic World Marron 22x12x3
  "gid://shopify/Product/16259190686031", // Fourre-tout Jurassic World Marron 12,5x19,5x5,5cm 37 Pièces
];

/**
 * Mission "GAMME RENTRÉE — extension" (19/08/2026) — demande explicite du
 * client : étendre la gamme Rentrée avec les catégories prioritaires de sa
 * liste (gourdes, informatique/bureau) au-delà des cartables/trousses
 * initiaux. Même méthode que RENTREE_BACKPACK_IDS/RENTREE_SUPPLIES_IDS :
 * audit du catalogue Shopify réel (recherche `vendor:Ondeal <mot-clé>` dans
 * l'admin), produits archivés pertinents réactivés un par un avec
 * vérification de statut, IDs Shopify réels uniquement. Volontairement PAS
 * étendu avec les trousses à licence (Spider-Man, Hello Kitty, Disney
 * Princesse, La Reine des Neiges) trouvées lors du même audit : signalées
 * par le client comme produits BigBuy dont la revente est interdite.
 */
const RENTREE_GOURDES_IDS = [
  "gid://shopify/Product/16259156476239", // Milk&Moo Gourde enfant inox Bunny rose 360ml
  "gid://shopify/Product/16259156410703", // Gourde enfant inox Milk&Moo Ponix 420ml bleu
  "gid://shopify/Product/16259156345167", // Milk&Moo Gourde enfant Mermaid 550ml acier violet
  "gid://shopify/Product/16259156246863", // Milk&Moo Gourde enfant inox Jungle Friends 550ml vert
];
const RENTREE_BUREAU_IDS = [
  "gid://shopify/Product/16259176661327", // Calculatrice Casio GR-12C-BU-W-EP
  "gid://shopify/Product/16258840527183", // Souris sans-fil Hama 00182699 Noir
  "gid://shopify/Product/16258856780111", // Hub USB Conceptronic HUBBIES13G Gris
];
const RENTREE_CAHIERS_IDS = [
  "gid://shopify/Product/16259180429647", // Cahier Minnie Mouse Rose
  "gid://shopify/Product/16259183640911", // Cahier à Spirale Pembe Le chat rose 80 Volets
  "gid://shopify/Product/16259182002511", // Carnet Safta Le chat rose
];

export default async function HomePage() {
  const [
    bestsellers,
    deals,
    newArrivals,
    allProducts,
    categoryHeroProducts,
    featuredCategoryProducts,
    rentreeBackpacks,
    rentreeSupplies,
    rentreeGourdes,
    rentreeBureau,
    rentreeCahiers,
  ] = await Promise.all([
      fetchBestsellers(10),
      fetchDeals(10),
      // Mission "GAMME RENTRÉE — carrousels produits" (19/08/2026) — demande
      // explicite du client : 100 dernières nouveautés (au lieu de 10) dans
      // un carrousel défilant plutôt qu'une grille classique — voir
      // ProductCarouselSection plus bas.
      fetchNewArrivals(100),
      fetchAllProducts(),
      fetchCategoryHeroProducts(),
      fetchProductsByCategory([FEATURED_CATEGORY_ID]),
      fetchProductsByIds(RENTREE_BACKPACK_IDS),
      fetchProductsByIds(RENTREE_SUPPLIES_IDS),
      fetchProductsByIds(RENTREE_GOURDES_IDS),
      fetchProductsByIds(RENTREE_BUREAU_IDS),
      fetchProductsByIds(RENTREE_CAHIERS_IDS),
    ]);
  const recommendations = sortProducts(allProducts, "rating").slice(0, 10);
  const showDeals = deals.length >= MIN_DEALS_TO_SHOW_SECTION;
  const featuredCategoryTop = sortProducts(featuredCategoryProducts, "rating").slice(0, 10);

  // Retour client (19/08/2026) — 5 carrousels rentrée séparés (dont 3 très
  // courts : gourdes, bureau, cahiers) faisaient trop de rangées fines côté
  // home. Regroupé en 2 rayons, conforme à la structure d'origine validée
  // (voir reports/gamme-rentree-strategie-commerciale.md, §3 : "sacs à dos &
  // cartables" + "trousses & papeterie") : un rayon cartables, un rayon qui
  // réunit tout le reste (trousses/papeterie/cahiers/gourdes/bureau) — même
  // produits réels, juste moins de découpage visuel. `Map` par id pour
  // éviter un doublon si jamais un même produit apparaissait dans deux
  // listes d'identifiants.
  const rentreeAutresFournitures = Array.from(
    new Map([...rentreeSupplies, ...rentreeCahiers, ...rentreeGourdes, ...rentreeBureau].map((p) => [p.id, p])).values()
  );

  // Mission "GAMME RENTRÉE — carrousel" (19/08/2026) — demande explicite du
  // client : la carte "Rentrée scolaire" du carrousel CategoryBlocks (voir
  // RENTREE_CARD dans ce composant) a besoin d'un vrai produit vitrine, au
  // même titre que les vraies catégories. Réutilise le premier cartable
  // réactivé pour la gamme Rentrée (déjà chargé ci-dessus, vrai prix/vraie
  // photo) — jamais de donnée inventée pour cette carte.
  const categoryHeroProductsWithRentree = {
    ...categoryHeroProducts,
    "rentree-scolaire": rentreeBackpacks[0] ?? null,
  };

  return (
    <>
      <Hero />
      <CategoryBlocks heroProducts={categoryHeroProductsWithRentree} />
      {(rentreeBackpacks.length > 0 || rentreeAutresFournitures.length > 0) && (
        <div id="rentree">
          {/* Mission "GAMME RENTRÉE — carrousels produits" (19/08/2026) —
              demande explicite du client : les sections rentrée doivent
              défiler (ProductCarouselSection) plutôt que rester en grille
              statique (ProductSection) — même principe que la carte
              "Rentrée scolaire" de CategoryBlocks et le carrousel
              Nouveautés ci-dessous. Le code promo public RENTREE20 (-20%,
              créé dans Shopify le 19/08/2026, actif jusqu'au 7 septembre)
              s'applique à toute la commande, pas seulement à ces produits —
              titre honnête : il invite à l'utiliser sans prétendre à une
              remise produit par produit qui n'existe pas côté Shopify.
              Regroupé en 2 rayons (retour client 19/08/2026, voir
              rentreeAutresFournitures ci-dessus) plutôt que 5 carrousels fins
              par sous-catégorie. */}
          {rentreeBackpacks.length > 0 && (
            <ProductCarouselSection
              title="Rentrée — sacs à dos & cartables (code RENTREE20 : -20% sur la commande)"
              products={rentreeBackpacks}
              seeAllHref="/search?q=cartable"
            />
          )}
          {rentreeAutresFournitures.length > 0 && (
            <ProductCarouselSection
              title="Rentrée — trousses, papeterie & fournitures"
              products={rentreeAutresFournitures}
              seeAllHref="/search?q=trousse"
            />
          )}
        </div>
      )}
      <RecentlyViewedSection />
      {featuredCategoryTop.length > 0 && (
        <ProductSection title={FEATURED_CATEGORY_TITLE} products={featuredCategoryTop} seeAllHref={FEATURED_CATEGORY_HREF} />
      )}
      {showDeals && (
        <ProductSection title="Offres du moment" products={deals} seeAllHref="/search?q=&sort=price_asc" />
      )}
      <ProductSection title="Meilleures ventes" products={bestsellers} seeAllHref="/search?q=&sort=bestselling" />
      <ProductCarouselSection title="Nouveautés" products={newArrivals} seeAllHref="/search?q=&sort=newest" />
      <ProductSection title="Recommandé pour vous" products={recommendations} seeAllHref="/search?q=&sort=rating" />
      {/* Pas de section "Nos marques" : le composant BrandsRow affichait 12 noms
          de marque entièrement fictifs (src/data/brands.ts, jamais vendus sur le
          catalogue réel — voir mission déploiement Vercel, 14/08/2026). Retiré
          plutôt que remplacé par une donnée inventée. */}
    </>
  );
}
