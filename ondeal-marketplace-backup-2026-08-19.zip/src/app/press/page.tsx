import type { Metadata } from "next";
import { Info } from "lucide-react";
import Breadcrumbs from "@/components/navigation/Breadcrumbs";
import { COMPANY_EMAIL } from "@/lib/company-info";
import styles from "../info-page.module.css";

export const metadata: Metadata = {
  title: "Presse",
  alternates: { canonical: "/press" },
};

export default function PressPage() {
  return (
    <div className={`${styles.page} container`}>
      <Breadcrumbs items={[{ label: "Accueil", href: "/" }, { label: "Presse" }]} />

      <header className={styles.header}>
        <h1>Presse</h1>
      </header>

      <div className={styles.infoNotice}>
        <Info size={18} />
        <span>Aucun dossier de presse n&apos;est disponible en téléchargement pour le moment.</span>
      </div>

      <section className={styles.section}>
        <p>
          Journaliste ou créateur de contenu et vous souhaitez en savoir plus sur OnDeal, obtenir des visuels ou
          organiser un entretien ? Contactez-nous directement à{" "}
          <a href={`mailto:${COMPANY_EMAIL}`}>{COMPANY_EMAIL}</a>, nous vous répondrons rapidement.
        </p>
      </section>
    </div>
  );
}
