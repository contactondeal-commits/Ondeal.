import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { fetchAllProducts, fetchBoughtTogetherProducts, fetchProductBySlug, fetchRelatedProducts } from "@/services/productService";
import { getAllCategoriesFlat } from "@/data/categories";
import Breadcrumbs from "@/components/navigation/Breadcrumbs";
import ProductGallery from "@/components/products/ProductGallery";
import ProductRating from "@/components/products/ProductRating";
import ProductBadge from "@/components/products/ProductBadge";
import AddToCartPanel from "@/components/products/AddToCartPanel";
import { ProductSelectionProvider } from "@/components/products/ProductSelectionProvider";
import ReviewsList from "@/components/products/ReviewsList";
import ProductGrid from "@/components/products/ProductGrid";
import RecentlyViewedSection from "@/components/products/RecentlyViewedSection";
import MobileStickyCta from "@/components/products/MobileStickyCta";
import TrustBadges from "@/components/products/TrustBadges";
import { Truck, ShieldCheck } from "lucide-react";
import { safeJsonLdString } from "@/lib/seo";
import { SITE_URL } from "@/lib/site-config";
import { formatPrice } from "@/lib/format";
import styles from "./page.module.css";

export async function generateStaticParams() {
  const allProducts = await fetchAllProducts();
  return allProducts.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata(props: PageProps<"/product/[slug]">): Promise<Metadata> {
  const { slug } = await props.params;
  const product = await fetchProductBySlug(slug);
  if (!product) return { title: "Produit introuvable" };
  return {
    title: product.title,
    description: product.description.slice(0, 160),
    alternates: { canonical: `/product/${product.slug}` },
    openGraph: {
      title: product.title,
      description: product.description.slice(0, 160),
      type: "website",
    },
  };
}

export default async function ProductPage(props: PageProps<"/product/[slug]">) {
  const { slug } = await props.params;
  const product = await fetchProductBySlug(slug);
  if (!product) notFound();

  const category = getAllCategoriesFlat().find((c) => c.id === (product.subcategoryId ?? product.categoryId));
  const [related, boughtTogether] = await Promise.all([
    fetchRelatedProducts(product, 6),
    fetchBoughtTogetherProducts(product, 4),
  ]);

  const realImages = product.images.filter((img) => /^https?:\/\//i.test(img));
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.title,
    url: `${SITE_URL}/product/${product.slug}`,
    ...(realImages.length > 0 ? { image: realImages } : {}),
    brand: { "@type": "Brand", name: product.brand },
    description: product.description,
    sku: product.id,
    aggregateRating:
      product.reviewsCount > 0
        ? { "@type": "AggregateRating", ratingValue: product.rating, reviewCount: product.reviewsCount }
        : undefined,
    offers: {
      "@type": "Offer",
      priceCurrency: "EUR",
      price: product.price,
      availability: product.inStock ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
    },
  };

  return (
    <div className={`${styles.page} container`}>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: safeJsonLdString(jsonLd) }} />

      <Breadcrumbs
        items={[
          { label: "Accueil", href: "/" },
          ...(category ? [{ label: category.name, href: `/category/${category.slug}` }] : []),
          { label: product.title },
        ]}
      />

      <ProductSelectionProvider product={product}>
      <div className={styles.top}>
        <ProductGallery images={product.images} title={product.title} />

        <div className={styles.info}>
          <span className={styles.brand}>{product.brand}</span>
          <h1 className={styles.title}>{product.title}</h1>
          <ProductRating rating={product.rating} reviewsCount={product.reviewsCount} size={16} />

          {product.badges.length > 0 && (
            <div className={styles.badges}>
              {product.badges.map((b) => (
                <ProductBadge key={b} type={b} />
              ))}
            </div>
          )}

          <div className={styles.priceBlock}>
            <span className={styles.price}>{formatPrice(product.price)}</span>
            {product.oldPrice && <span className={styles.oldPrice}>{formatPrice(product.oldPrice)}</span>}
            {product.discount ? <span className={styles.discount}>-{product.discount}%</span> : null}
          </div>

          <div className={styles.deliveryInfo}>
            <p>
              <Truck size={15} /> {product.delivery.estimate}
              {product.delivery.freeShipping && " — Livraison offerte"}
            </p>
            {/*
              Mission CRO Phase 1 (2026-08-13) — section 10 : le nombre brut
              `product.stock` (issu de `totalInventory` Shopify) n'est plus
              affiché ici. L'audit stock du 13/08/2026
              (reports/shopify-live-catalog-audit.md section 2) a confirmé
              que 858/970 produits ont une valeur `totalInventory`
              manifestement anormale (jusqu'à 3 440 217), cause exacte
              NOT AVAILABLE / HUMAN VALIDATION REQUIRED. Afficher ce chiffre
              tel quel (ex. "En stock (3440217 disponibles)") nuirait à la
              crédibilité du site. Seul un signal binaire fiable est
              utilisé : `product.inStock`, dérivé en priorité de
              `availableForSale` (voir mapStorefrontProduct dans
              storefront.ts) — jamais de fausse urgence ("plus que X").
            */}
            <p className={product.inStock ? styles.inStock : styles.outStock}>
              <ShieldCheck size={15} /> {product.inStock ? "En stock" : "Rupture de stock"}
            </p>
          </div>

          <hr className={styles.divider} />

          <AddToCartPanel product={product} />
          {/* Sentinel utilisé par MobileStickyCta (P1-2) pour détecter la
              sortie du viewport du bloc d'achat initial — voir ce composant. */}
          <span id="add-to-cart-sentinel" aria-hidden="true" />

          <TrustBadges />

          <p className={styles.seller}>{product.seller}</p>
        </div>
      </div>

      <MobileStickyCta product={product} />
      </ProductSelectionProvider>

      <div className={styles.tabsGrid}>
        <section aria-labelledby="description-heading">
          <h2 id="description-heading">Description</h2>
          <p className={styles.descriptionText}>{product.description}</p>
        </section>

        <section aria-labelledby="features-heading">
          <h2 id="features-heading">Caractéristiques</h2>
          <ul className={styles.featureList}>
            {product.features.map((f) => (
              <li key={f}>{f}</li>
            ))}
          </ul>
        </section>

        <section aria-labelledby="specs-heading">
          <h2 id="specs-heading">Informations techniques</h2>
          <table className={styles.specsTable}>
            <tbody>
              {Object.entries(product.specifications).map(([key, value]) => (
                <tr key={key}>
                  <th scope="row">{key}</th>
                  <td>{value}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <section aria-labelledby="reviews-heading">
          <h2 id="reviews-heading">Avis clients</h2>
          <ReviewsList product={product} />
        </section>

        <section aria-labelledby="qa-heading">
          <h2 id="qa-heading">Questions / réponses</h2>
          <p className={styles.qaEmpty}>Aucune question pour le moment. Soyez le premier à en poser une.</p>
        </section>
      </div>

      {/* Repère utilisé par MobileStickyCta (corrigé le 2026-08-13) pour se
          masquer avant les grilles de produits liés — évite qu'elle recouvre
          le bouton "Ajouter au panier" d'un AUTRE produit. */}
      <span id="sticky-cta-end-boundary" aria-hidden="true" />

      {related.length > 0 && (
        <section className={styles.relatedSection} aria-labelledby="related-heading">
          <h2 id="related-heading">Produits similaires</h2>
          <ProductGrid products={related} />
        </section>
      )}

      {boughtTogether.length > 0 && (
        <section className={styles.relatedSection} aria-labelledby="together-heading">
          <h2 id="together-heading">Produits fréquemment achetés ensemble</h2>
          <ProductGrid products={boughtTogether} />
        </section>
      )}

      <RecentlyViewedSection currentProductId={product.id} />
    </div>
  );
}
