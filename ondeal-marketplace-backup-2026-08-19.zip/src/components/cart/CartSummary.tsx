import Link from "next/link";
import Button from "@/components/ui/Button";
import TrustBadges from "@/components/products/TrustBadges";
import { formatPrice } from "@/lib/format";
import { FREE_SHIPPING_THRESHOLD, STANDARD_SHIPPING_COST as SHIPPING_COST } from "@/lib/site-config";
import styles from "./CartSummary.module.css";

interface CartSummaryProps {
  subtotal: number;
  itemCount: number;
}

export default function CartSummary({ subtotal, itemCount }: CartSummaryProps) {
  const shipping = subtotal === 0 || subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_COST;
  const total = subtotal + shipping;
  const remainingForFreeShipping = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal);
  // Progression réelle basée sur le sous-total réel / le seuil réel — jamais simulée.
  const progressPercent = Math.min(100, Math.round((subtotal / FREE_SHIPPING_THRESHOLD) * 100));

  return (
    <div className={styles.root}>
      <h2>Résumé</h2>

      {subtotal > 0 && (
        <div className={styles.freeShippingProgress}>
          {remainingForFreeShipping > 0 ? (
            <p className={styles.freeShippingNote}>
              Encore {formatPrice(remainingForFreeShipping)} pour la livraison offerte !
            </p>
          ) : (
            <p className={styles.freeShippingNoteDone}>Livraison offerte débloquée ✓</p>
          )}
          <div
            className={styles.progressTrack}
            role="progressbar"
            aria-valuenow={progressPercent}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-label="Progression vers la livraison offerte"
          >
            <div className={styles.progressFill} style={{ width: `${progressPercent}%` }} />
          </div>
        </div>
      )}

      <div className={styles.row}>
        <span>Sous-total ({itemCount} article{itemCount > 1 ? "s" : ""})</span>
        <span>{formatPrice(subtotal)}</span>
      </div>
      <div className={styles.row}>
        <span>Livraison</span>
        <span>{shipping === 0 ? "Offerte" : formatPrice(shipping)}</span>
      </div>
      <div className={`${styles.row} ${styles.total}`}>
        <span>Total</span>
        <span>{formatPrice(total)}</span>
      </div>

      <Link href="/checkout">
        <Button variant="primary" size="lg" fullWidth disabled={itemCount === 0}>
          Passer la commande
        </Button>
      </Link>

      {/* Mission CRO Phase 1 — P1-4 : badges de confiance visibles avant le paiement. */}
      <TrustBadges compact />
    </div>
  );
}
