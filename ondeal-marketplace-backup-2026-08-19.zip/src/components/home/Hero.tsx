"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { ChevronLeft, ChevronRight, Copy, Check } from "lucide-react";
import styles from "./Hero.module.css";

export interface HeroSlide {
  id: string;
  title: string;
  subtitle: string;
  cta: string;
  href: string;
  bg: string;
  /** Mission "GAMME RENTRÉE — code promo visible" (19/08/2026) — demande
   * explicite du client : le code promo public doit être visible dès
   * l'arrivée sur ondeal.fr, avec un visuel "pro/agence". Optionnel :
   * uniquement renseigné sur le slide rentrée, avec le vrai code créé dans
   * Shopify (RENTREE20, -20% sur toute la commande, voir ProductCarouselSection
   * dans page.tsx pour le rappel du même code) — jamais un code inventé. */
  promoCode?: string;
  promoLabel?: string;
}

const DEFAULT_SLIDES: HeroSlide[] = [
  {
    // Mission "GAMME RENTRÉE" (19/08/2026) — demande explicite du client,
    // placée en premier slide car période de vente réelle (fin août). Pointe
    // vers l'ancre #rentree (voir page.tsx) : les deux sections "Rentrée"
    // construites à partir du vrai catalogue Shopify réactivé pour
    // l'occasion (voir commentaire RENTREE_BACKPACK_IDS dans page.tsx) —
    // jamais de produit ou de promotion inventés pour ce visuel.
    id: "rentree",
    title: "C'est la rentrée !",
    subtitle: "Cartables, trousses et fournitures des plus grandes marques, prêts à partir.",
    cta: "Voir la sélection rentrée",
    href: "/#rentree",
    // Vert tableau d'école — code couleur volontairement différent des
    // autres slides (navy/teal/violet) pour évoquer la rentrée, tout en
    // gardant un fond sombre qui fait ressortir le bouton CTA orange
    // (var(--color-secondary), voir Hero.module.css) comme sur les autres
    // slides — un fond orange/rouge aurait fait disparaître ce bouton.
    bg: "linear-gradient(120deg, #14532d, #052e16)",
    // Code promo public réel (créé dans Shopify le 19/08/2026, -20% sur
    // toute la commande, actif jusqu'au 7 septembre) — voir demande client
    // "il faut le code promo visible ... des qu'il rentre sur ondeal".
    promoCode: "RENTREE20",
    promoLabel: "-20% sur toute la commande",
  },
  {
    id: "s1",
    title: "Découvrez nos meilleures offres",
    subtitle: "Les produits que vous recherchez au meilleur prix.",
    cta: "Découvrir maintenant",
    href: "/search?q=&sort=price_asc",
    // Mission IDENTITÉ VISUELLE (2026-08-13) — ancien dégradé bleu vif
    // générique (#1a56db, placeholder pré-mission) remplacé par le vrai
    // bleu foncé de marque échantillonné depuis le logo officiel (#0c1f32).
    // Le CTA orange (styles.cta → var(--color-secondary)) reste inchangé et
    // ressort naturellement sur ce fond navy.
    bg: "linear-gradient(120deg, #0c1f32, #061019)",
  },
  {
    id: "s2",
    title: "La rentrée high-tech commence ici",
    subtitle: "Smartphones, ordinateurs et accessoires sélectionnés pour vous.",
    cta: "Voir la sélection",
    href: "/category/electronique",
    bg: "linear-gradient(120deg, #0f766e, #0b4f4a)",
  },
  {
    id: "s3",
    title: "Nouveautés mode de la semaine",
    subtitle: "Les dernières tendances pour toute la famille.",
    cta: "Explorer la mode",
    href: "/category/mode",
    bg: "linear-gradient(120deg, #6d28d9, #4c1d95)",
  },
];

interface HeroProps {
  slides?: HeroSlide[];
  autoplayMs?: number;
}

export default function Hero({ slides = DEFAULT_SLIDES, autoplayMs = 6000 }: HeroProps) {
  const [index, setIndex] = useState(0);
  // Retour visuel "Copié !" après clic sur le badge code promo — voir
  // handleCopyCode ci-dessous. Remis à zéro automatiquement.
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const next = useCallback(() => setIndex((i) => (i + 1) % slides.length), [slides.length]);
  const prev = useCallback(() => setIndex((i) => (i - 1 + slides.length) % slides.length), [slides.length]);

  useEffect(() => {
    if (!autoplayMs) return;
    const id = setInterval(next, autoplayMs);
    return () => clearInterval(id);
  }, [next, autoplayMs]);

  useEffect(() => {
    if (!copiedCode) return;
    const t = setTimeout(() => setCopiedCode(null), 2000);
    return () => clearTimeout(t);
  }, [copiedCode]);

  const handleCopyCode = useCallback(async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedCode(code);
    } catch {
      // Presse-papiers indisponible (permissions navigateur) : le code reste
      // lisible à l'écran, l'utilisateur peut le recopier manuellement.
    }
  }, []);

  const slide = slides[index];

  return (
    <section className={styles.root} aria-roledescription="carousel" aria-label="Mises en avant">
      <div className={styles.slide} style={{ background: slide.bg }}>
        <div className={`${styles.content} container`}>
          {slide.promoCode && (
            <button
              type="button"
              className={styles.promoBadge}
              onClick={() => handleCopyCode(slide.promoCode!)}
              aria-label={`Copier le code promo ${slide.promoCode}${slide.promoLabel ? `, ${slide.promoLabel}` : ""}`}
            >
              {slide.promoLabel && <span className={styles.promoLabel}>{slide.promoLabel}</span>}
              <span className={styles.promoCodeChip}>
                <span className={styles.promoCodeText}>{slide.promoCode}</span>
                {copiedCode === slide.promoCode ? (
                  <Check size={14} aria-hidden="true" />
                ) : (
                  <Copy size={14} aria-hidden="true" />
                )}
              </span>
              <span className={styles.promoHint}>{copiedCode === slide.promoCode ? "Copié !" : "Cliquer pour copier"}</span>
            </button>
          )}
          <h1 className={styles.title}>{slide.title}</h1>
          <p className={styles.subtitle}>{slide.subtitle}</p>
          <Link href={slide.href} className={styles.cta}>
            {slide.cta}
          </Link>
        </div>
      </div>

      <button className={`${styles.nav} ${styles.navPrev}`} onClick={prev} aria-label="Diapositive précédente">
        <ChevronLeft size={22} />
      </button>
      <button className={`${styles.nav} ${styles.navNext}`} onClick={next} aria-label="Diapositive suivante">
        <ChevronRight size={22} />
      </button>

      <div className={styles.indicators} role="tablist" aria-label="Choisir une diapositive">
        {slides.map((s, i) => (
          <button
            key={s.id}
            role="tab"
            aria-selected={i === index}
            aria-label={`Diapositive ${i + 1}`}
            className={`${styles.dot} ${i === index ? styles.dotActive : ""}`}
            onClick={() => setIndex(i)}
          />
        ))}
      </div>
    </section>
  );
}
