"use client";

import Link from "next/link";
import Image from "next/image";
import { User, Package, ShoppingCart, Menu, Globe } from "lucide-react";
import SearchBar from "@/components/search/SearchBar";
import { useCart } from "@/hooks/useCart";
import { SITE_NAME, SHOPIFY_ACCOUNT_URL } from "@/lib/site-config";
import styles from "./Header.module.css";

interface HeaderProps {
  onOpenCategoryMenu: () => void;
}

export default function Header({ onOpenCategoryMenu }: HeaderProps) {
  const { count } = useCart();

  return (
    <header className={styles.header}>
      <div className={`${styles.inner} container`}>
        <button
          type="button"
          className={styles.mobileMenuBtn}
          aria-label="Ouvrir le menu des catégories"
          onClick={onOpenCategoryMenu}
        >
          <Menu size={24} />
        </button>

        {/*
          Mission LOGO OFFICIEL FINAL (15/08/2026) — remplace l'ancien fichier
          public/brand/ondeal-logo.png (variante "Ondeal" + panier orange,
          jamais validée comme définitive) par le logo officiel et final
          fourni par le client (dossier 06_Logo_Identite_Visuelle/Final/ —
          wordmark "OnDeal" + trait orange, sans le panier). Fichier source :
          logo-wordmark-sans-slogan.png, simplement détouré (transparence
          existante conservée, aucune recoloration/déformation). Dimensions
          width/height alignées sur le ratio réel du nouveau fichier
          (1524×511) pour ne pas déformer l'image — la taille affichée réelle
          reste pilotée par .logoImg (CSS, height fixe + width:auto). Le fond
          blanc du chip est conservé car le header reste en bleu foncé de
          marque : le logo (texte bleu foncé) serait invisible sur un fond
          bleu foncé identique.
        */}
        <Link href="/" className={styles.logoChip} aria-label={`${SITE_NAME} — Retour à l'accueil`}>
          {/*
            Mission autonome (15/08/2026) — audit Lighthouse : `priority` est
            déprécié depuis Next.js 16 (voir node_modules/next/dist/docs/.../
            image.md, et le correctif équivalent sur CategoryBlocks.tsx pour
            le détail complet). Remplacé par le vrai signal documenté
            (`fetchPriority="high"` + `loading="eager"`) pour ce logo, présent
            dans le viewport initial sur toutes les pages.
          */}
          <Image
            src="/brand/ondeal-logo.png"
            alt={SITE_NAME}
            width={1524}
            height={511}
            fetchPriority="high"
            loading="eager"
            className={styles.logoImg}
          />
        </Link>

        <SearchBar className={styles.searchBar} />

        <nav className={styles.actions} aria-label="Compte et panier">
          <button type="button" className={styles.langBtn} aria-label="Changer de langue">
            <Globe size={18} />
            <span className={styles.actionLabel}>FR</span>
          </button>

          {/*
            Mission UX/UI Phase 3 (2026-08-13) — P1 (audit accessibilité) :
            ajout de aria-label="Mon compte"/"Mes commandes" (libellés déjà
            utilisés tels quels sur les pages de destination, voir
            src/app/account/page.tsx et src/app/account/orders/page.tsx —
            aucun texte inventé). Sans lui, ces liens n'avaient AUCUN nom
            accessible dès ≤991px : leur seul texte visible (.actionText)
            est masqué en CSS à cette largeur (display: none, exclu du calcul
            du nom accessible), contrairement à .cartBtn qui avait déjà un
            aria-label explicite. Bug confirmé via l'arbre d'accessibilité
            (accessibility.snapshot) : nom vide ('') pour ces deux liens en
            mobile — voir reports/ondeal-ux-ui-phase3.md section 7.
          */}
          {/*
            Mission "CONNEXION CLIENT" (15/08/2026) — pointe désormais
            directement vers le portail natif Shopify (voir SHOPIFY_ACCOUNT_URL
            dans site-config.ts pour le détail complet du diagnostic) plutôt
            que vers notre ancienne page /account personnalisée, qui dépendait
            d'un système de mot de passe classique incompatible avec les
            comptes clients réels de la boutique.
          */}
          <a href={SHOPIFY_ACCOUNT_URL} className={styles.actionBtn} aria-label="Mon compte">
            <User size={20} />
            <span className={styles.actionText}>
              <small>Bonjour</small>
              <span>Compte</span>
            </span>
          </a>

          <a href={SHOPIFY_ACCOUNT_URL} className={styles.actionBtn} aria-label="Mes commandes">
            <Package size={20} />
            <span className={styles.actionText}>
              <small>Vos</small>
              <span>Commandes</span>
            </span>
          </a>

          <Link href="/cart" className={styles.cartBtn} aria-label={`Panier, ${count} article(s)`}>
            <span className={styles.cartIconWrap}>
              <ShoppingCart size={22} />
              {count > 0 && <span className={styles.cartCount}>{count > 99 ? "99+" : count}</span>}
            </span>
            <span className={styles.actionText}>
              <span>Panier</span>
            </span>
          </Link>
        </nav>
      </div>

      <div className={styles.mobileSearchRow}>
        <SearchBar />
      </div>
    </header>
  );
}
