"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu } from "lucide-react";
import { categories, megaMenuCategoryIds } from "@/data/categories";
import { MegaMenuPanel, MegaMenuMobile } from "@/components/navigation/MegaMenu";
import type { Category } from "@/types";
import styles from "./MainNav.module.css";

interface MainNavProps {
  onOpenCategoryMenu: () => void;
}

const STATIC_LINKS = [
  { label: "Meilleures ventes", href: "/search?q=&sort=bestselling" },
  { label: "Nouveautés", href: "/search?q=&sort=newest" },
  { label: "Offres", href: "/search?q=&sort=price_asc" },
  { label: "Idées cadeaux", href: "/category/jeux-et-jouets" },
  { label: "Services", href: "/help" },
  { label: "Vendre", href: "/help" },
  { label: "Aide", href: "/help" },
];

export default function MainNav({ onOpenCategoryMenu }: MainNavProps) {
  const [hovered, setHovered] = useState<string | null>(null);
  const [mobileMega, setMobileMega] = useState<string | null>(null);
  /*
    Mission UX/UI Phase 4 (2026-08-13) — P0 (audit clavier des drawers) :
    bug confirmé par test automatisé (tests/drawer-focus-trap.spec.ts,
    scénario MegaMenuMobile) — le focus ne revenait PAS au lien déclencheur
    après Escape/fermeture, contrairement à CategoryMenu et FilterMobile.
    Cause : `<MegaMenuMobile>` (et donc son `<Drawer>` interne) n'était
    rendu que via `{activeMobileMega && <MegaMenuMobile .../>}`, où
    `activeMobileMega` dépendait directement de `mobileMega`. Fermer le
    panneau (mobileMega → null) démontait donc IMMÉDIATEMENT tout le
    composant au lieu de simplement faire passer sa prop `open` à `false` —
    contrairement à CategoryMenu/FilterMobile, dont le Drawer reste monté en
    permanence. `Drawer.tsx` ne peut renvoyer le focus au déclencheur que
    lors d'un re-render avec `open: true → false` sur un composant TOUJOURS
    monté (voir son effet `useEffect(..., [open])`) — un démontage immédiat
    court-circuite cet effet.
    Correctif minimal : `lastMegaCategory` retient la dernière catégorie
    ouverte séparément de `mobileMega` (qui ne pilote plus que `open`),
    pour garder `<MegaMenuMobile>` monté pendant sa fermeture — même
    pattern de stabilité que CategoryMenu/FilterMobile. Aucun changement à
    Drawer.tsx, à Escape, ni au comportement d'ouverture existant.
  */
  const [lastMegaCategory, setLastMegaCategory] = useState<Category | null>(null);
  const megaCategories = categories.filter((c) => megaMenuCategoryIds.includes(c.id));
  const activeMega = megaCategories.find((c) => c.id === hovered);

  return (
    <nav className={styles.nav} aria-label="Navigation principale" onMouseLeave={() => setHovered(null)}>
      <div className={`${styles.inner} container`}>
        <button type="button" className={styles.allCategoriesBtn} onClick={onOpenCategoryMenu}>
          <Menu size={16} />
          Toutes les catégories
        </button>

        <ul className={styles.links}>
          {megaCategories.map((cat) => (
            <li
              key={cat.id}
              onMouseEnter={() => setHovered(cat.id)}
              className={styles.megaTrigger}
            >
              {/*
                Bug confirmé et corrigé le 2026-08-13 (voir
                reports/ondeal-ux-ui-audit.md, ÉTAPE 1 — Navigation) :
                l'élément était un <button> dont le clic déclenchait
                toujours `setMobileMega`, y compris sur desktop. Résultat
                réel observé en navigateur : cliquer sur "Électronique"/
                "Maison"/"Mode" sur desktop (1440px) n'importe où
                n'amenait JAMAIS vers la page catégorie, et ouvrait en plus
                le panneau mobile plein écran par-dessus le panneau hover
                déjà affiché (double overlay visuellement cassé).
                Corrigé : vrai lien vers `/category/<slug>` (navigation
                fonctionnelle sur desktop, où le survol continue d'afficher
                le panneau détaillé) ; sur mobile (pas de survol possible),
                le tap ouvre toujours le sélecteur plein écran existant.
              */}
              <Link
                href={`/category/${cat.slug}`}
                className={styles.link}
                aria-haspopup="true"
                aria-expanded={hovered === cat.id}
                onClick={(e) => {
                  if (window.matchMedia("(max-width: 767px)").matches) {
                    e.preventDefault();
                    setLastMegaCategory(cat);
                    setMobileMega(cat.id);
                  }
                }}
              >
                {cat.name}
              </Link>
            </li>
          ))}
          {STATIC_LINKS.map((link) => (
            <li key={link.label}>
              <Link href={link.href} className={styles.link}>
                {link.label}
              </Link>
            </li>
          ))}
        </ul>
      </div>

      {activeMega && <MegaMenuPanel category={activeMega} onClose={() => setHovered(null)} />}
      {lastMegaCategory && (
        <MegaMenuMobile category={lastMegaCategory} open={!!mobileMega} onClose={() => setMobileMega(null)} />
      )}
    </nav>
  );
}
