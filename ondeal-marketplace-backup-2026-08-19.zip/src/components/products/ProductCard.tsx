"use client";

import Link from "next/link";
import { Heart, ShoppingCart, Truck } from "lucide-react";
import type { Product } from "@/types";
import PlaceholderImage from "@/components/ui/PlaceholderImage";
import ProductBadge from "./ProductBadge";
import ProductRating from "./ProductRating";
import { useCart } from "@/hooks/useCart";
import { useWishlist } from "@/hooks/useWishlist";
import { formatPrice } from "@/lib/format";
import styles from "./ProductCard.module.css";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();
  const { isInWishlist, toggleWishlist } = useWishlist();
  const inWishlist = isInWishlist(product.id);

  return (
    <div className={styles.card}>
      {/*
        Mission autonome (15/08/2026) — audit Lighthouse (accessibilité) :
        `aria-label={product.title}` sur ce lien masquait aux lecteurs
        d'écran/contrôle vocal le badge visible qu'il contient parfois
        ("Nouveau", "Top vente"...) — un vrai texte visible à l'intérieur du
        lien mais absent du nom accessible annoncé (violation WCAG 2.5.3,
        confirmée par l'audit : `label-content-name-mismatch`). Retiré :
        le nom accessible se calcule désormais naturellement à partir du
        contenu réel du lien (alt de l'image produit + texte du badge s'il y
        en a un) — plus complet, plus honnête, et sans changement visuel.
      */}
      <Link href={`/product/${product.slug}`} className={styles.imageLink}>
        <div className={styles.imageWrap}>
          <PlaceholderImage seed={product.images[0]} label={product.title} rounded={false} />
          <div className={styles.badges}>
            {product.badges.slice(0, 2).map((b) => (
              <ProductBadge key={b} type={b} />
            ))}
          </div>
        </div>
      </Link>

      <button
        type="button"
        className={`${styles.wishlistBtn} ${inWishlist ? styles.wishlistActive : ""}`}
        aria-label={inWishlist ? "Retirer des favoris" : "Ajouter aux favoris"}
        aria-pressed={inWishlist}
        onClick={() => toggleWishlist(product.id)}
      >
        <Heart size={17} fill={inWishlist ? "currentColor" : "none"} />
      </button>

      <div className={styles.body}>
        <span className={styles.brand}>{product.brand}</span>
        <Link href={`/product/${product.slug}`} className={styles.title}>
          {product.title}
        </Link>

        <ProductRating rating={product.rating} reviewsCount={product.reviewsCount} hideWhenEmpty />

        <div className={styles.priceRow}>
          <span className={styles.price}>{formatPrice(product.price)}</span>
          {product.oldPrice && <span className={styles.oldPrice}>{formatPrice(product.oldPrice)}</span>}
          {product.discount && product.discount > 0 && <span className={styles.discount}>-{product.discount}%</span>}
        </div>

        <div className={styles.deliveryRow}>
          {product.delivery.freeShipping && (
            <span className={styles.deliveryFree}>
              <Truck size={13} /> Livraison offerte
            </span>
          )}
          <span className={product.inStock ? styles.inStock : styles.outStock}>
            {product.inStock ? "Disponible" : "Rupture de stock"}
          </span>
        </div>

        {/*
          Mission "SÉLECTION DE TAILLE" (15/08/2026) — une grille de produits
          ne charge que la variante par défaut de chaque produit (voir
          fetchShopifyProducts dans storefront.ts, pour ne pas alourdir la
          requête de 24 à 250 produits) : elle ne peut donc jamais savoir
          quelle taille/couleur ajouter. `product.options` (léger, toujours
          chargé) suffit à détecter qu'un choix est nécessaire — dans ce cas,
          le bouton mène à la fiche produit (où le vrai sélecteur est
          disponible) au lieu d'ajouter une variante arbitraire au panier.
        */}
        {product.options && product.options.length > 0 ? (
          <Link href={`/product/${product.slug}`} className={styles.addBtn}>
            <ShoppingCart size={16} />
            Choisir les options
          </Link>
        ) : (
          <button
            type="button"
            className={styles.addBtn}
            disabled={!product.inStock}
            onClick={() => addToCart(product)}
          >
            <ShoppingCart size={16} />
            Ajouter au panier
          </button>
        )}
      </div>
    </div>
  );
}
