"use client";

import { useRecentlyViewed } from "@/hooks/useRecentlyViewed";
import ProductSection from "@/components/home/ProductSection";

/**
 * Mission "GAINS RAPIDES CROISSANCE" (19/08/2026) — "Produits récemment
 * consultés". Section client (l'historique vit dans le localStorage du
 * navigateur, voir recentlyViewedStore.ts) branchée sur la fiche produit
 * (enregistre + affiche, `currentProductId` exclu de sa propre liste) et
 * sur l'accueil (affiche seulement, aucun `currentProductId`).
 *
 * Rendu conditionnel : rien tant que le chargement n'est pas terminé ou si
 * la liste est vide (premier visiteur, historique effacé, etc.) — jamais de
 * section vide ni de squelette qui décale la mise en page pour un bloc
 * secondaire en bas de page.
 */
interface RecentlyViewedSectionProps {
  currentProductId?: string;
  title?: string;
}

export default function RecentlyViewedSection({
  currentProductId,
  title = "Consulté récemment",
}: RecentlyViewedSectionProps) {
  const { items, loading } = useRecentlyViewed(currentProductId);

  if (loading || items.length === 0) return null;

  return <ProductSection title={title} products={items} />;
}
