"use client";

import { useEffect, useState } from "react";
import { useRecentlyViewedStore } from "@/store/recentlyViewedStore";
import { fetchRecentlyViewedProducts } from "@/app/actions/recently-viewed";
import type { Product } from "@/types";

/**
 * Mission "GAINS RAPIDES CROISSANCE" (19/08/2026) — "Produits récemment
 * consultés". Même modèle que useWishlist.ts : la liste locale (ids
 * seulement, dans le localStorage du navigateur) ne suffit pas à afficher
 * un produit — il faut résoudre les VRAIS produits Shopify correspondants
 * via une Server Action, de façon asynchrone.
 *
 * `currentProductId`, si fourni (appelé depuis la fiche produit en cours de
 * consultation) : (1) enregistré comme "vu" au montage, (2) exclu de la
 * liste affichée — inutile de recommander à quelqu'un le produit qu'il est
 * déjà en train de regarder.
 */
const MAX_DISPLAY_COUNT = 10;

export function useRecentlyViewed(currentProductId?: string) {
  const productIds = useRecentlyViewedStore((s) => s.productIds);
  const recordView = useRecentlyViewedStore((s) => s.recordView);

  useEffect(() => {
    if (currentProductId) recordView(currentProductId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentProductId]);

  const idsToShow = productIds.filter((id) => id !== currentProductId).slice(0, MAX_DISPLAY_COUNT);

  const [items, setItems] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    if (idsToShow.length === 0) {
      setItems([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    fetchRecentlyViewedProducts(idsToShow)
      .then((products) => {
        if (!cancelled) setItems(products);
      })
      .catch(() => {
        // Filet de sécurité : en cas d'erreur réseau/API, section masquée
        // plutôt qu'un plantage — jamais de produit inventé.
        if (!cancelled) setItems([]);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idsToShow.join(",")]);

  return { items, loading };
}
