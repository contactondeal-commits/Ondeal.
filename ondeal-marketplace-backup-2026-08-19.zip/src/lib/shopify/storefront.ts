import { SHOPIFY_API_VERSION, getShopifyDomain, isShopifyPublicConfigured } from "./config";
import type { Product } from "@/types";
import { parseCategoryTag, UNCATEGORIZED } from "@/lib/catalog/category-mapping";
import { fetchJudgemeProductReviews } from "./judgeme";

/**
 * Client Storefront GraphQL Shopify — seule source de vérité pour le
 * catalogue affiché publiquement sur ondeal.fr (voir mission : "Ne jamais
 * faire Next.js → CJ directement pour afficher le catalogue public").
 *
 * Le Storefront API ne retourne jamais les produits ARCHIVED ou DRAFT : par
 * construction, il n'expose que les produits publiés sur le canal de vente
 * "Online Store". Aucun filtrage manuel du statut n'est donc nécessaire côté
 * Next.js pour respecter la règle "jamais afficher les produits archivés" —
 * c'est Shopify qui l'applique nativement à ce niveau.
 *
 * CREDENTIALS REQUIS : SHOPIFY_STORE_DOMAIN, SHOPIFY_STOREFRONT_ACCESS_TOKEN
 * (Shopify Admin > Apps > Développer des apps > votre app > API Storefront >
 * scopes de lecture catalogue > Installer > "Token API Storefront").
 */

export class ShopifyStorefrontError extends Error {
  constructor(
    message: string,
    public readonly errors?: unknown
  ) {
    super(message);
  }
}

function getStorefrontToken(): string {
  const token = process.env.SHOPIFY_STOREFRONT_ACCESS_TOKEN;
  if (!token) {
    throw new Error("SHOPIFY_STOREFRONT_ACCESS_TOKEN manquant. Voir .env.example.");
  }
  return token;
}

export async function shopifyStorefrontGraphQL<T>(
  query: string,
  variables: Record<string, unknown> = {},
  options: { noStore?: boolean } = {}
): Promise<T> {
  const domain = getShopifyDomain();
  const token = getStorefrontToken();

  let res: Response;
  try {
    res = await fetch(`https://${domain}/api/${SHOPIFY_API_VERSION}/graphql.json`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Shopify-Storefront-Access-Token": token,
      },
      body: JSON.stringify({ query, variables }),
      // Le catalogue public est raisonnablement stable : revalidation toutes
      // les 60s. En revanche, tout appel portant des données PERSONNELLES
      // (compte client : connexion, profil, commandes, adresses — voir
      // src/lib/shopify/customer.ts) passe options.noStore=true pour ne
      // JAMAIS être mis en cache — des données d'un client ne doivent
      // jamais pouvoir être servies à un autre.
      ...(options.noStore ? { cache: "no-store" as const } : { next: { revalidate: 60 } }),
      // Évite qu'une requête Shopify qui ne répond jamais (incident réseau/
      // CDN) ne bloque indéfiniment le rendu d'une page Next.js — voir
      // src/app/error.tsx pour la page affichée si ce délai est dépassé.
      signal: AbortSignal.timeout(10_000),
    });
  } catch (err) {
    if (err instanceof Error && err.name === "TimeoutError") {
      throw new ShopifyStorefrontError("Requête Storefront Shopify expirée après 10s (timeout réseau).");
    }
    throw new ShopifyStorefrontError(
      `Impossible de joindre l'API Storefront Shopify : ${err instanceof Error ? err.message : "erreur réseau inconnue"}`
    );
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new ShopifyStorefrontError(`Requête Storefront GraphQL échouée (HTTP ${res.status}): ${text}`);
  }

  const json = await res.json();
  if (json.errors) {
    throw new ShopifyStorefrontError("Erreurs GraphQL Storefront Shopify", json.errors);
  }
  return json.data as T;
}

// ---------------------------------------------------------------------------
// Fragment produit + mapping vers le type interne `Product`
// ---------------------------------------------------------------------------

// Mission "SÉLECTION DE TAILLE" (15/08/2026) — champs communs à toutes les
// requêtes catalogue (liste, recherche, recommandations) SANS la liste
// complète des variantes : charger jusqu'à 250 variantes par produit sur une
// grille de 24 à 250 produits serait inutile (une grille n'affiche que
// `inStock`) et coûteux côté quota API Shopify. `options` reste ici (léger :
// juste noms/valeurs, pas les variantes elles-mêmes) pour rester disponible
// partout sans coût significatif.
const PRODUCT_FIELDS_BASE = `
  fragment ProductFieldsBase on Product {
    id
    handle
    title
    vendor
    tags
    description
    createdAt
    productType
    images(first: 8) { nodes { url altText } }
    priceRange { minVariantPrice { amount } }
    compareAtPriceRange { minVariantPrice { amount } }
    totalInventory
    options { name values }
    ratingValue: metafield(namespace: "reviews", key: "rating") { value }
    ratingCount: metafield(namespace: "reviews", key: "rating_count") { value }
  }
`;

// Fragment "léger" (grilles/listes/recherche/recommandations) : seule la
// première variante est chargée, uniquement pour dériver `inStock`.
const PRODUCT_FRAGMENT = `
  ${PRODUCT_FIELDS_BASE}
  fragment ProductFields on Product {
    ...ProductFieldsBase
    variants(first: 1) { nodes { id availableForSale } }
  }
`;

// Fragment "détaillé" (fiche produit uniquement) : toutes les variantes avec
// leurs options sélectionnées, prix et disponibilité réels — nécessaire pour
// construire le sélecteur de taille/couleur et résoudre le bon
// `shopifyVariantId` à ajouter au panier. 250 = maximum autorisé par
// connexion Shopify Storefront (catalogue réel observé : jusqu'à ~100+
// variantes sur certains produits couleur × taille, voir DECISIONS.md).
const PRODUCT_FRAGMENT_DETAILED = `
  ${PRODUCT_FIELDS_BASE}
  fragment ProductFieldsDetailed on Product {
    ...ProductFieldsBase
    variants(first: 250) {
      nodes {
        id
        title
        availableForSale
        price { amount }
        selectedOptions { name value }
        image { url }
      }
    }
  }
`;

interface StorefrontProductNode {
  id: string;
  handle: string;
  title: string;
  vendor: string;
  tags: string[];
  description: string;
  createdAt: string;
  productType: string;
  images: { nodes: { url: string; altText: string | null }[] };
  priceRange: { minVariantPrice: { amount: string } };
  compareAtPriceRange: { minVariantPrice: { amount: string } };
  totalInventory: number | null;
  options: { name: string; values: string[] }[];
  variants: {
    nodes: {
      id: string;
      availableForSale: boolean;
      title?: string;
      price?: { amount: string };
      selectedOptions?: { name: string; value: string }[];
      image?: { url: string } | null;
    }[];
  };
  ratingValue: { value: string } | null;
  ratingCount: { value: string } | null;
}

/**
 * Le metafield Shopify "reviews.rating" (posé par l'app Judge.me) ne stocke
 * PAS un simple nombre : c'est une chaîne JSON du type
 * `{"scale_min":"1.0","scale_max":"5.0","value":"5.0"}`. Correctif du
 * 17/08/2026 (commit 73175a3) : `Number(node.ratingValue.value)` sur cette
 * chaîne entière renvoyait `NaN` (affiché tel quel dans <ProductRating>),
 * jamais un vrai 0 propre — repéré en observant une note "NaN★" sur une
 * fiche produit réelle. Cette fonction extrait la seule sous-valeur
 * numérique utile (`value`) et retombe silencieusement sur 0 si le
 * metafield est absent, malformé, ou dans un format inattendu — jamais
 * d'erreur qui casserait le rendu de la fiche produit.
 */
function parseShopifyRatingMetafieldValue(raw: string | undefined | null): number {
  if (!raw) return 0;
  try {
    const parsed = JSON.parse(raw);
    const value = Number(parsed?.value);
    return Number.isFinite(value) ? value : 0;
  } catch {
    // Certains metafields "rating" plus anciens/manuels peuvent contenir un
    // nombre brut plutôt que le JSON posé par Judge.me — filet de sécurité.
    const value = Number(raw);
    return Number.isFinite(value) ? value : 0;
  }
}

const TAG_TO_BADGE: Record<string, Product["badges"][number]> = {
  bestseller: "BESTSELLER",
  nouveau: "NOUVEAU",
  promotion: "PROMOTION",
  "top-vente": "TOP_VENTE",
  recommande: "RECOMMANDE",
  exclusivite: "EXCLUSIVITE",
};

/**
 * Convertit un produit Storefront Shopify vers le type `Product` interne
 * utilisé par tous les composants existants (ProductCard, ProductGrid, etc.)
 * — permet de brancher Shopify sans réécrire la couche d'affichage.
 */
function mapStorefrontProduct(node: StorefrontProductNode): Product {
  const price = Number(node.priceRange.minVariantPrice.amount);
  const compareAt = Number(node.compareAtPriceRange.minVariantPrice.amount || 0);
  const hasDiscount = compareAt > price;
  const inStock = node.variants.nodes[0]?.availableForSale ?? (node.totalInventory ?? 0) > 0;

  const badges = node.tags
    .map((tag) => TAG_TO_BADGE[tag.toLowerCase()])
    .filter((b): b is Product["badges"][number] => Boolean(b));
  if (!inStock) badges.push("RUPTURE_STOCK");

  return {
    id: node.id,
    slug: node.handle,
    title: node.title,
    // Le champ Shopify `vendor` contient, pour une grande partie du
    // catalogue, le nom du FOURNISSEUR d'approvisionnement réel (ex.
    // "CJdropshipping", "SHENZHEN CANGYUAN TRADING CO., LTD.") plutôt qu'une
    // vraie marque produit — confidentiel, ne doit jamais apparaître côté
    // client (règle explicite du fournisseur). "Ondeal" est utilisé partout
    // à la place, quelle que soit la valeur réelle de `vendor`.
    brand: "Ondeal",
    // categoryId provient du tag Shopify `cat-<id>` (voir
    // src/lib/catalog/category-mapping.ts — convention réelle vérifiée sur
    // les produits déjà en catalogue le 12/08/2026 ; corrigé depuis un
    // premier brouillon qui lisait à tort un metafield inexistant sur les
    // vraies données, `custom.ondeal_category_id`, ce qui aurait rendu
    // TOUTE catégorisation invisible côté storefront public).
    categoryId: node.tags.map(parseCategoryTag).find((id): id is string => id !== null) ?? UNCATEGORIZED,
    images: node.images.nodes.map((img) => img.url),
    price,
    oldPrice: hasDiscount ? compareAt : undefined,
    discount: hasDiscount ? Math.round(((compareAt - price) / compareAt) * 100) : undefined,
    rating: parseShopifyRatingMetafieldValue(node.ratingValue?.value),
    reviewsCount: node.ratingCount ? Number(node.ratingCount.value) : 0,
    stock: node.totalInventory ?? 0,
    inStock,
    badges,
    delivery: {
      fast: node.tags.includes("livraison-rapide"),
      freeShipping: node.tags.includes("livraison-offerte"),
      estimate: "2 à 7 jours ouvrés",
    },
    // Même règle que `brand` ci-dessus : jamais le fournisseur réel.
    seller: "Ondeal",
    description: node.description,
    features: [],
    specifications: {},
    createdAt: node.createdAt,
    salesCount: 0,
    shopifyProductId: node.id,
    shopifyDefaultVariantId: node.variants.nodes[0]?.id,
    // Mission "SÉLECTION DE TAILLE" (15/08/2026) — `node.options` inclut
    // systématiquement une option "Title"/"Default Title" sur les produits
    // Shopify sans variante réelle (une seule variante implicite) : filtrée
    // ici (jamais un vrai choix pour l'acheteur), le reste est conservé tel
    // quel, sans renommer/traduire les noms d'option réels.
    options: node.options.filter((o) => o.name.toLowerCase() !== "title" && o.values.length > 1),
    // Seule la requête détaillée (fetchShopifyProductByHandle) demande
    // `selectedOptions`/`price`/`image` par variante — sur les autres
    // requêtes (grilles), `node.variants.nodes[0].selectedOptions` est
    // `undefined` et `variants` reste absent du Product retourné (voir
    // filtre ci-dessous), pour ne jamais construire un sélecteur de taille
    // avec des données de variante incomplètes.
    variants: node.variants.nodes[0]?.selectedOptions
      ? node.variants.nodes.map((v) => ({
          id: v.id,
          title: v.title ?? "",
          price: v.price ? Number(v.price.amount) : price,
          availableForSale: v.availableForSale,
          selectedOptions: v.selectedOptions ?? [],
          image: v.image?.url,
        }))
      : undefined,
    // Voir commentaire sur `tags` dans src/types/index.ts.
    tags: node.tags,
  };
}

// ---------------------------------------------------------------------------
// Requêtes catalogue
// ---------------------------------------------------------------------------

interface ProductsQueryResponse {
  products: { nodes: StorefrontProductNode[]; pageInfo: { hasNextPage: boolean; endCursor: string | null } };
}

export async function fetchShopifyProducts(options: {
  first?: number;
  after?: string | null;
  query?: string;
  sortKey?: "RELEVANCE" | "PRICE" | "BEST_SELLING" | "CREATED_AT";
  reverse?: boolean;
} = {}): Promise<{ products: Product[]; hasNextPage: boolean; endCursor: string | null }> {
  const data = await shopifyStorefrontGraphQL<ProductsQueryResponse>(
    `${PRODUCT_FRAGMENT}
    query Products($first: Int!, $after: String, $query: String, $sortKey: ProductSortKeys, $reverse: Boolean) {
      products(first: $first, after: $after, query: $query, sortKey: $sortKey, reverse: $reverse) {
        nodes { ...ProductFields }
        pageInfo { hasNextPage endCursor }
      }
    }`,
    {
      first: options.first ?? 24,
      after: options.after ?? null,
      query: options.query,
      sortKey: options.sortKey ?? "RELEVANCE",
      reverse: options.reverse ?? false,
    }
  );

  return {
    products: data.products.nodes.map(mapStorefrontProduct),
    hasNextPage: data.products.pageInfo.hasNextPage,
    endCursor: data.products.pageInfo.endCursor,
  };
}

// Nombre maximal de pages (250 produits/page) récupérées par
// `fetchAllShopifyProducts` avant d'arrêter la pagination par sécurité
// (évite une boucle de récupération illimitée en cas de catalogue anormal).
// Relevé le 15/08/2026 (mission "FINALISATION") : le catalogue réel est
// passé de 1037 à 1192+ produits ACTIVE en quelques minutes pendant cette
// session (import fournisseur en cours) — 10 pages (2500) laissait une marge
// trop faible vu la trajectoire annoncée (+1500 produits). Relevé à 20 pages
// (5000 produits) pour absorber la croissance prévue sans troncature
// silencieuse.
const MAX_PAGINATION_PAGES = 20;

/**
 * Récupère TOUS les produits correspondant aux critères, en paginant tant
 * que Shopify indique `hasNextPage`, au lieu de se limiter à une seule page
 * de 250 (limite corrigée le 13/08/2026 — voir reports/project-final-audit.md
 * section 15 #3 : les pages catégorie/catalogue tronquaient silencieusement
 * au-delà de 250 produits).
 *
 * Correctif "FINALISATION" (15/08/2026) : sans `sortKey` explicite, Shopify
 * trie par défaut par pertinence — un ordre pouvant se réorganiser entre deux
 * pages si le catalogue est modifié PENDANT la pagination (import fournisseur
 * en cours, observé réellement dans cette session : mêmes produits renvoyés
 * deux fois sur deux pages différentes). Un tri stable et monotone
 * (`CREATED_AT`, plus récent d'abord) évite ce réordonnancement en cours de
 * pagination ; les nouveaux produits créés pendant l'appel apparaissent en
 * tête (avant la page déjà récupérée) plutôt que de décaler des produits déjà
 * lus vers une autre page. Un dédoublonnage par id est conservé en filet de
 * sécurité, y compris quand un `sortKey` explicite est fourni par l'appelant.
 */
export async function fetchAllShopifyProducts(options: {
  query?: string;
  sortKey?: "RELEVANCE" | "PRICE" | "BEST_SELLING" | "CREATED_AT";
  reverse?: boolean;
} = {}): Promise<Product[]> {
  const sortKey = options.sortKey ?? "CREATED_AT";
  const reverse = options.sortKey ? options.reverse : true;

  const all: Product[] = [];
  const seenIds = new Set<string>();
  let after: string | null = null;
  let page = 0;

  while (page < MAX_PAGINATION_PAGES) {
    const result: { products: Product[]; hasNextPage: boolean; endCursor: string | null } = await fetchShopifyProducts({
      first: 250,
      after,
      query: options.query,
      sortKey,
      reverse,
    });
    for (const product of result.products) {
      if (seenIds.has(product.id)) continue; // filet de sécurité anti-doublon
      seenIds.add(product.id);
      all.push(product);
    }
    page += 1;
    if (!result.hasNextPage) return all;
    after = result.endCursor;
  }

  console.warn(
    `[shopify/storefront] fetchAllShopifyProducts a atteint la limite de sécurité de ${MAX_PAGINATION_PAGES} pages ` +
      `(${all.length} produits) sans avoir épuisé le catalogue Shopify — des produits supplémentaires existent ` +
      `peut-être et ne sont pas retournés. Augmenter MAX_PAGINATION_PAGES si le catalogue a réellement dépassé cette taille.`
  );
  return all;
}

interface ProductByHandleResponse {
  product: StorefrontProductNode | null;
}

export async function fetchShopifyProductByHandle(handle: string): Promise<Product | null> {
  const data = await shopifyStorefrontGraphQL<ProductByHandleResponse>(
    `${PRODUCT_FRAGMENT_DETAILED}
    query ProductByHandle($handle: String!) {
      product(handle: $handle) { ...ProductFieldsDetailed }
    }`,
    { handle }
  );
  if (!data.product) return null;

  const product = mapStorefrontProduct(data.product);

  // BUG FIX (17/08/2026) — voir judgeme.ts pour le contexte complet : le
  // résumé (note/nombre d'avis) vient du metafield agrégé Shopify, mais le
  // CONTENU détaillé des avis (auteur, texte) n'est disponible que via
  // l'API Judge.me. Uniquement sur la fiche produit détaillée (jamais sur
  // une grille) et uniquement si reviewsCount > 0 (évite un appel réseau
  // inutile sur les ~centaines de produits sans aucun avis publié).
  if (product.reviewsCount > 0) {
    const numericId = product.shopifyProductId?.split("/").pop();
    if (numericId) {
      product.reviews = await fetchJudgemeProductReviews(numericId);
    }
  }

  return product;
}

interface ProductsByIdsResponse {
  nodes: (StorefrontProductNode | null)[];
}

/**
 * Mission "AUDIT PANIER/FAVORIS" (15/08/2026) — bug réel découvert : la page
 * /wishlist reconstruisait ses produits en cherchant chaque `productId`
 * favori dans le jeu de données fictif `@/data/products` (voir
 * useWishlist.ts, avant correction). Un `productId` réel Shopify est un GID
 * (`gid://shopify/Product/...`), qui ne correspond à AUCUN id du jeu de
 * données fictif (`prod-0`, `prod-1`...) — la recherche échouait donc
 * TOUJOURS en silence : un client ayant réellement ajouté des favoris sur le
 * vrai catalogue voyait systématiquement "Vous n'avez pas encore ajouté de
 * favoris", quel que soit le nombre d'articles réellement mis en favori
 * (confirmé en inspectant le format des ids générés par mapStorefrontProduct
 * ci-dessus vs celui de products.ts). Cette fonction récupère les VRAIS
 * produits Shopify correspondant aux ids stockés, en un seul appel API
 * (`nodes`), quel que soit leur nombre — jamais de re-fabrication de données
 * produit à partir d'un simple id.
 */
export async function fetchShopifyProductsByIds(ids: string[]): Promise<Product[]> {
  if (ids.length === 0) return [];
  const data = await shopifyStorefrontGraphQL<ProductsByIdsResponse>(
    `${PRODUCT_FRAGMENT}
    query ProductsByIds($ids: [ID!]!) {
      nodes(ids: $ids) { ...ProductFields }
    }`,
    { ids }
  );
  // Un id qui ne correspond plus à un produit publié (supprimé/dépublié
  // depuis l'ajout aux favoris) renvoie `null` — filtré silencieusement,
  // jamais affiché comme une erreur (comportement attendu, pas un bug).
  return data.nodes
    .filter((n): n is StorefrontProductNode => n !== null && "id" in n)
    .map(mapStorefrontProduct);
}

// Mission "BRANCHER SEARCH & DISCOVERY" (15/08/2026) — demande explicite du
// client de vraiment relier l'app Shopify "Search & Discovery" (déjà
// installée) au site. Deux usages concrets de la Storefront API, tous deux
// pilotés par la configuration réelle de cette app côté Shopify Admin
// (synonymes, boosts, exclusions) :
// 1. `predictiveSearch` pour les suggestions de la barre de recherche
//    (remplace searchSuggestions() qui filtrait un jeu de données fictif
//    @/data/products — jamais de vrais produits Shopify, voir searchService.ts).
// 2. `productRecommendations` pour les sections "Produits similaires" /
//    "Achetés ensemble" de la fiche produit (remplace une requête par tag de
//    catégorie approximative par le vrai moteur de recommandation Shopify).

interface PredictiveSearchResponse {
  predictiveSearch: { products: StorefrontProductNode[] } | null;
}

/** Suggestions de recherche en temps réel — vrai moteur Shopify (Search & Discovery), jamais de données fictives. */
export async function fetchShopifyPredictiveSearchProducts(query: string, limit = 6): Promise<Product[]> {
  if (!query.trim()) return [];
  const data = await shopifyStorefrontGraphQL<PredictiveSearchResponse>(
    `${PRODUCT_FRAGMENT}
    query PredictiveSearchProducts($query: String!, $limit: Int!) {
      predictiveSearch(query: $query, limit: $limit, types: [PRODUCT]) {
        products { ...ProductFields }
      }
    }`,
    { query, limit }
    // Pas de noStore ici : données catalogue publiques (comme fetchShopifyProducts),
    // pas personnelles — le cache 60s par défaut de shopifyStorefrontGraphQL s'applique.
  );
  return (data.predictiveSearch?.products ?? []).map(mapStorefrontProduct);
}

interface ProductRecommendationsResponse {
  productRecommendations: StorefrontProductNode[] | null;
}

/** Recommandations réelles Shopify ("Search & Discovery") pour une fiche produit. */
export async function fetchShopifyProductRecommendations(
  productId: string,
  intent: "RELATED" | "COMPLEMENTARY" = "RELATED"
): Promise<Product[]> {
  const data = await shopifyStorefrontGraphQL<ProductRecommendationsResponse>(
    `${PRODUCT_FRAGMENT}
    query ProductRecommendations($productId: ID!, $intent: ProductRecommendationIntent!) {
      productRecommendations(productId: $productId, intent: $intent) { ...ProductFields }
    }`,
    { productId, intent }
    // Pas de noStore : données catalogue publiques, cache 60s par défaut.
  );
  return (data.productRecommendations ?? []).map(mapStorefrontProduct);
}

export { isShopifyPublicConfigured };
