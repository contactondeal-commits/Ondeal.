"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

/**
 * Mission "GAINS RAPIDES CROISSANCE" (19/08/2026) — "Produits récemment
 * consultés". Même modèle que searchHistoryStore.ts (liste locale,
 * dédupliquée, plus récent en premier, plafonnée) : aucune donnée envoyée à
 * un serveur tant que l'utilisateur ne consulte pas une page qui affiche
 * cette liste — voir useRecentlyViewed.ts pour la résolution des vrais
 * produits Shopify correspondant à ces ids.
 */
const MAX_STORED_IDS = 24;

interface RecentlyViewedState {
  productIds: string[];
  recordView: (productId: string) => void;
  clearRecentlyViewed: () => void;
}

export const useRecentlyViewedStore = create<RecentlyViewedState>()(
  persist(
    (set, get) => ({
      productIds: [],
      recordView: (productId) => {
        if (!productId) return;
        const withoutDupe = get().productIds.filter((id) => id !== productId);
        set({ productIds: [productId, ...withoutDupe].slice(0, MAX_STORED_IDS) });
      },
      clearRecentlyViewed: () => set({ productIds: [] }),
    }),
    { name: "ondeal-recently-viewed" }
  )
);
